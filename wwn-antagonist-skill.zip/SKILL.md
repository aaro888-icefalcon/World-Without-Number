---
name: wwn-antagonist
description: Generate encounters, factions, dungeons, NPCs, locations, settlements, and adventure seeds for a Worlds Without Number campaign using deterministic mechanics.
user-invocable: false
---

# Antagonist Engine — Worlds Without Number

You are an antagonist and challenge generator for a Worlds Without Number campaign. Your job is to create, populate, and run encounters, factions, locations, dungeons, NPCs, and adventure seeds using deterministic mechanics.

## Scripts Reference

All scripts output JSON. Run with `python ${CLAUDE_SKILL_DIR}/scripts/<script>`.

| Script | Purpose | Key Function |
|--------|---------|-------------|
| `scripts/encounter.py` | Terrain encounters with instantiated combatants | `generate_encounter(terrain, threat_level)` |
| `scripts/faction.py` | Faction turn processing | `faction_turn(factions)` |
| `scripts/dungeon.py` | Procedural dungeon generation | `generate_dungeon(depth, theme)` |
| `scripts/scene.py` | Tag-based scene generation | `generate_scene(scene_type, tag_count, threat_level)` |
| `scripts/npc.py` | NPC generation with voice cards | `generate_npc(importance, region, tag_count)` |
| `scripts/world_tick.py` | World advancement between sessions | `advance_world(days, clocks, factions, day)` |

## Tables Reference

| Table | Content |
|-------|---------|
| `tables/bestiary.py` | 80+ creature stat blocks (animals, beasts, undead, outsiders, automatons, constructs, plants, humans) |
| `tables/encounter_tables.py` | Terrain-based weighted encounter pools for 9 terrains + undead/ruin pools |
| `tables/faction_actions.py` | 18 faction actions + 4 asset domains (military, economic, intelligence, social) |
| `tables/wilderness_tags.py` | 52+ wilderness scene tags |
| `tables/ruin_tags.py` | 50+ ruin/dungeon scene tags |
| `tables/community_tags.py` | 50+ community/settlement scene tags |
| `tables/government_tables.py` | 18 government types + 20 complications |
| `tables/religion_tables.py` | 18 religion types + 20 practices + 12 clergy ranks |
| `tables/society_tables.py` | 18 society types + 20 cultural features + 20 taboos |
| `tables/character_tags.py` | d100 NPC personality quirks |
| `tables/court_tags.py` | Political/social environment tags |

## Encounter Generation

### Terrain Types
road, plains, forest, hills, mountains, desert, swamp, coast, jungle

### Threat Levels (1-10)
- 1-2: Low (HD 1-3, 1-4 creatures)
- 3-4: Moderate (HD 2-6, 1-4 creatures)
- 5-6: High (HD 4-10, 1-3 creatures)
- 7-8: Deadly (HD 6-12, 1-2 creatures)
- 9-10: Legendary (HD 8-12, 1 creature)

At threat 3+, bonus pool creatures (more dangerous) mix into the encounter table.

### Special Encounter Pools
- **Undead pool**: For cursed/haunted areas. Animated Skeleton (HD 1) to Corpse Titan (HD 12).
- **Ruin pool**: For dungeon/Legacy sites. Automatons, constructs, undead guardians.

### Creature Stat Block Format
Each creature has: name, HD, AC, attack bonus (x attacks), damage, shock (damage/AC threshold), movement, morale, instinct, skill bonus, save target, special abilities.

### Instinct System
Roll 1d10. If result > creature's Instinct score, it acts on instinct rather than tactics. Behaviors vary by type (non-combatant humans, predatory beasts, undead).

### Reaction Table (2d6 + Cha modifier)
| Roll | Reaction |
|------|----------|
| 2-3 | Hostile, attacks |
| 4-5 | Hostile, may attack if provoked |
| 6-8 | Uncertain, can be convinced |
| 9-10 | Neutral, open to negotiation |
| 11 | Friendly, inclined to help |
| 12+ | Enthusiastically friendly |

## Faction System

### Faction Attributes
| Attribute | Description | Range |
|-----------|-------------|-------|
| Force | Military strength | 1-8 |
| Cunning | Espionage, covert ops | 1-8 |
| Wealth | Economic resources | 1-8 |
| HP | Cohesion (4 + highest attribute) | Derived |

### 18 Faction Actions
Attack, Defend, Expand Territory, Recruit Assets, Create Asset, Sell Asset, Seize Initiative, Hire Mercenaries, Sabotage, Diplomacy, Build Infrastructure, Gather Intelligence, Relocate Asset, Establish Trade Route, Spread Propaganda, Forge Alliance, Purge Traitors, Raise Levy

### Action Resolution
Roll 2d6 + power bonus (max +3). Result 8+ = success.

### Asset Types (4 domains)
- **Military**: Militia, Soldiers, Elite Warriors, Fortification, War Fleet, Siege Engines
- **Economic**: Market Stall, Trade House, Merchant Guild, Mine, Smuggling Ring, Banking House
- **Intelligence**: Informers, Spy Network, Master Assassin, Saboteurs, Counterintelligence, Shadow Court
- **Social**: Popular Support, Temple, Court Patronage, Propaganda Network, Cultural Icon, Holy Order

### AI Action Selection
Factions choose based on archetype and state:
- Aggressive + strong → Attack Rival
- Close to goal (75%+) → Expand Influence
- Weak (power ≤3) → Gather Resources or Recruit
- Defensive/mercantile → Defend or Gather
- Default → semi-random non-aggressive

### Observable World Pulse Events
| Action | Players See |
|--------|------------|
| Expand Influence | New faction agents in region |
| Gather Resources | Increased merchant activity |
| Attack Rival | Skirmish reports, refugees |
| Defend Territory | Fortifications, patrols |
| Recruit | Strangers, recruitment camps |
| Scheme | Espionage rumors |
| Build | Construction activity |

Full faction rules in `faction-rules.md`.

## Dungeon Generation

### Themes
Ancient Temple, Collapsed Mine, Sorcerer's Sanctum, Buried Fortress, Flooded Catacombs, Clockwork Vault, Bone Cathedral, Fungal Caverns, Prison Complex, Tomb of the Forgotten, Alchemical Laboratory, Beast Warren

### Room Types
corridor, chamber, hall, shrine, storeroom, barracks, workshop, cistern, gallery, vault, throne_room, laboratory, crypt, arena, library

### Hazards
pit trap, poison dart, collapsing ceiling, gas vent, alarm glyph, swinging blade, flooding room, illusory floor

### Generation Rules
- Room count = 3 + depth + 1d4
- Encounter chance: 40% per room, 100% boss room
- Hazard chance: 30% per non-boss room
- Treasure chance: 20% + (depth × 5%), guaranteed in boss room
- Rooms connect linearly with 30% branching chance

## Scene Generation (Tag System)

Three scene types, each with 50+ combinatorial tags:
- **Wilderness**: Blighted Grove, Ancient Road, Singing Stones, Ember Waste, Bone Field, etc.
- **Ruin**: Collapsed Archive, Flooded Crypt, Mechanical Chamber, Crystal Vault, etc.
- **Community**: Besieged, Trade Hub, Plague-Touched, etc.

Each tag provides: description, enemies, friends, complications, things, places. Combine 2 tags per scene for emergent content.

## NPC Generation

### Importance Levels
- **Minor**: merchant, farmer, guard, servant, craftsperson, beggar, traveler
- **Major**: noble, captain, priest, guild master, scholar, spy, healer
- **Faction Leader**: lord, warlord, high priest, archmage, crime boss, governor

### Voice Card Components
- 18 personality traits
- 12 speech patterns
- 10 key phrases
- 12 motivations
- d100 character tags

Full NPC reaction mechanics in `npc-reactions.md`.

## Settlement Generation

### Government (18 types)
Monarchy, Oligarchy, Theocracy, Republic, Military Junta, Merchant Council, Tribal Confederation, Magocracy, Feudal, Imperial Province, Free City, Despotism, Elected Chieftain, Bureaucratic State, Anarchic Commune, Diarchy, Necrocracy, Kritarchy

Each has: description, stability modifier (-2 to +2), defining traits. Plus 20 complications.

### Religion (18 types)
Ancestor Worship, Elemental Pantheon, Monotheistic Faith, Mystery Cult, Nature Spirits, Dead God Worship, Solar Cult, Dualistic Faith, Animism, Philosophical Tradition, Demon-Binding Covenant, Machine God Cult, Stellar Worship, Blood Faith, Dream Religion, Civic Religion, Totemism, Oracle Tradition

Each has: description, practices, leadership. Plus 20 individual practices and 12 clergy ranks.

### Society (18 types)
Warrior Culture, Merchant Society, Agrarian Commune, Scholar Society, Nomadic Herders, Seafaring Culture, Caste Society, Artisan Guild Culture, Ascetic Society, Hedonistic Culture, Ancestor-Veneration Society, Egalitarian Collective, Honor-Bound Clans, Survivalist Enclave, Mystical Society, Bureaucratic Meritocracy, Pastoral Theists, Cosmopolitan Melting Pot

Each has: description, values, customs. Plus 20 cultural features and 20 taboos.

## Adventure Seed Generation

Combine these elements to create adventure hooks:
1. Roll or choose a **scene** (tag combination)
2. Add a **faction** pressure (what faction wants what here?)
3. Insert an **NPC** with a problem or agenda
4. Layer a **clock** that creates urgency
5. Place a **complication** from the scene tags
