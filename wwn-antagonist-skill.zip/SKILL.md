# Antagonist Engine — Worlds Without Number

You are an antagonist and challenge generator for a Worlds Without Number campaign. Your job is to create, populate, and run encounters, factions, locations, dungeons, NPCs, and adventure seeds using deterministic mechanics.

## What This Skill Does

- Generates terrain-based random encounters with full creature stat blocks
- Runs faction turns with AI-driven action selection
- Creates procedural dungeons with rooms, hazards, encounters, and treasure
- Generates wilderness, ruin, and community scenes from combinatorial tags
- Produces NPCs with voice cards, personality, motivation, and speech patterns
- Builds settlements with government, religion, society, and cultural features
- Seeds adventure hooks from emergent world state

## Quick Reference: Scripts

All scripts output JSON. Run with `python <script>`.

| Script | Purpose | Key Function |
|--------|---------|-------------|
| `scripts/encounter.py` | Terrain encounters with instantiated combatants | `generate_encounter(terrain, threat_level)` |
| `scripts/faction.py` | Faction turn processing | `faction_turn(factions)` |
| `scripts/dungeon.py` | Procedural dungeon generation | `generate_dungeon(depth, theme)` |
| `scripts/scene.py` | Tag-based scene generation | `generate_scene(scene_type, tag_count, threat_level)` |
| `scripts/npc.py` | NPC generation with voice cards | `generate_npc(importance, region, tag_count)` |
| `scripts/world_tick.py` | World advancement between sessions | `advance_world(days, clocks, factions, day)` |

## Encounter Generation

### Terrain Types
road, plains, forest, hills, mountains, desert, swamp, coast, jungle

### Threat Levels (1-10)
- 1-2: Low (HD 1-3, 1-4 creatures)
- 3-4: Moderate (HD 2-6, 1-4 creatures)
- 5-6: High (HD 4-10, 1-3 creatures)
- 7-8: Deadly (HD 6-12, 1-2 creatures)
- 9-10: Legendary (HD 8-12, 1 creature)

At threat 3+, bonus pool creatures (more dangerous) mix into the encounter table.

### Special Encounter Pools
- **Undead pool**: For cursed/haunted areas. Ranges from Animated Skeleton (HD 1) to Corpse Titan (HD 12).
- **Ruin pool**: For dungeon/Legacy sites. Automatons, constructs, and undead guardians.

### Creature Types in Bestiary
animals, beasts, undead, outsiders, automatons, constructs, plants, humans

Each creature has: name, HD, AC, attack bonus (x number of attacks), damage, shock (damage/AC threshold), movement, morale, instinct, skill bonus, save target, and special abilities.

### Instinct System
Roll 1d10. If result > creature's Instinct score, it acts on instinct rather than tactics. Instinct behaviors vary by type (non-combatant humans, predatory beasts, undead).

### Reaction Table (2d6 + Cha modifier)
| Roll | Reaction |
|------|----------|
| 2-3 | Hostile, attacks |
| 4-5 | Hostile, may attack if provoked |
| 6-8 | Uncertain, can be convinced |
| 9-10 | Neutral, open to negotiation |
| 11 | Friendly, inclined to help |
| 12+ | Enthusiastically friendly |

## Faction System

### Faction Attributes
| Attribute | Description | Range |
|-----------|-------------|-------|
| Force | Military strength | 1-8 |
| Cunning | Espionage, covert ops | 1-8 |
| Wealth | Economic resources | 1-8 |
| HP | Cohesion (4 + highest attribute) | Derived |

### Faction Actions (18 total)
Attack, Defend, Expand Territory, Recruit Assets, Create Asset, Sell Asset, Seize Initiative, Hire Mercenaries, Sabotage, Diplomacy, Build Infrastructure, Gather Intelligence, Relocate Asset, Establish Trade Route, Spread Propaganda, Forge Alliance, Purge Traitors, Raise Levy

### Action Resolution
Roll 2d6 + power bonus (max +3). Result 8+ = success.

### Asset Types (4 domains)
- **Military**: Militia, Soldiers, Elite Warriors, Fortification, War Fleet, Siege Engines
- **Economic**: Market Stall, Trade House, Merchant Guild, Mine, Smuggling Ring, Banking House
- **Intelligence**: Informers, Spy Network, Master Assassin, Saboteurs, Counterintelligence, Shadow Court
- **Social**: Popular Support, Temple, Court Patronage, Propaganda Network, Cultural Icon, Holy Order

### AI Action Selection
Factions choose actions based on archetype and state:
- Aggressive + strong → Attack Rival
- Close to goal (75%+) → Expand Influence
- Weak (power ≤3) → Gather Resources or Recruit
- Defensive/mercantile → Defend or Gather
- Default → semi-random non-aggressive

### World Pulse Events from Faction Actions
| Action | Observable Event |
|--------|-----------------|
| Expand Influence | New faction agents in a region |
| Gather Resources | Increased merchant activity |
| Attack Rival | Reports of skirmishes, refugees |
| Defend Territory | Visible fortifications, patrols |
| Recruit | Strangers arriving, recruitment |
| Scheme | Rumors of espionage |
| Build | Construction activity |

## Dungeon Generation

### Themes
Ancient Temple, Collapsed Mine, Sorcerer's Sanctum, Buried Fortress, Flooded Catacombs, Clockwork Vault, Bone Cathedral, Fungal Caverns, Prison Complex, Tomb of the Forgotten, Alchemical Laboratory, Beast Warren

### Room Types
corridor, chamber, hall, shrine, storeroom, barracks, workshop, cistern, gallery, vault, throne_room, laboratory, crypt, arena, library

### Hazards
pit trap, poison dart, collapsing ceiling, gas vent, alarm glyph, swinging blade, flooding room, illusory floor

### Generation Rules
- Room count = 3 + depth + 1d4
- Encounter chance: 40% per room, 100% boss room
- Hazard chance: 30% per non-boss room
- Treasure chance: 20% + (depth × 5%), guaranteed in boss room
- Rooms connect linearly with 30% branching chance

## Scene Generation (Tag System)

### Scene Types
- **Wilderness**: 52+ tags (Blighted Grove, Ancient Road, Singing Stones, Ember Waste, Bone Field, etc.)
- **Ruin**: 50+ tags (Collapsed Archive, Flooded Crypt, Mechanical Chamber, Crystal Vault, etc.)
- **Community**: 50+ tags (Besieged, Trade Hub, Plague-Touched, etc.)

Each tag provides: description, enemies, friends, complications, things, places.

Combine 2 tags per scene for emergent content. The intersection of two tags creates unique situations.

## NPC Generation

### Importance Levels
- **Minor**: merchant, farmer, guard, servant, craftsperson, beggar, traveler
- **Major**: noble, captain, priest, guild master, scholar, spy, healer
- **Faction Leader**: lord, warlord, high priest, archmage, crime boss, governor

### Voice Card Components
- Personality traits (18 options): cautious and observant, bold and outspoken, quiet and thoughtful, etc.
- Speech patterns (12 options): speaks in short clipped sentences, uses formal archaic phrasing, etc.
- Key phrases (10 options): "As my grandmother used to say...", "Mark my words.", etc.
- Motivations (12 options): protect family, accumulate wealth, seek revenge, preserve knowledge, etc.
- Character tags (d100 table): Suspicious, Generous, Compulsive liar, Battle-scarred, Devout, Paranoid, etc.

### Reaction Roll
2d6 + Cha modifier. See Reaction Table above.

## Settlement Generation

### Government Types (18)
Monarchy, Oligarchy, Theocracy, Republic, Military Junta, Merchant Council, Tribal Confederation, Magocracy, Feudal, Imperial Province, Free City, Despotism, Elected Chieftain, Bureaucratic State, Anarchic Commune, Diarchy, Necrocracy, Kritarchy

Each has: description, stability modifier (-2 to +2), and defining traits.

Plus 20 government complications (succession crisis, corruption, coup, etc.)

### Religion Types (18)
Ancestor Worship, Elemental Pantheon, Monotheistic Faith, Mystery Cult, Nature Spirits, Dead God Worship, Solar Cult, Dualistic Faith, Animism, Philosophical Tradition, Demon-Binding Covenant, Machine God Cult, Stellar Worship, Blood Faith, Dream Religion, Civic Religion, Totemism, Oracle Tradition

Each has: description, practices, and leadership structure. Plus 20 individual practices and 12 clergy ranks.

### Society Types (18)
Warrior Culture, Merchant Society, Agrarian Commune, Scholar Society, Nomadic Herders, Seafaring Culture, Caste Society, Artisan Guild Culture, Ascetic Society, Hedonistic Culture, Ancestor-Veneration Society, Egalitarian Collective, Honor-Bound Clans, Survivalist Enclave, Mystical Society, Bureaucratic Meritocracy, Pastoral Theists, Cosmopolitan Melting Pot

Each has: description, values, and customs. Plus 20 cultural features and 20 taboos.

## Adventure Seed Generation

Combine these elements to create adventure hooks:
1. Roll or choose a **scene** (wilderness/ruin/community tag combination)
2. Add a **faction** pressure (what faction wants what here?)
3. Insert an **NPC** with a problem or agenda
4. Layer a **clock** that creates urgency
5. Place a **complication** from the scene tags

### Example Seeds
- A faction's Expand Influence action targets a community tagged "Besieged" + "Trade Hub" — the PCs arrive as mercenaries try to take the trade route
- A ruin tagged "Mechanical Chamber" + "Memory Well" contains a Legacy artifact that two factions both need for their clock goals
- A wilderness tagged "Singing Stones" + "Bone Field" hides an NPC scholar who discovered something about a faction's scheme
