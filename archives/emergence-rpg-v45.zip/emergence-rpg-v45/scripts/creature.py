"""
EMERGENCE: THE EXILE — Creature Generation
Procedural creature stat blocks with encounter context from tables.
"""

import random
from typing import Optional, List, Dict

try:
    from .dice import generate_id, roll_on_table, weighted_choice
except ImportError:
    from dice import generate_id, roll_on_table, weighted_choice

# Tables integration (graceful fallback)
try:
    import sys, os
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _parent_dir = os.path.dirname(_script_dir)
    if _parent_dir not in sys.path:
        sys.path.insert(0, _parent_dir)
    from tables.encounter_context import get_encounter_context
    TABLES_AVAILABLE = True
except ImportError:
    TABLES_AVAILABLE = False

# ═══════════════════════════════════════════════════════════════════════════════
# CREATURE BASES
# ═══════════════════════════════════════════════════════════════════════════════

CREATURE_BASES = {
    "wolf": {"hp_mult": 0.8, "dmg_mult": 1.0, "def_mod": 0, "speed": "fast", "pack": True, "int_range": (3, 6), "attack_type": "bite/claw", "size": "medium"},
    "bear": {"hp_mult": 1.5, "dmg_mult": 1.3, "def_mod": 2, "speed": "medium", "pack": False, "int_range": (2, 5), "attack_type": "claw/bite", "size": "large"},
    "spider": {"hp_mult": 0.6, "dmg_mult": 0.8, "def_mod": -1, "speed": "medium", "pack": True, "int_range": (1, 3), "attack_type": "bite/web", "size": "medium"},
    "serpent": {"hp_mult": 0.7, "dmg_mult": 1.1, "def_mod": 1, "speed": "fast", "pack": False, "int_range": (2, 4), "attack_type": "bite/constrict", "size": "large"},
    "drake": {"hp_mult": 2.0, "dmg_mult": 1.5, "def_mod": 4, "speed": "medium", "pack": False, "int_range": (6, 12), "attack_type": "bite/claw/breath", "size": "huge"},
    "insect": {"hp_mult": 0.4, "dmg_mult": 0.6, "def_mod": -2, "speed": "fast", "pack": True, "int_range": (1, 2), "attack_type": "mandible/sting", "size": "small"},
    "bird": {"hp_mult": 0.5, "dmg_mult": 0.9, "def_mod": 2, "speed": "fast", "pack": True, "int_range": (2, 5), "attack_type": "talons/beak", "size": "medium"},
    "elemental": {"hp_mult": 1.3, "dmg_mult": 1.2, "def_mod": 3, "speed": "slow", "pack": False, "int_range": (4, 8), "attack_type": "slam/aura", "size": "large"},
    "undead": {"hp_mult": 1.2, "dmg_mult": 0.9, "def_mod": 1, "speed": "slow", "pack": True, "int_range": (1, 4), "attack_type": "claw/bite", "size": "medium"},
    "aberration": {"hp_mult": 1.0, "dmg_mult": 1.1, "def_mod": 0, "speed": "medium", "pack": False, "int_range": (8, 16), "attack_type": "tentacle/psychic", "size": "large"},
    "humanoid": {"hp_mult": 1.0, "dmg_mult": 1.0, "def_mod": 0, "speed": "medium", "pack": True, "int_range": (8, 14), "attack_type": "weapon", "size": "medium"},
}

CREATURE_SUFFIXES = {
    "wolf": ["Wolf", "Hound", "Warg", "Stalker", "Howler"],
    "bear": ["Bear", "Ursine", "Mauler", "Brute", "Colossus"],
    "spider": ["Spider", "Weaver", "Crawler", "Spinner", "Lurker"],
    "serpent": ["Serpent", "Viper", "Constrictor", "Coil", "Wyrm"],
    "drake": ["Drake", "Wyvern", "Draconian", "Scale-lord", "Firemaw"],
    "insect": ["Swarm", "Hive-drone", "Chitinous", "Stinger", "Mantis"],
    "bird": ["Hawk", "Roc", "Raptor", "Screamer", "Talon"],
    "elemental": ["Golem", "Elemental", "Titan", "Colossus", "Warden"],
    "undead": ["Zombie", "Revenant", "Wraith", "Ghoul", "Risen"],
    "aberration": ["Horror", "Abomination", "Mind-eater", "Void-thing", "Anomaly"],
    "humanoid": ["Warrior", "Raider", "Scout", "Berserker", "Champion"],
}

REGIONAL_PREFIXES = {
    "forest": {"prefixes": ["Thornwood", "Greenblood", "Mossfang", "Rootborn", "Canopy"], "hp_mod": 0, "dmg_mod": 0, "def_mod": 0, "creature_weights": {"wolf": 30, "bear": 15, "spider": 25, "bird": 15, "insect": 10, "serpent": 5}, "common_abilities": ["ambush", "camouflage", "pack_tactics"]},
    "plains": {"prefixes": ["Dustmane", "Steppe", "Goldgrass", "Windborn", "Horizon"], "hp_mod": 0, "dmg_mod": 1, "def_mod": -1, "creature_weights": {"wolf": 25, "bird": 25, "insect": 20, "bear": 10, "serpent": 10, "humanoid": 10}, "common_abilities": ["charge", "pack_tactics", "trample"]},
    "mountain": {"prefixes": ["Ironpeak", "Stonehorn", "Cloudreach", "Cragborn", "Frostjaw"], "hp_mod": 1, "dmg_mod": 1, "def_mod": 1, "creature_weights": {"bear": 25, "drake": 15, "bird": 20, "elemental": 15, "wolf": 15, "serpent": 10}, "common_abilities": ["rock_throw", "charge", "roar"]},
    "swamp": {"prefixes": ["Rotmire", "Bogblood", "Murkvein", "Fenscale", "Miasma"], "hp_mod": 0, "dmg_mod": 0, "def_mod": 0, "creature_weights": {"serpent": 25, "insect": 25, "spider": 20, "undead": 15, "aberration": 10, "wolf": 5}, "common_abilities": ["poison", "camouflage", "grapple"]},
    "ruins": {"prefixes": ["Ashfall", "Rubble", "Hollowed", "Shattered", "Ghostwall"], "hp_mod": 0, "dmg_mod": 0, "def_mod": 1, "creature_weights": {"undead": 30, "spider": 15, "humanoid": 20, "aberration": 15, "insect": 10, "wolf": 10}, "common_abilities": ["ambush", "fear_aura", "life_drain"]},
    "crystal": {"prefixes": ["Prismatic", "Shardborn", "Resonant", "Crystalblood", "Faceted"], "hp_mod": 1, "dmg_mod": 1, "def_mod": 2, "creature_weights": {"elemental": 35, "aberration": 25, "drake": 15, "insect": 15, "spider": 10}, "common_abilities": ["mana_drain", "regeneration", "aura_damage"]},
    "shadow": {"prefixes": ["Voidtouched", "Nightborn", "Eclipse", "Umbral", "Abyssal"], "hp_mod": 0, "dmg_mod": 2, "def_mod": 0, "creature_weights": {"aberration": 30, "undead": 25, "serpent": 15, "wolf": 10, "elemental": 10, "spider": 10}, "common_abilities": ["fear_aura", "life_drain", "mana_drain", "camouflage"]},
}

ABILITIES = {
    "pack_tactics": {"name": "Pack Tactics", "effect": "+2 attack when ally is adjacent to target", "type": "passive"},
    "ambush": {"name": "Ambush", "effect": "If hidden at combat start, first attack deals +50% damage", "type": "passive"},
    "charge": {"name": "Charge", "effect": "If moves 4+ meters before attack, +2 damage and target saves or is knocked prone", "type": "action"},
    "camouflage": {"name": "Camouflage", "effect": "Advantage on stealth in native terrain. DC 14 Perception to spot.", "type": "passive"},
    "poison": {"name": "Poison", "effect": "On hit, target saves FOR DC 12 or takes 1d6 poison damage per round for 3 rounds", "type": "rider"},
    "regeneration": {"name": "Regeneration", "effect": "Heals 1d6 HP at start of each turn unless hit by fire", "type": "passive"},
    "multi_attack": {"name": "Multi-Attack", "effect": "Makes two attacks per action instead of one", "type": "action"},
    "roar": {"name": "Roar", "effect": "All enemies within 6m save WIL DC 13 or Frightened for 1 round", "type": "action"},
    "grapple": {"name": "Grapple", "effect": "On hit, target is grappled. MIG DC 14 to escape.", "type": "rider"},
    "trample": {"name": "Trample", "effect": "Move through enemy space. Target saves DEF or takes damage and is prone.", "type": "action"},
    "breath_weapon": {"name": "Breath Weapon", "effect": "3d8 damage in 6m cone, DEF save for half. Recharge on 5-6 each round.", "type": "action"},
    "fear_aura": {"name": "Fear Aura", "effect": "Enemies within 6m save WIL DC 14 at start of turn or Frightened", "type": "passive"},
    "aura_damage": {"name": "Damaging Aura", "effect": "1d4 damage to all creatures within 3m at start of creature's turn", "type": "passive"},
    "rock_throw": {"name": "Rock Throw", "effect": "Ranged attack (15m). 2d8 damage.", "type": "action"},
    "life_drain": {"name": "Life Drain", "effect": "On hit, heal HP equal to half damage dealt", "type": "rider"},
    "mana_drain": {"name": "Mana Drain", "effect": "On hit, target loses 1d6 Mana. Creature gains temp HP equal to mana drained.", "type": "rider"},
    "web": {"name": "Web", "effect": "Ranged attack. Target restrained. DC 12 STR to break free.", "type": "action"},
    "burrow": {"name": "Burrow", "effect": "Can burrow through earth at half speed. Emerge as ambush.", "type": "movement"},
    "shatter": {"name": "Shatter", "effect": "On death, explode for 2d6 damage in 5m radius, DEF save for half", "type": "passive"},
}

THREAT_MULTIPLIERS = {
    "minion": {"hp": 0.5, "dmg": 0.7, "def": -2, "atk": -1, "abilities": 0, "actions": 1},
    "standard": {"hp": 1.0, "dmg": 1.0, "def": 0, "atk": 0, "abilities": 1, "actions": 2},
    "elite": {"hp": 1.5, "dmg": 1.3, "def": 2, "atk": 2, "abilities": 2, "actions": 3},
    "boss": {"hp": 3.0, "dmg": 1.5, "def": 3, "atk": 3, "abilities": 3, "actions": 4},
    "legendary": {"hp": 5.0, "dmg": 2.0, "def": 4, "atk": 4, "abilities": 4, "actions": 4},
}


def get_behavior(intelligence: int, is_pack: bool) -> dict:
    if intelligence <= 2:
        return {"type": "mindless", "pattern": "Attacks nearest target. No self-preservation. Ignores tactics.", "intelligence": intelligence}
    elif intelligence <= 4:
        pattern = "Attacks whoever hurt it. Tests prey before committing. Flees when bloodied and alone."
        if is_pack:
            pattern += " Coordinates with pack—flanks, rotates wounded to back."
        return {"type": "bestial", "pattern": pattern, "intelligence": intelligence}
    elif intelligence <= 8:
        pattern = "Targets wounded/casters. Uses terrain for advantage. Retreats if outmatched."
        if is_pack:
            pattern += " Alpha directs pack. Will sacrifice minions."
        return {"type": "cunning", "pattern": pattern, "intelligence": intelligence}
    elif intelligence <= 12:
        return {"type": "intelligent", "pattern": "Analyzes threats. Exploits weaknesses. Calls reinforcements. May parley.", "intelligence": intelligence}
    else:
        return {"type": "genius", "pattern": "Pre-positions traps. Counter-builds party tactics. Psychological warfare. Has escape plan.", "intelligence": intelligence}


def generate_creature(
    level: int, threat: str = "standard", region: str = None,
    creature_type: str = None, name: str = None,
    terrain: str = None, time_of_day: str = "day",
) -> dict:
    """Generate a procedural creature with encounter context from tables."""
    if region is None:
        region = random.choice(list(REGIONAL_PREFIXES.keys()))
    region_data = REGIONAL_PREFIXES.get(region, REGIONAL_PREFIXES["forest"])

    if creature_type is None:
        weights = region_data.get("creature_weights", {"wolf": 1})
        options = [(k, v) for k, v in weights.items()]
        creature_type = weighted_choice(options)

    base = CREATURE_BASES.get(creature_type, CREATURE_BASES["wolf"])
    threat_mods = THREAT_MULTIPLIERS.get(threat.lower(), THREAT_MULTIPLIERS["standard"])

    if name is None:
        prefix = random.choice(region_data["prefixes"])
        suffix = random.choice(CREATURE_SUFFIXES.get(creature_type, ["Beast"]))
        name = f"{prefix} {suffix}"
        if threat.lower() in ["elite", "boss", "legendary"]:
            name = f"{random.choice(['Alpha', 'Ancient', 'Dire', 'Greater', 'Elder', 'Primal'])} {name}"

    base_hp = 10 + (level * 8)
    hp = int(int(base_hp * base["hp_mult"]) + region_data["hp_mod"] * level)
    damage = int(int((4 + int(level * 1.5)) * base["dmg_mult"]) + region_data["dmg_mod"])
    defense = 10 + (level // 2) + base["def_mod"] + region_data["def_mod"]
    hp = int(hp * threat_mods["hp"])
    damage = int(damage * threat_mods["dmg"])
    defense += threat_mods["def"]
    attack = level + 2 + threat_mods["atk"]
    armor = max(0, level // 3)

    speed_init = {"stationary": -2, "slow": 0, "medium": 2, "fast": 4}
    initiative = random.randint(1, 4) + (level // 3) + speed_init.get(base["speed"], 0)
    intelligence = random.randint(*base["int_range"])
    behavior = get_behavior(intelligence, base["pack"])

    available_abilities = list(set(region_data["common_abilities"].copy() +
        (["pack_tactics"] if base["pack"] else []) +
        (["breath_weapon"] if creature_type == "drake" else []) +
        (["web"] if creature_type == "spider" else []) +
        (["ambush"] if base["speed"] == "fast" else []) +
        (["multi_attack"] if threat.lower() in ["elite", "boss", "legendary"] else [])
    ))
    random.shuffle(available_abilities)
    selected_abilities = [ABILITIES[k].copy() for k in available_abilities[:threat_mods["abilities"]] if k in ABILITIES]

    movement = {"stationary": 0, "slow": 4, "medium": 6, "fast": 10}.get(base["speed"], 6)
    loot_tier = {"minion": "minion", "standard": "standard", "elite": "elite", "boss": "boss", "legendary": "boss"}.get(threat.lower(), "standard")

    # ── TABLES: Encounter Context ──
    encounter_context = None
    if TABLES_AVAILABLE:
        valid_terrains = ["urban", "forest", "ruins", "swamp", "mountain", "plains", "crystal", "shadow"]
        ctx_terrain = (terrain or region) if (terrain or region) in valid_terrains else None
        threat_map = {"minion": 1, "standard": 2, "elite": 3, "boss": 4, "legendary": 5}
        encounter_context = get_encounter_context(
            terrain=ctx_terrain, is_pack=base["pack"], intelligence=intelligence,
            threat_level=threat_map.get(threat.lower(), 2), time_of_day=time_of_day,
        )

    return {
        "name": name, "level": level, "threat": threat, "region": region, "creature_type": creature_type,
        "hp": {"current": hp, "max": hp}, "armor": armor, "attack": attack, "damage": damage,
        "defense": defense, "initiative": initiative, "movement": movement,
        "actions_per_turn": threat_mods["actions"], "intelligence": intelligence,
        "behavior": behavior, "abilities": selected_abilities, "is_pack": base["pack"],
        "loot_tier": loot_tier, "conditions": [], "zone": None, "telegraph": None,
        "encounter_context": encounter_context,
    }


def generate_creature_group(level: int, region: str, difficulty: str = "medium", terrain: str = None, time_of_day: str = "day") -> List[dict]:
    """Generate a balanced encounter group with encounter context."""
    region_data = REGIONAL_PREFIXES.get(region, REGIONAL_PREFIXES["forest"])
    weights = region_data.get("creature_weights", {"wolf": 1})
    base_type = weighted_choice([(k, v) for k, v in weights.items()])
    is_pack = CREATURE_BASES[base_type]["pack"]
    ctx = {"terrain": terrain, "time_of_day": time_of_day}
    creatures = []

    if difficulty == "easy":
        if is_pack:
            for _ in range(random.randint(2, 3)):
                creatures.append(generate_creature(max(1, level - 1), "minion", region, base_type, **ctx))
        else:
            creatures.append(generate_creature(max(1, level - 2), "standard", region, base_type, **ctx))
    elif difficulty == "medium":
        if is_pack:
            for _ in range(random.randint(2, 4)):
                creatures.append(generate_creature(level, "standard", region, base_type, **ctx))
        else:
            creatures.append(generate_creature(level, "standard", region, base_type, **ctx))
            if random.random() < 0.3:
                creatures.append(generate_creature(max(1, level - 1), "minion", region, **ctx))
    elif difficulty == "hard":
        if is_pack:
            creatures.append(generate_creature(level + 1, "elite", region, base_type, **ctx))
            for _ in range(random.randint(2, 4)):
                creatures.append(generate_creature(max(1, level - 1), "minion", region, base_type, **ctx))
        else:
            if random.random() < 0.5:
                creatures.append(generate_creature(level + 1, "elite", region, base_type, **ctx))
            else:
                creatures.append(generate_creature(level, "standard", region, base_type, **ctx))
                creatures.append(generate_creature(level, "standard", region, base_type, **ctx))
    elif difficulty == "deadly":
        creatures.append(generate_creature(level + 2, "boss", region, base_type, **ctx))
        for _ in range(random.randint(2, 4)):
            creatures.append(generate_creature(max(1, level - 1), "minion", region, base_type, **ctx))

    return creatures


if __name__ == "__main__":
    print(f"=== CREATURE GENERATION TEST (tables={TABLES_AVAILABLE}) ===\n")
    c = generate_creature(3, "standard", "forest", time_of_day="dusk")
    print(f"**{c['name']}** Lv{c['level']} {c['threat']} | HP {c['hp']['max']} DEF {c['defense']} ATK +{c['attack']} DMG {c['damage']}")
    if c.get("encounter_context"):
        ec = c["encounter_context"]
        print(f"  Activity: {ec['activity']}")
        print(f"  Mood: {ec['mood']}")
        if ec.get('problem'): print(f"  Problem: {ec['problem']}")
        if ec.get('complication'): print(f"  Complication: {ec['complication']}")
