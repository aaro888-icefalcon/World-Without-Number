"""
EMERGENCE: THE EXILE — Scene Generation
Orchestrates creature, NPC, and zone generation with environmental detail from tables.
"""

import random
from typing import Optional, List, Dict

try:
    from .dice import generate_id, roll_on_table, weighted_choice
    from .creature import generate_creature, generate_creature_group
    from .npc import generate_quick_npc, generate_awakened_npc
    from .faction import format_clock_display
except ImportError:
    from dice import generate_id, roll_on_table, weighted_choice
    from creature import generate_creature, generate_creature_group
    from npc import generate_quick_npc, generate_awakened_npc
    from faction import format_clock_display

# Tables integration (graceful fallback)
try:
    import sys, os
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _parent_dir = os.path.dirname(_script_dir)
    if _parent_dir not in sys.path:
        sys.path.insert(0, _parent_dir)
    from tables.environmental_detail import get_environmental_objects, get_discovery, get_atmosphere
    TABLES_AVAILABLE = True
except ImportError:
    TABLES_AVAILABLE = False

# ═══════════════════════════════════════════════════════════════════════════════
# SCENE TYPES
# ═══════════════════════════════════════════════════════════════════════════════

SCENE_TYPES = {
    "exploration": {"description": "Traversing/investigating an area", "encounter_weights": {"clear": 30, "combat": 25, "social": 20, "environmental": 15, "discovery": 10}},
    "travel": {"description": "Moving between locations", "encounter_weights": {"clear": 40, "combat": 30, "social": 10, "environmental": 15, "discovery": 5}},
    "social": {"description": "Interacting with faction/settlement", "encounter_weights": {"clear": 20, "combat": 10, "social": 50, "environmental": 5, "discovery": 15}},
    "danger_zone": {"description": "Known hostile territory", "encounter_weights": {"clear": 10, "combat": 50, "social": 5, "environmental": 25, "discovery": 10}},
    "safe_zone": {"description": "Established safe area", "encounter_weights": {"clear": 60, "combat": 5, "social": 25, "environmental": 5, "discovery": 5}},
}

# ═══════════════════════════════════════════════════════════════════════════════
# TERRAIN AND ZONES
# ═══════════════════════════════════════════════════════════════════════════════

TERRAIN_TYPES = {
    "urban": {"zones": ["Street", "Alley", "Building Interior", "Rooftop", "Parking Lot", "Intersection"], "properties": ["Cover (debris)", "Elevation (stairs)", "Choke Point (doorway)", "Open Ground"], "hazards": ["Unstable floor", "Broken glass", "Collapsed ceiling", "Fire"]},
    "forest": {"zones": ["Dense Trees", "Clearing", "Stream", "Fallen Log", "Thicket", "Rocky Outcrop"], "properties": ["Cover (trees)", "Difficult Terrain", "Concealment", "High Ground"], "hazards": ["Pitfall", "Thornbush", "Quicksand", "Predator territory"]},
    "plains": {"zones": ["Open Field", "Tall Grass", "Hill", "Boulder", "Dried Creek", "Animal Trail"], "properties": ["No Cover", "Concealment (grass)", "High Ground", "Clear Sight Lines"], "hazards": ["Stampede path", "Sinkhole", "Nest", "Territorial marker"]},
    "ruins": {"zones": ["Collapsed Hall", "Standing Wall", "Basement", "Courtyard", "Tower Base", "Rubble Pile"], "properties": ["Cover", "Unstable", "Darkness", "Echoing"], "hazards": ["Collapse risk", "Undead stirring", "Trapped", "Cursed ground"]},
    "mountain": {"zones": ["Narrow Path", "Ledge", "Cave Mouth", "Boulder Field", "Cliff Face", "Summit"], "properties": ["Elevation", "Exposed", "Choke Point", "Fall Risk"], "hazards": ["Rockslide", "Thin air", "Ice", "Territorial predator"]},
    "swamp": {"zones": ["Solid Ground", "Shallow Water", "Deep Mire", "Dead Tree", "Fog Bank", "Island"], "properties": ["Difficult Terrain", "Concealment", "Hazardous Footing", "Disease Risk"], "hazards": ["Quicksand", "Leeches", "Toxic gas", "Ambush predator"]},
}

# Fallback objects (used when tables not available)
FALLBACK_OBJECTS = [
    {"name": "Supply cache", "interaction": "Search DC 12", "contents": "Random supplies"},
    {"name": "Collapsed structure", "interaction": "Athletics DC 14 to clear", "contents": "Passage"},
    {"name": "Strange markings", "interaction": "INT check DC 13", "contents": "Information about area"},
    {"name": "Fresh tracks", "interaction": "Survival DC 11", "contents": "Track source"},
    {"name": "Damaged vehicle", "interaction": "Repair DC 15", "contents": "Parts or transport"},
]

FALLBACK_DISCOVERIES = [
    {"name": "Abandoned camp", "check": "Investigation DC 12", "reward": "Supplies + information"},
    {"name": "Hidden cache", "check": "Perception DC 14", "reward": "Equipment"},
    {"name": "Survivor shelter", "check": "None (obvious)", "reward": "NPC contact + rest spot"},
    {"name": "Monster corpse", "check": "Survival DC 11", "reward": "Monster parts"},
    {"name": "Pre-Transit technology", "check": "INT DC 13", "reward": "Useful device"},
    {"name": "Skill Stone location", "check": "Perception DC 16", "reward": "Possible Skill Stone"},
]


def generate_zones(terrain: str, num_zones: int = 4, has_combat: bool = False) -> List[dict]:
    terrain_data = TERRAIN_TYPES.get(terrain, TERRAIN_TYPES["urban"])
    available = terrain_data["zones"].copy()
    random.shuffle(available)
    zone_names = available[:num_zones]

    zones = []
    for i, name in enumerate(zone_names):
        num_props = random.randint(1, 2)
        props = random.sample(terrain_data["properties"], min(num_props, len(terrain_data["properties"])))
        hazard = random.choice(terrain_data["hazards"]) if random.random() < (0.3 if has_combat else 0.1) else None
        zones.append({"id": f"zone_{chr(65 + i)}", "name": name, "properties": props,
                      "hazard": hazard, "occupants": [], "connections": []})

    for i, zone in enumerate(zones):
        for j, other in enumerate(zones):
            if i != j:
                zone["connections"].append({"target": other["id"], "distance": abs(i - j) * 4 + random.randint(2, 6)})
    return zones


def format_zone_matrix(zones: List[dict]) -> str:
    lines = ["### Zone Distance Matrix"]
    lines.append("|   |" + "".join(f" {z['id'][-1]} |" for z in zones))
    lines.append("|---|" + "".join("---|" for _ in zones))
    for zone in zones:
        row = f"| **{zone['id'][-1]}** |"
        for other in zones:
            if zone['id'] == other['id']:
                row += " — |"
            else:
                dist = next((c['distance'] for c in zone['connections'] if c['target'] == other['id']), "?")
                row += f" {dist}m |"
        lines.append(row)
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# ENCOUNTER DETERMINATION
# ═══════════════════════════════════════════════════════════════════════════════

def determine_encounter_type(scene_type: str, threat_level: int, clock_pressure: int = 0, time_of_day: str = "day") -> str:
    scene_data = SCENE_TYPES.get(scene_type, SCENE_TYPES["exploration"])
    weights = scene_data["encounter_weights"].copy()
    if threat_level >= 4:
        weights["combat"] = int(weights["combat"] * 1.5)
        weights["clear"] = int(weights["clear"] * 0.5)
    elif threat_level >= 2:
        weights["combat"] = int(weights["combat"] * 1.2)
    if clock_pressure > 50:
        weights["combat"] = int(weights["combat"] * 1.3)
        weights["environmental"] = int(weights["environmental"] * 1.2)
    if time_of_day == "night":
        weights["combat"] = int(weights["combat"] * 1.4)
        weights["social"] = int(weights["social"] * 0.5)
    elif time_of_day in ["dusk", "dawn"]:
        weights["combat"] = int(weights["combat"] * 1.2)
    return weighted_choice([(k, v) for k, v in weights.items()])


# ═══════════════════════════════════════════════════════════════════════════════
# SCENE GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

def generate_scene(location: dict, world_state: dict, player_level: int,
                   scene_type: str = None, force_encounter: str = None) -> dict:
    """Generate a complete scene with environmental detail from tables."""
    loc_name = location.get("name", "Unknown Location")
    region = location.get("region", "urban")
    terrain = location.get("terrain", region)
    threat_level = location.get("threat_level", 2)
    current_day = world_state.get("current_day", 1)
    current_time = world_state.get("current_time", "12:00")

    hour = int(current_time.split(":")[0]) if ":" in str(current_time) else 12
    time_of_day = "dawn" if 6 <= hour < 8 else "day" if 8 <= hour < 18 else "dusk" if 18 <= hour < 20 else "night"

    clock_pressure = 0
    relevant_clocks = []
    for clock in world_state.get("clocks", []):
        if clock.get("max", 1) > 0:
            pct = (clock.get("current", 0) / clock["max"]) * 100
            clock_pressure += pct
            if pct >= 50:
                relevant_clocks.append(clock)

    if scene_type is None:
        scene_type = "danger_zone" if threat_level >= 4 else "safe_zone" if threat_level <= 1 else "exploration"

    encounter_type = force_encounter or determine_encounter_type(scene_type, threat_level, clock_pressure, time_of_day)

    weather = random.choice(["clear", "clear", "clear", "overcast", "overcast", "light rain", "fog", "storm"])
    if time_of_day == "night":
        lighting = "dark" if weather in ["clear", "overcast"] else "pitch black"
    elif time_of_day in ["dusk", "dawn"] or weather in ["fog", "storm"]:
        lighting = "dim"
    else:
        lighting = "daylight"

    has_combat = encounter_type == "combat"
    zones = generate_zones(terrain, 4 if has_combat else random.randint(2, 4), has_combat)

    # ── TABLES: Atmosphere ──
    atmosphere = None
    if TABLES_AVAILABLE:
        atmosphere = get_atmosphere(terrain)

    scene = {
        "id": generate_id("scene_"),
        "name": f"{loc_name} - {scene_type.replace('_', ' ').title()}",
        "location": loc_name, "region": region, "terrain": terrain,
        "threat_level": threat_level, "scene_type": scene_type,
        "encounter_type": encounter_type,
        "time": {"day": current_day, "time": current_time, "time_of_day": time_of_day},
        "conditions": {"weather": weather, "lighting": lighting},
        "atmosphere": atmosphere,  # NEW: {sound, smell, sight}
        "zones": zones, "zone_matrix": format_zone_matrix(zones),
        "npcs": [], "enemies": [], "objects": [], "secrets": [],
        "upcoming_events": [], "relevant_clocks": [], "combat_state": None,
    }

    if encounter_type == "combat":
        _populate_combat_encounter(scene, player_level, region, world_state, terrain, time_of_day)
    elif encounter_type == "social":
        _populate_social_encounter(scene, world_state)
    elif encounter_type == "environmental":
        _populate_environmental_encounter(scene, terrain, threat_level)
    elif encounter_type == "discovery":
        _populate_discovery_encounter(scene, terrain, threat_level)

    for clock in relevant_clocks:
        scene["relevant_clocks"].append({"name": clock["name"], "display": format_clock_display(clock), "effect": clock.get("goal", "Unknown")})

    _generate_secrets(scene, world_state, encounter_type)
    return scene


def _populate_combat_encounter(scene: dict, player_level: int, region: str,
                                world_state: dict, terrain: str = None, time_of_day: str = "day"):
    """Add enemies with encounter context to a combat scene."""
    threat_level = scene["threat_level"]
    difficulty = {0: "easy", 1: "easy", 2: "medium", 3: "medium", 4: "hard", 5: "deadly"}.get(threat_level, "medium")

    external_threats = world_state.get("external_threats", [])
    spawning_threat = None
    for threat in external_threats:
        clock = threat.get("clock", {})
        if clock.get("current", 0) >= clock.get("max", 99) * 0.6:
            if threat.get("region") == region or random.random() < 0.3:
                spawning_threat = threat
                break

    # Pass terrain and time_of_day so creatures get encounter context
    enemies = generate_creature_group(player_level, region, difficulty, terrain=terrain, time_of_day=time_of_day)

    if spawning_threat:
        scene["secrets"].append({"type": "threat_connection",
            "content": f"These creatures are connected to {spawning_threat['name']}. Clock may advance."})

    for i, enemy in enumerate(enemies):
        zone_idx = i % len(scene["zones"])
        enemy["zone"] = scene["zones"][zone_idx]["id"]
        scene["zones"][zone_idx]["occupants"].append(enemy["name"])

    scene["enemies"] = enemies
    scene["combat_state"] = {"round": 0, "phase": "pre-combat", "initiative_order": [], "current_turn": None}
    scene["upcoming_events"].append({"trigger": "Player detected or approaches", "event": "Combat begins. Roll initiative."})


def _populate_social_encounter(scene: dict, world_state: dict):
    """Add NPCs with deep character tags to a social scene."""
    human_factions = world_state.get("human_factions", [])
    if human_factions:
        present_factions = random.sample(human_factions, min(2, len(human_factions)))
        for faction in present_factions:
            for _ in range(random.randint(1, 3)):
                npc = generate_quick_npc(
                    faction_id=faction.get("id"), faction_name=faction.get("name"),
                    faction_archetype=faction.get("archetype"),
                )
                scene["npcs"].append(npc)
    else:
        for _ in range(random.randint(1, 4)):
            scene["npcs"].append(generate_quick_npc())

    for i, npc in enumerate(scene["npcs"]):
        zone_idx = i % len(scene["zones"])
        npc["zone"] = scene["zones"][zone_idx]["id"]
        scene["zones"][zone_idx]["occupants"].append(npc["name"])


def _populate_environmental_encounter(scene: dict, terrain: str, threat_level: int = 2):
    """Add environmental hazards with objects from tables."""
    terrain_data = TERRAIN_TYPES.get(terrain, TERRAIN_TYPES["urban"])
    primary_hazard = random.choice(terrain_data["hazards"])
    scene["zones"][0]["hazard"] = primary_hazard

    # ── TABLES: Rich environmental objects ──
    if TABLES_AVAILABLE:
        scene["objects"] = get_environmental_objects(terrain, n=random.randint(2, 4), threat_level=threat_level)
    else:
        scene["objects"] = random.sample(FALLBACK_OBJECTS, random.randint(1, 3))

    scene["upcoming_events"].append({"trigger": "Player enters hazard zone", "event": f"Must deal with {primary_hazard}"})


def _populate_discovery_encounter(scene: dict, terrain: str, threat_level: int):
    """Add discovery from tables."""
    # ── TABLES: Contextual discovery ──
    if TABLES_AVAILABLE:
        discovery = get_discovery(terrain, threat_level)
        if discovery:
            scene["objects"].append({
                "name": discovery.get("name", "Unknown"),
                "interaction": discovery.get("check", "Investigation DC 12"),
                "contents": discovery.get("reward", "Unknown reward"),
            })
        # Also add 1-2 environmental objects
        scene["objects"].extend(get_environmental_objects(terrain, n=random.randint(1, 2)))
    else:
        discoveries = FALLBACK_DISCOVERIES.copy()
        if threat_level >= 3:
            discoveries.append({"name": "Ancient ruins entrance", "check": "Various", "reward": "Major dungeon"})
        discovery = random.choice(discoveries)
        scene["objects"].append({"name": discovery["name"], "interaction": discovery["check"], "contents": discovery["reward"]})


def _generate_secrets(scene: dict, world_state: dict, encounter_type: str):
    """Generate GM-only hidden information."""
    for npc in scene["npcs"]:
        if npc.get("secret"):
            scene["secrets"].append({"type": "npc_secret", "npc": npc["name"], "content": npc["secret"]})
        # Surface character tag leverage as GM-only intel
        if npc.get("leverage"):
            scene["secrets"].append({"type": "npc_leverage", "npc": npc["name"], "content": f"Leverage: {npc['leverage']}"})

    if encounter_type == "clear" and random.random() < 0.3:
        scene["secrets"].append({"type": "hidden_threat", "content": "Area seems clear but predator is tracking party from distance."})

    for clock_info in scene["relevant_clocks"]:
        scene["secrets"].append({"type": "clock_pressure", "content": f"Clock '{clock_info['name']}' at high pressure. May affect this scene."})

    if scene["enemies"]:
        scene["secrets"].append({"type": "idle_consequence",
            "content": "If players wait too long, enemies will: " + random.choice([
                "call reinforcements", "set up ambush", "flee with valuable", "complete patrol and leave"])})

    # Surface encounter context as GM intel
    for enemy in scene["enemies"]:
        ec = enemy.get("encounter_context")
        if ec and ec.get("complication"):
            scene["secrets"].append({"type": "combat_complication", "content": ec["complication"]})
            break  # One complication per scene


if __name__ == "__main__":
    print(f"=== SCENE GENERATION TEST (tables={TABLES_AVAILABLE}) ===\n")

    world_state = {
        "current_day": 5, "current_time": "14:30",
        "human_factions": [{"id": "f1", "name": "The Exchange", "archetype": "trade"}, {"id": "f2", "name": "The Sentinels", "archetype": "military"}],
        "external_threats": [{"id": "t1", "name": "Thornwood Swarm", "region": "forest", "creature_types": ["wolf", "spider"], "clock": {"current": 3, "max": 6}}],
        "clocks": [{"name": "Monster Pressure", "current": 4, "max": 6, "goal": "Creature surge"}, {"name": "City Consolidation", "current": 2, "max": 8, "goal": "Order restored"}],
    }
    location = {"name": "Thornwood Edge", "region": "forest", "terrain": "forest", "threat_level": 3}

    scene = generate_scene(location, world_state, player_level=3, force_encounter="combat")
    print(f"**{scene['name']}** ({scene['encounter_type']})")
    print(f"Weather: {scene['conditions']['weather']} | Lighting: {scene['conditions']['lighting']}")
    if scene.get("atmosphere"):
        atm = scene["atmosphere"]
        print(f"  Hear: {atm.get('sound', 'N/A')}")
        print(f"  Smell: {atm.get('smell', 'N/A')}")
        print(f"  See: {atm.get('sight', 'N/A')}")
    print(f"\nEnemies:")
    for e in scene["enemies"]:
        line = f"  - {e['name']} (Lv {e['level']} {e['threat']}): HP {e['hp']['max']}"
        ec = e.get("encounter_context")
        if ec:
            line += f"\n    Activity: {ec['activity']}"
            line += f"\n    Mood: {ec['mood']}"
        print(line)

    print(f"\n--- Social Scene ---")
    loc2 = {"name": "Market Square", "region": "urban", "terrain": "urban", "threat_level": 1}
    scene2 = generate_scene(loc2, world_state, player_level=3, force_encounter="social")
    for npc in scene2["npcs"][:2]:
        print(f"  {npc['name']} ({npc['role']})")
        if npc.get("character_tags"):
            for tag in npc["character_tags"]:
                print(f"    Tag: [{tag['key']}]")
        if npc.get("active_ambition"):
            print(f"    Ambition: {npc['active_ambition']}")
