"""
EMERGENCE: THE EXILE — Combat System
Attack resolution, stance management, combat state tracking.
"""

import random
from typing import Optional, List, Dict

try:
    from .dice import roll_2d6, check_vs_dc, get_crit_threshold
except ImportError:
    from dice import roll_2d6, check_vs_dc, get_crit_threshold

# ═══════════════════════════════════════════════════════════════════════════════
# COMBAT STANCES
# ═══════════════════════════════════════════════════════════════════════════════

STANCES = {
    "balanced": {
        "ap": 3, "rp": 1, "move": 0, "attack": 0, "defense": 0, "damage": 0,
        "special": "Default stance"
    },
    "aggressive": {
        "ap": 4, "rp": 1, "move": 0, "attack": 2, "defense": -2, "damage": 2,
        "special": "+2 damage on all attacks"
    },
    "defensive": {
        "ap": 2, "rp": 2, "move": -2, "attack": -2, "defense": 4, "damage": 0,
        "special": "Cannot be critically hit"
    },
    "mobile": {
        "ap": 3, "rp": 1, "move": 4, "attack": 0, "defense": 0, "damage": 0,
        "special": "Free disengage; no opportunity attacks"
    },
    "focused": {
        "ap": 2, "rp": 0, "move": -999, "attack": 0, "defense": -2, "damage": 0,
        "special": "Advantage on all attacks (cannot move)"
    }
}

def get_stance(stance_name: str) -> dict:
    """Get stance modifiers. Returns balanced if invalid."""
    return STANCES.get(stance_name.lower(), STANCES["balanced"])


# ═══════════════════════════════════════════════════════════════════════════════
# ATTACK RESOLUTION
# ═══════════════════════════════════════════════════════════════════════════════

def attack_roll(
    attacker: str,
    target: str,
    attack_mod: int,
    defense_dc: int,
    base_damage: int,
    damage_mod: int,
    armor: int = 0,
    stance: str = "balanced",
    precision_mod: int = 0,
    advantage: bool = False,
    disadvantage: bool = False,
    target_defensive: bool = False
) -> dict:
    """
    Full attack resolution.
    
    Returns dict with all roll details and final damage.
    """
    stance_mods = get_stance(stance)
    
    # Focused stance grants advantage
    if stance.lower() == "focused":
        advantage = True
    
    # Roll attack
    roll = roll_2d6(
        modifier=attack_mod + stance_mods["attack"],
        advantage=advantage,
        disadvantage=disadvantage
    )
    
    # Check vs DC with crit threshold
    crit_threshold = get_crit_threshold(precision_mod)
    
    # Defensive stance blocks crits
    if target_defensive:
        crit_threshold = 99  # Effectively no crits
    
    result = check_vs_dc(roll, defense_dc, crit_threshold)
    
    # Determine damage multiplier
    damage_mult = {
        "crit_hit": 2.0,
        "exceptional": 1.25,
        "hit": 1.0,
        "graze": 0.5,
        "miss": 0,
        "crit_miss": 0
    }.get(result["band"], 0)
    
    # Calculate damage
    raw_damage = base_damage + damage_mod + stance_mods["damage"]
    modified_damage = int(raw_damage * damage_mult)
    final_damage = max(0, modified_damage - armor)
    
    # Minimum 1 damage on any hit
    if damage_mult > 0 and final_damage < 1:
        final_damage = 1
    
    return {
        "attacker": attacker,
        "target": target,
        "roll": roll,
        "result": result,
        "band": result["band"],
        "total": result["total"],
        "defense_dc": defense_dc,
        "crit_threshold": crit_threshold,
        "damage_mult": damage_mult,
        "raw_damage": raw_damage,
        "armor": armor,
        "final_damage": final_damage,
        "stance": stance
    }


def format_attack_result(result: dict) -> str:
    """Format attack result for display."""
    lines = []
    lines.append(f"**Attack: {result['attacker']} → {result['target']}**")
    
    roll = result['roll']
    if roll['roll_type'] != "normal":
        lines.append(f"Roll ({roll['roll_type']}): {roll['dice']} → {roll['d1']} + {roll['d2']} = {roll['base']}")
    else:
        lines.append(f"Roll: {roll['d1']} + {roll['d2']} = {roll['base']}")
    
    lines.append(f"Total: {result['total']} vs DEF {result['defense_dc']}")
    
    band_display = {
        "crit_hit": "**CRITICAL HIT**",
        "exceptional": "**EXCEPTIONAL HIT**",
        "hit": "**HIT**",
        "graze": "GRAZING HIT",
        "miss": "MISS",
        "crit_miss": "**CRITICAL MISS**"
    }
    lines.append(band_display.get(result['band'], result['band']))
    
    if result['damage_mult'] > 0:
        lines.append(f"Damage: {result['raw_damage']} × {result['damage_mult']} - {result['armor']} armor = **{result['final_damage']}**")
    
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# COMBAT STATE MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════════

def roll_initiative(combatants: List[dict]) -> List[dict]:
    """
    Roll initiative for all combatants.
    
    combatants: List of dicts with 'name' and 'initiative_mod' keys.
    Returns sorted list with initiative values.
    """
    results = []
    for c in combatants:
        roll = roll_2d6(modifier=c.get("initiative_mod", 0))
        results.append({
            **c,
            "initiative_roll": roll["total"],
            "initiative_base": roll["base"]
        })
    
    # Sort by initiative (highest first), tiebreak by modifier
    results.sort(key=lambda x: (x["initiative_roll"], x.get("initiative_mod", 0)), reverse=True)
    
    return results


def create_combat_state(
    player: dict,
    enemies: List[dict],
    allies: List[dict] = None
) -> dict:
    """
    Initialize combat state.
    """
    combatants = []
    
    # Add player
    combatants.append({
        "name": player.get("name", "Player"),
        "type": "player",
        "initiative_mod": player.get("initiative", 0),
        "hp": player.get("hp", {"current": 1, "max": 1}),
        "is_active": True
    })
    
    # Add enemies
    for e in enemies:
        combatants.append({
            "name": e["name"],
            "type": "enemy",
            "initiative_mod": e.get("initiative", 0),
            "hp": e.get("hp", {"current": 1, "max": 1}),
            "is_active": True,
            "enemy_ref": e
        })
    
    # Add allies if present
    if allies:
        for a in allies:
            combatants.append({
                "name": a["name"],
                "type": "ally",
                "initiative_mod": a.get("initiative", 0),
                "hp": a.get("hp", {"current": 1, "max": 1}),
                "is_active": True
            })
    
    # Roll initiative
    initiative_order = roll_initiative(combatants)
    
    return {
        "round": 1,
        "turn_index": 0,
        "initiative_order": initiative_order,
        "current_turn": initiative_order[0]["name"] if initiative_order else None,
        "phase": "active",
        "combat_log": []
    }


def advance_turn(combat_state: dict) -> dict:
    """Advance to next turn in combat."""
    order = combat_state["initiative_order"]
    
    # Find next active combatant
    start_index = combat_state["turn_index"]
    current_index = (start_index + 1) % len(order)
    
    # Skip inactive combatants
    while not order[current_index].get("is_active", True):
        current_index = (current_index + 1) % len(order)
        if current_index == start_index:
            # Full loop, no active combatants
            combat_state["phase"] = "ended"
            return combat_state
    
    # Check for new round
    if current_index <= start_index:
        combat_state["round"] += 1
    
    combat_state["turn_index"] = current_index
    combat_state["current_turn"] = order[current_index]["name"]
    
    return combat_state


def format_combat_state(
    combat_state: dict,
    player: dict,
    enemies: List[dict],
    zones: List[dict] = None
) -> str:
    """Format combat state for display."""
    lines = []
    
    current = combat_state["current_turn"]
    round_num = combat_state["round"]
    
    lines.append(f"## Combat — Round {round_num} | {current}'s Turn\n")
    
    # Player status
    stance = player.get("stance", "balanced")
    stance_mods = get_stance(stance)
    
    hp = player.get("hp", {})
    hp_pct = (hp.get("current", 1) / hp.get("max", 1)) * 100
    if hp_pct <= 9:
        hp_state = "Near Death"
    elif hp_pct <= 24:
        hp_state = "Critical"
    elif hp_pct <= 49:
        hp_state = "Bloodied"
    elif hp_pct <= 74:
        hp_state = "Wounded"
    else:
        hp_state = "Healthy"
    
    lines.append(f"**Stance:** {stance.capitalize()} | **AP:** {stance_mods['ap']}/{stance_mods['ap']} | **RP:** {stance_mods['rp']}/{stance_mods['rp']} | **Move:** {6 + stance_mods['move']}m")
    lines.append(f"**HP:** {hp.get('current', '?')}/{hp.get('max', '?')} ({hp_state}) | **Stamina:** {player.get('stamina', {}).get('current', '?')} | **Mana:** {player.get('mana', {}).get('current', '?')}")
    
    conditions = player.get("conditions", [])
    lines.append(f"**Conditions:** {', '.join(conditions) if conditions else 'None'}\n")
    
    # Enemies
    lines.append("### Enemies\n")
    lines.append("| Enemy | HP | Armor | DEF | ATK | DMG | Zone | Telegraphed |")
    lines.append("|-------|-----|-------|-----|-----|-----|------|-------------|")
    
    for e in enemies:
        if e["hp"]["current"] > 0:
            hp_str = f"{e['hp']['current']}/{e['hp']['max']}"
            zone = e.get("zone", "—")
            telegraph = e.get("telegraph", "—")
            lines.append(f"| {e['name']} (Lv {e['level']}) | {hp_str} | {e.get('armor', 0)} | {e['defense']} | +{e['attack']} | {e['damage']} | {zone} | {telegraph} |")
    
    # Zones
    if zones:
        lines.append("\n### Zones\n")
        for z in zones:
            occupants = ", ".join(z.get("occupants", [])) or "Empty"
            props = ", ".join(z.get("properties", [])) or "None"
            hazard = f" | **Hazard:** {z['hazard']}" if z.get("hazard") else ""
            lines.append(f"- **{z['id']}** ({z['name']}): {occupants} | {props}{hazard}")
    
    # Initiative order
    lines.append("\n### Initiative Order\n")
    for i, c in enumerate(combat_state["initiative_order"]):
        if c.get("is_active", True):
            marker = " ← Current" if c["name"] == current else ""
            lines.append(f"{i+1}. {c['name']} ({c['initiative_roll']}){marker}")
    
    lines.append("\n**What do you do?**")
    
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# REACTIONS
# ═══════════════════════════════════════════════════════════════════════════════

REACTIONS = {
    "parry": {
        "name": "Parry",
        "rp_cost": 1,
        "trigger": "Attacked in melee",
        "effect": "Contested attack roll. If you win, negate the attack."
    },
    "dodge": {
        "name": "Dodge",
        "rp_cost": 1,
        "trigger": "Attacked (any)",
        "effect": "+4 DEF against this attack. Move 2m."
    },
    "intercept": {
        "name": "Intercept",
        "rp_cost": 1,
        "trigger": "Ally within 2m attacked",
        "effect": "Become the target instead."
    },
    "opportunity_attack": {
        "name": "Opportunity Attack",
        "rp_cost": 1,
        "trigger": "Enemy leaves your reach without disengaging",
        "effect": "Make one melee attack against them."
    }
}


# ═══════════════════════════════════════════════════════════════════════════════
# TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== COMBAT SYSTEM TEST ===\n")
    
    print("--- Attack Roll ---")
    result = attack_roll(
        attacker="Kira",
        target="Thornwolf",
        attack_mod=4,
        defense_dc=12,
        base_damage=8,
        damage_mod=2,
        armor=1,
        stance="aggressive",
        precision_mod=3
    )
    print(format_attack_result(result))
    
    print("\n--- Crit Threshold by PRC ---")
    for prc in [0, 3, 5, 7]:
        thresh = get_crit_threshold(prc)
        print(f"PRC mod +{prc}: Crit on {thresh}+")
    
    print("\n--- Initiative Roll ---")
    combatants = [
        {"name": "Player", "initiative_mod": 3},
        {"name": "Wolf 1", "initiative_mod": 2},
        {"name": "Wolf 2", "initiative_mod": 2},
        {"name": "Wolf Alpha", "initiative_mod": 4}
    ]
    order = roll_initiative(combatants)
    print("Initiative Order:")
    for i, c in enumerate(order):
        print(f"  {i+1}. {c['name']}: {c['initiative_roll']}")
    
    print("\n--- Stance Reference ---")
    print("| Stance | AP | RP | Move | ATK | DEF | DMG | Special |")
    print("|--------|----|----|------|-----|-----|-----|---------|")
    for name, s in STANCES.items():
        move = f"{s['move']:+d}" if s['move'] != -999 else "0"
        print(f"| {name.capitalize()} | {s['ap']} | {s['rp']} | {move}m | {s['attack']:+d} | {s['defense']:+d} | {s['damage']:+d} | {s['special']} |")
