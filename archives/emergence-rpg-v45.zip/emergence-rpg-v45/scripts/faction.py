"""
EMERGENCE: THE EXILE — Faction & Clock Generation
Session zero world building with faction dynamics and situation tags from tables.
"""

import random
from typing import Optional, List, Dict

try:
    from .dice import generate_id, weighted_choice
except ImportError:
    from dice import generate_id, weighted_choice

# Tables integration (graceful fallback)
try:
    import sys, os
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _parent_dir = os.path.dirname(_script_dir)
    if _parent_dir not in sys.path:
        sys.path.insert(0, _parent_dir)
    from tables.faction_dynamics import get_faction_dynamics, get_relationship_complication
    from tables.situation_tags import roll_situation_tags
    TABLES_AVAILABLE = True
except ImportError:
    TABLES_AVAILABLE = False

# ═══════════════════════════════════════════════════════════════════════════════
# HUMAN FACTION ARCHETYPES
# ═══════════════════════════════════════════════════════════════════════════════

HUMAN_ARCHETYPES = {
    "authority": {
        "description": "Claims governmental legitimacy",
        "goals": ["Restore order", "Unify territory", "Establish law", "Protect citizens"],
        "methods": ["Military force", "Bureaucracy", "Public works", "Propaganda"],
        "resources": ["Former officials", "Police/military", "Government buildings", "Records"],
        "territory_types": ["City hall", "Government complex", "Major landmark"],
        "clock_segments": (6, 10),
        "npc_roles": ["Leader", "Military Commander", "Spokesperson", "Enforcer"],
    },
    "military": {
        "description": "Armed force, former or improvised",
        "goals": ["Secure perimeter", "Protect civilians", "Eliminate threats", "Control territory"],
        "methods": ["Patrols", "Fortification", "Combat operations", "Martial law"],
        "resources": ["Weapons", "Training", "Discipline", "Equipment"],
        "territory_types": ["Armory", "Police station", "Barracks", "Checkpoint"],
        "clock_segments": (4, 8),
        "npc_roles": ["Commander", "Sergeant", "Scout", "Quartermaster"],
    },
    "trade": {
        "description": "Controls resources and exchange",
        "goals": ["Monopolize trade", "Establish currency", "Control supply", "Profit"],
        "methods": ["Caravans", "Markets", "Hoarding", "Price fixing"],
        "resources": ["Warehouses", "Connections", "Information", "Guards"],
        "territory_types": ["Market", "Warehouse district", "Port", "Trading post"],
        "clock_segments": (6, 8),
        "npc_roles": ["Boss", "Negotiator", "Caravan Master", "Accountant"],
    },
    "knowledge": {
        "description": "Information and expertise",
        "goals": ["Understand System", "Research magic", "Document threats", "Preserve knowledge"],
        "methods": ["Research", "Experimentation", "Teaching", "Information brokering"],
        "resources": ["Books", "Laboratories", "Experts", "Data"],
        "territory_types": ["University", "Library", "Hospital", "Research facility"],
        "clock_segments": (8, 12),
        "npc_roles": ["Lead Researcher", "Archivist", "Field Investigator", "Medic"],
    },
    "faith": {
        "description": "Spiritual or ideological movement",
        "goals": ["Spread belief", "Provide meaning", "Build community", "Interpret Transit"],
        "methods": ["Preaching", "Charity", "Rituals", "Prophecy"],
        "resources": ["Believers", "Sacred sites", "Charisma", "Hope"],
        "territory_types": ["Church", "Temple", "Community center", "Refuge"],
        "clock_segments": (6, 10),
        "npc_roles": ["Leader", "Prophet", "Healer", "Missionary"],
    },
    "criminal": {
        "description": "Operates outside law",
        "goals": ["Profit", "Control territory", "Survive", "Expand influence"],
        "methods": ["Theft", "Protection rackets", "Black market", "Violence"],
        "resources": ["Enforcers", "Hideouts", "Connections", "Fear"],
        "territory_types": ["Underground", "Abandoned building", "Nightclub", "Warehouse"],
        "clock_segments": (4, 8),
        "npc_roles": ["Boss", "Lieutenant", "Enforcer", "Fence"],
    },
    "commune": {
        "description": "Collective survival focus",
        "goals": ["Feed members", "Protect community", "Stay hidden", "Self-sufficiency"],
        "methods": ["Farming", "Scavenging", "Mutual aid", "Isolation"],
        "resources": ["Land", "Labor", "Trust", "Skills"],
        "territory_types": ["Park", "Rooftop garden", "Apartment complex", "School"],
        "clock_segments": (4, 8),
        "npc_roles": ["Elder", "Farmer", "Defender", "Mediator"],
    },
    "scavenger": {
        "description": "Salvage and exploration",
        "goals": ["Find resources", "Map territory", "Profit from danger", "Monopolize salvage"],
        "methods": ["Expeditions", "Risk-taking", "Trading finds", "Claiming sites"],
        "resources": ["Scouts", "Maps", "Equipment", "Guts"],
        "territory_types": ["Base camp", "Staging area", "Garage", "Depot"],
        "clock_segments": (4, 6),
        "npc_roles": ["Leader", "Scout", "Salvage Expert", "Mapper"],
    },
    "tech": {
        "description": "Maintains/adapts technology",
        "goals": ["Keep power on", "Adapt tech to magic", "Build defenses", "Information control"],
        "methods": ["Repair", "Innovation", "Hacking", "Infrastructure control"],
        "resources": ["Engineers", "Parts", "Power sources", "Knowledge"],
        "territory_types": ["Power plant", "Server farm", "Workshop", "Communications hub"],
        "clock_segments": (6, 10),
        "npc_roles": ["Chief Engineer", "Inventor", "Technician", "Operator"],
    },
    "hunters": {
        "description": "Specialized monster killers",
        "goals": ["Clear threats", "Harvest monsters", "Train warriors", "Control awakening"],
        "methods": ["Combat", "Tracking", "Trapping", "Bounties"],
        "resources": ["Fighters", "Monster knowledge", "Trophies", "Reputation"],
        "territory_types": ["Training ground", "Trophy hall", "Armory", "Hunting lodge"],
        "clock_segments": (4, 8),
        "npc_roles": ["Hunt Master", "Veteran", "Tracker", "Trophy Keeper"],
    },
}

FACTION_NAME_PARTS = {
    "authority": {"prefix": ["Provisional", "United", "New York", "Emergency", "Citizens'"], "suffix": ["Authority", "Council", "Government", "Assembly", "Coalition"]},
    "military": {"prefix": ["The", "First", "United", "Guardian", "Iron"], "suffix": ["Watch", "Guard", "Sentinels", "Militia", "Defense Force"]},
    "trade": {"prefix": ["The", "Central", "Free", "United", "Open"], "suffix": ["Exchange", "Market", "Trading Company", "Consortium", "Network"]},
    "knowledge": {"prefix": ["The", "New", "United", "Scientific", "Applied"], "suffix": ["Institute", "Collective", "Foundation", "Academy", "Circle"]},
    "faith": {"prefix": ["The", "Holy", "True", "Awakened", "Children of"], "suffix": ["Light", "Covenant", "Path", "Communion", "Faithful"]},
    "criminal": {"prefix": ["The", "Shadow", "Underground", "Night", "Street"], "suffix": ["Syndicate", "Family", "Kings", "Network", "Brotherhood"]},
    "commune": {"prefix": ["The", "United", "Free", "People's", "Community"], "suffix": ["Collective", "Haven", "Refuge", "Garden", "Commune"]},
    "scavenger": {"prefix": ["The", "Deep", "Urban", "Ruin", "First"], "suffix": ["Runners", "Delvers", "Harvesters", "Salvagers", "Explorers"]},
    "tech": {"prefix": ["The", "New", "Grid", "Circuit", "Digital"], "suffix": ["Engineers", "Collective", "Network", "Workshop", "Guild"]},
    "hunters": {"prefix": ["The", "Monster", "Beast", "Wild", "Storm"], "suffix": ["Hunters", "Slayers", "Pack", "Lodge", "Company"]},
}

# ═══════════════════════════════════════════════════════════════════════════════
# EXTERNAL THREAT TYPES
# ═══════════════════════════════════════════════════════════════════════════════

EXTERNAL_THREAT_TYPES = {
    "empire": {"description": "Organized foreign power", "goals": ["Conquer", "Enslave", "Extract resources", "Expand territory"], "methods": ["Military invasion", "Diplomacy", "Espionage", "Economic pressure"], "clock_segments": (6, 10), "creature_types": ["humanoid"], "approach": "Calculated. Scouts first, then probes, then invasion."},
    "horde": {"description": "Nomadic warrior culture", "goals": ["Raid", "Loot", "Conquer weak", "Prove strength"], "methods": ["Raids", "Lightning strikes", "Tribute demands", "Shows of force"], "clock_segments": (4, 8), "creature_types": ["humanoid"], "approach": "Tests strength. Respects power. Will trade if outmatched."},
    "swarm": {"description": "Monster migration/breeding", "goals": ["Feed", "Breed", "Expand territory", "Survive"], "methods": ["Numbers", "Instinct", "Overwhelming force", "Attrition"], "clock_segments": (4, 6), "creature_types": ["wolf", "insect", "spider", "bird"], "approach": "Instinctive. Pressure builds until breach."},
    "predator": {"description": "Apex predator establishing territory", "goals": ["Hunt", "Claim territory", "Eliminate competition", "Feed"], "methods": ["Ambush", "Terror", "Systematic hunting", "Territorial marking"], "clock_segments": (4, 8), "creature_types": ["drake", "cat", "bear"], "approach": "Solitary or mated pair. Hunts methodically."},
    "corruption": {"description": "Spreading magical/environmental hazard", "goals": ["Spread", "Transform", "Consume", "Exist"], "methods": ["Contamination", "Mutation", "Mind control", "Landscape change"], "clock_segments": (6, 12), "creature_types": ["ooze", "plant", "elemental"], "approach": "Inexorable. No negotiation. Must be contained."},
    "undead": {"description": "Necromantic threat", "goals": ["Expand", "Serve master", "Consume life", "Unknown"], "methods": ["Attrition", "Infection", "Fear", "Endless assault"], "clock_segments": (6, 10), "creature_types": ["undead"], "approach": "Relentless. Numbers grow from fallen."},
    "cult": {"description": "Worshippers of something alien", "goals": ["Summon", "Sacrifice", "Convert", "Prepare the way"], "methods": ["Infiltration", "Kidnapping", "Rituals", "Terrorism"], "clock_segments": (8, 12), "creature_types": ["humanoid", "elemental"], "approach": "Hidden until ready. Clock = ritual progress."},
    "elemental": {"description": "Elemental incursion", "goals": ["Reclaim", "Purify", "Transform", "Exist"], "methods": ["Natural disasters", "Transformation", "Raw power", "Persistence"], "clock_segments": (6, 10), "creature_types": ["elemental", "golem"], "approach": "Alien intelligence. May be negotiated with."},
}

EXTERNAL_NAME_PARTS = {
    "empire": ["Kaelthari", "Dominion", "Empire", "Kingdom", "Dynasty", "Sovereignty"],
    "horde": ["Khanate", "Horde", "Riders", "Raiders", "Warband", "Host"],
    "swarm": ["Swarm", "Tide", "Wave", "Plague", "Migration", "Brood"],
    "predator": ["The", "Ancient", "Great", "Dire", "Primal", "Apex"],
    "corruption": ["Blight", "Corruption", "Taint", "Spread", "Rot", "Infection"],
    "undead": ["Risen", "Legion", "Dead", "Hollow", "Wailing", "Bound"],
    "cult": ["Cult of", "Followers of", "Children of", "Servants of", "Disciples of"],
    "elemental": ["Storm", "Earth", "Fire", "Void", "Primal", "Awakened"],
}

# ═══════════════════════════════════════════════════════════════════════════════
# CLOCK SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

def create_clock(name: str, segments: int, owner: str, goal: str, completion_effect: str, hidden: bool = False) -> dict:
    return {"id": generate_id("clock_"), "name": name, "current": 0, "max": segments, "owner": owner, "goal": goal, "completion_effect": completion_effect, "hidden": hidden, "history": []}

def tick_clock(clock: dict, amount: int, reason: str, day: int) -> dict:
    old_value = clock["current"]
    clock["current"] = max(0, min(clock["max"], clock["current"] + amount))
    clock["history"].append({"day": day, "change": amount, "old": old_value, "new": clock["current"], "reason": reason})
    return clock

def check_clock_completion(clock: dict) -> Optional[dict]:
    if clock["current"] >= clock["max"]:
        return {"clock_id": clock["id"], "clock_name": clock["name"], "owner": clock["owner"], "effect": clock["completion_effect"], "is_completed": True}
    return None

def format_clock_display(clock: dict) -> str:
    return f"{'●' * clock['current']}{'○' * (clock['max'] - clock['current'])} {clock['current']}/{clock['max']}"


# ═══════════════════════════════════════════════════════════════════════════════
# FACTION GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

def generate_human_faction(archetype: str = None, power_level: int = None) -> dict:
    """Generate a human faction with dynamics and situation tags from tables."""
    if archetype is None:
        archetype = random.choice(list(HUMAN_ARCHETYPES.keys()))
    arch_data = HUMAN_ARCHETYPES.get(archetype, HUMAN_ARCHETYPES["authority"])
    if power_level is None:
        power_level = random.randint(1, 5)

    name_parts = FACTION_NAME_PARTS.get(archetype, FACTION_NAME_PARTS["authority"])
    name = f"{random.choice(name_parts['prefix'])} {random.choice(name_parts['suffix'])}"
    goal = random.choice(arch_data["goals"])
    method = random.choice(arch_data["methods"])
    territory = random.choice(arch_data["territory_types"])

    seg_min, seg_max = arch_data["clock_segments"]
    completion_effect = random.choice([
        f"{name} achieves {goal.lower()}. Major shift in power dynamics.",
        f"{name} completes their plan. Other factions must respond.",
        f"{name}'s {goal.lower()} succeeds. Consequences ripple across the city.",
    ])
    clock = create_clock(name=f"{name} - {goal}", segments=random.randint(seg_min, seg_max),
                         owner=name, goal=goal, completion_effect=completion_effect)

    npcs = [{"id": generate_id("npc_"), "role": role, "name": None, "faction": name,
             "disposition": "neutral", "status": "active", "secret": None}
            for role in arch_data["npc_roles"][:3]]

    # ── TABLES INTEGRATION ──
    faction_dynamics = None
    situation_tags = None
    if TABLES_AVAILABLE:
        faction_dynamics = get_faction_dynamics(archetype)
        situation_tags = roll_situation_tags(2)

    return {
        "id": generate_id("faction_"), "name": name, "archetype": archetype,
        "description": arch_data["description"], "goal": goal, "method": method,
        "territory": territory, "power_level": power_level, "resources": arch_data["resources"],
        "clock": clock, "npcs": npcs, "reputation": 0, "rank": None, "notes": "",
        # NEW: from tables
        "faction_dynamics": faction_dynamics,  # {internal_crisis, legitimacy_source}
        "situation_tags": situation_tags,       # [{key, desc, enemy, friend, complication, thing, place}, ...]
    }


def generate_external_threat(threat_type: str = None, threat_level: int = None, region: str = None) -> dict:
    """Generate an external (non-human) threat."""
    if threat_type is None:
        threat_type = random.choice(list(EXTERNAL_THREAT_TYPES.keys()))
    type_data = EXTERNAL_THREAT_TYPES.get(threat_type, EXTERNAL_THREAT_TYPES["swarm"])
    if threat_level is None:
        threat_level = random.randint(1, 5)
    if region is None:
        region = random.choice(["forest", "plains", "mountain", "swamp", "ruins", "crystal", "shadow"])

    name_parts = EXTERNAL_NAME_PARTS.get(threat_type, ["Unknown"])
    if threat_type in ["empire", "horde", "cult"]:
        name = f"{random.choice(['The', 'Great', 'Ancient', 'Iron', 'Shadow', 'Storm'])} {random.choice(name_parts)}"
    elif threat_type == "predator":
        name = f"{random.choice(['Shadowfang', 'Deathclaw', 'Nightterror', 'Grimjaw', 'Bloodmaw'])} the {random.choice(name_parts)}"
    else:
        name = f"The {random.choice(name_parts)} of {region.capitalize()}"

    goal = random.choice(type_data["goals"])
    method = random.choice(type_data["methods"])
    seg_min, seg_max = type_data["clock_segments"]

    completion_templates = {
        "empire": f"Full invasion. {name} establishes military presence in the city.",
        "horde": f"Major raid. {name} breaches defenses and pillages significant territory.",
        "swarm": f"Outbreak. {name} overwhelms an area. Mass casualties possible.",
        "predator": f"{name} claims hunting ground. Area becomes extremely dangerous.",
        "corruption": f"Spread complete. Area permanently transformed. New threats emerge.",
        "undead": f"The dead rise en masse. Major district falls to {name}.",
        "cult": f"Ritual complete. Something answers. Reality warps.",
        "elemental": f"Incursion peaks. Area transformed by elemental force.",
    }

    clock = create_clock(name=f"{name} - {goal}", segments=random.randint(seg_min, seg_max),
                         owner=name, goal=goal,
                         completion_effect=completion_templates.get(threat_type, f"{name} achieves {goal.lower()}."),
                         hidden=(threat_type == "cult"))

    return {
        "id": generate_id("threat_"), "name": name, "threat_type": threat_type,
        "description": type_data["description"], "goal": goal, "method": method,
        "region": region, "threat_level": threat_level, "creature_types": type_data["creature_types"],
        "approach": type_data["approach"], "clock": clock, "status": "active", "notes": "",
    }


# ═══════════════════════════════════════════════════════════════════════════════
# SESSION ZERO GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

def generate_session_zero_factions(num_human: int = 10, num_external: int = 10) -> dict:
    """Generate complete faction landscape with dynamics and relationships."""
    human_factions = []
    external_threats = []

    archetypes = list(HUMAN_ARCHETYPES.keys())
    random.shuffle(archetypes)
    for i in range(num_human):
        faction = generate_human_faction(archetype=archetypes[i % len(archetypes)])
        human_factions.append(faction)

    threat_types = list(EXTERNAL_THREAT_TYPES.keys())
    random.shuffle(threat_types)
    regions = ["forest", "plains", "mountain", "swamp", "ruins", "crystal", "shadow"]
    random.shuffle(regions)
    for i in range(num_external):
        threat = generate_external_threat(threat_type=threat_types[i % len(threat_types)], region=regions[i % len(regions)])
        external_threats.append(threat)

    meta_clocks = [
        create_clock("The Stirring", 12, "World", "Something ancient awakens",
                     "The Hollow King stirs. Massive undead escalation. Boss encounter unlocked.", hidden=True),
        create_clock("Winter Comes", 8, "World", "First winter in Vaelithar",
                     "Winter arrives. Resource scarcity. Many clocks accelerate.", hidden=False),
    ]

    # ── TABLES: Generate relationship complications between factions ──
    relationships = []
    if TABLES_AVAILABLE and len(human_factions) >= 2:
        for i in range(min(5, len(human_factions) - 1)):
            relationships.append({
                "faction_a": human_factions[i]["name"],
                "faction_b": human_factions[i + 1]["name"],
                "complication": get_relationship_complication(),
            })

    return {
        "human_factions": human_factions,
        "external_threats": external_threats,
        "meta_clocks": meta_clocks,
        "faction_relationships": relationships,
    }


if __name__ == "__main__":
    print(f"=== FACTION GENERATION TEST (tables={TABLES_AVAILABLE}) ===\n")

    f = generate_human_faction("authority")
    print(f"**{f['name']}** ({f['archetype']})")
    print(f"Goal: {f['goal']} via {f['method']} | Power: {f['power_level']}/5")
    print(f"Clock: {format_clock_display(f['clock'])}")
    if f.get("faction_dynamics"):
        print(f"  Internal Crisis: {f['faction_dynamics']['internal_crisis']}")
        print(f"  Legitimacy: {f['faction_dynamics']['legitimacy_source']}")
    if f.get("situation_tags"):
        for tag in f["situation_tags"]:
            print(f"  Situation: [{tag['key']}] {tag['desc']}")
            print(f"    Enemy: {tag['enemy']}")
            print(f"    Friend: {tag['friend']}")

    print()
    world = generate_session_zero_factions(num_human=3, num_external=2)
    print(f"Factions: {[f['name'] for f in world['human_factions']]}")
    if world.get("faction_relationships"):
        print(f"Relationships:")
        for r in world["faction_relationships"]:
            print(f"  {r['faction_a']} ↔ {r['faction_b']}: {r['complication']}")
