#!/usr/bin/env python3
"""
EMERGENCE: THE EXILE — Unified CLI
Single entry point for all game mechanics. Outputs JSON for artifact population.

Usage:
    python emergence_cli.py <command> [options]

Commands:
    session-zero    Generate complete world state (factions, threats, clocks)
    character       Generate character stats
    scene           Generate a new scene
    creature        Generate a single creature
    creatures       Generate a balanced encounter group
    npc             Generate an NPC
    awakened-npc    Generate an awakened (combat-capable) NPC
    attack          Resolve an attack roll
    roll            Roll 2d6 with modifier
    loot            Roll for loot
    adventure       Generate an adventure hook
"""

import argparse
import json
import sys
import os

# Ensure script directory is in path for imports
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

# Parent directory for tables
_parent_dir = os.path.dirname(_script_dir)
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)


def cmd_session_zero(args):
    """Generate complete session zero world state."""
    from faction import generate_session_zero_factions
    
    result = generate_session_zero_factions(
        num_human=args.human,
        num_external=args.external
    )
    
    # Convert to serializable format
    output = {
        "human_factions": result["human_factions"],
        "external_threats": result["external_threats"],
        "meta_clocks": result["meta_clocks"],
        "faction_relationships": result.get("faction_relationships", []),
        "initial_state": {
            "current_day": 1,
            "current_time": "14:47",
            "entropy": 50,
            "momentum": 30,
            "connection": 0
        }
    }
    
    print(json.dumps(output, indent=2, default=str))


def cmd_character(args):
    """Generate character stats."""
    from character import (
        apply_aspect_archetype_bonuses,
        calculate_derived_stats, get_class_name, get_form_slots
    )
    
    # Base stats
    base_stats = {
        "might": 10, "agility": 10, "fortitude": 10, "precision": 10,
        "intellect": 10, "wisdom": 10, "willpower": 10, "presence": 10
    }
    
    # Apply aspect and archetype bonuses together
    final_stats = apply_aspect_archetype_bonuses(
        base_stats, args.aspect, args.archetype, args.level
    )
    
    # Calculate derived stats
    derived = calculate_derived_stats(final_stats, level=args.level, armor_bonus=0)
    
    # Get class name
    class_name = get_class_name(args.aspect, args.archetype)
    
    output = {
        "class_name": class_name,
        "aspect": args.aspect,
        "archetype": args.archetype,
        "level": args.level,
        "attributes": final_stats,
        "modifiers": {k: (v - 10) // 2 for k, v in final_stats.items()},
        "derived": derived,
        "form_slots": get_form_slots(args.level),
        "xp": {"current": 0, "next_level": 100 * args.level}
    }
    
    print(json.dumps(output, indent=2, default=str))


def cmd_scene(args):
    """Generate a complete scene."""
    from scene import generate_scene
    
    # Build location dict
    location = {
        "name": args.location,
        "region": args.region,
        "terrain": args.terrain or args.region,
        "threat_level": args.threat_level
    }
    
    # Parse world state if provided
    if args.world_json:
        try:
            world_state = json.loads(args.world_json)
        except json.JSONDecodeError:
            world_state = {"current_day": 1, "current_time": "12:00"}
    else:
        world_state = {"current_day": 1, "current_time": "12:00"}
    
    scene = generate_scene(
        location=location,
        world_state=world_state,
        player_level=args.player_level,
        scene_type=args.scene_type,
        force_encounter=args.force_encounter
    )
    
    print(json.dumps(scene, indent=2, default=str))


def cmd_creature(args):
    """Generate a single creature."""
    from creature import generate_creature
    
    creature = generate_creature(
        level=args.level,
        threat=args.threat,
        region=args.region,
        creature_type=args.creature_type,
        terrain=args.terrain,
        time_of_day=args.time_of_day
    )
    
    print(json.dumps(creature, indent=2, default=str))


def cmd_creatures(args):
    """Generate a balanced encounter group."""
    from creature import generate_creature_group
    
    creatures = generate_creature_group(
        level=args.level,
        region=args.region,
        difficulty=args.difficulty,
        terrain=args.terrain,
        time_of_day=args.time_of_day
    )
    
    print(json.dumps(creatures, indent=2, default=str))


def cmd_npc(args):
    """Generate a quick NPC."""
    from npc import generate_quick_npc
    
    npc = generate_quick_npc(
        faction_id=args.faction_id,
        faction_name=args.faction,
        faction_archetype=args.archetype,
        role=args.role,
        disposition=args.disposition
    )
    
    print(json.dumps(npc, indent=2, default=str))


def cmd_awakened_npc(args):
    """Generate an awakened (combat-capable) NPC."""
    from npc import generate_awakened_npc
    
    npc = generate_awakened_npc(
        level=args.level,
        tier=args.tier,
        faction_name=args.faction,
        faction_archetype=args.archetype,
        role=args.role
    )
    
    print(json.dumps(npc, indent=2, default=str))


def cmd_attack(args):
    """Resolve an attack roll."""
    from combat import attack_roll, format_attack_result
    
    result = attack_roll(
        attacker=args.attacker,
        target=args.target,
        attack_mod=args.attack_mod,
        defense_dc=args.defense_dc,
        base_damage=args.damage,
        damage_mod=args.damage_mod,
        armor=args.armor,
        stance=args.stance,
        precision_mod=args.precision_mod,
        advantage=args.advantage,
        disadvantage=args.disadvantage
    )
    
    # Add formatted output for easy reading
    result["formatted"] = format_attack_result(result)
    
    print(json.dumps(result, indent=2, default=str))


def cmd_roll(args):
    """Roll 2d6 with modifier."""
    from dice import roll_2d6, check_vs_dc
    
    result = roll_2d6(
        modifier=args.modifier,
        advantage=args.advantage,
        disadvantage=args.disadvantage
    )
    
    if args.dc:
        result = check_vs_dc(result, args.dc, crit_threshold=args.crit_threshold)
    
    print(json.dumps(result, indent=2, default=str))


def cmd_loot(args):
    """Roll for loot."""
    from dice import roll_loot
    
    result = roll_loot(source_type=args.source)
    
    print(json.dumps(result, indent=2, default=str))


def cmd_adventure(args):
    """Generate an adventure hook."""
    from adventure import generate_adventure
    
    # Parse world state if provided
    if args.world_json:
        try:
            world_state = json.loads(args.world_json)
        except json.JSONDecodeError:
            world_state = {}
    else:
        world_state = {}
    
    location = None
    if args.location:
        location = {"name": args.location, "threat_level": args.threat_level}
    
    adventure = generate_adventure(
        world_state=world_state,
        current_location=location,
        seed_type=args.seed_type,
        depth=args.depth
    )
    
    print(json.dumps(adventure, indent=2, default=str))


def cmd_clock_tick(args):
    """Format a clock tick for recording."""
    result = {
        "clock_name": args.clock,
        "previous": args.previous,
        "change": args.change,
        "new_value": args.previous + args.change,
        "max_value": args.max_value,
        "reason": args.reason,
        "completed": (args.previous + args.change) >= args.max_value,
        "display": "●" * (args.previous + args.change) + "○" * (args.max_value - args.previous - args.change)
    }
    
    if result["completed"]:
        result["alert"] = f"CLOCK COMPLETE: {args.clock} - Execute completion effect!"
    
    print(json.dumps(result, indent=2, default=str))


def main():
    parser = argparse.ArgumentParser(
        description="EMERGENCE: THE EXILE — Unified CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Session Zero
    p_session = subparsers.add_parser("session-zero", help="Generate world state")
    p_session.add_argument("--human", type=int, default=10, help="Number of human factions")
    p_session.add_argument("--external", type=int, default=10, help="Number of external threats")
    
    # Character
    p_char = subparsers.add_parser("character", help="Generate character stats")
    p_char.add_argument("--aspect", required=True, 
                        choices=["ore", "tide", "pyre", "gale", "radiance", "shroud", "anima", "aether"])
    p_char.add_argument("--archetype", required=True,
                        choices=["striker", "guardian", "hunter", "skirmisher", "mender", "warden", "analyst", "speaker"])
    p_char.add_argument("--level", type=int, default=1)
    
    # Scene
    p_scene = subparsers.add_parser("scene", help="Generate a scene")
    p_scene.add_argument("--location", required=True, help="Location name")
    p_scene.add_argument("--region", required=True,
                         choices=["forest", "plains", "mountain", "swamp", "ruins", "urban", "crystal", "shadow"])
    p_scene.add_argument("--terrain", help="Terrain type (defaults to region)")
    p_scene.add_argument("--threat-level", type=int, default=2)
    p_scene.add_argument("--player-level", type=int, default=1)
    p_scene.add_argument("--scene-type", choices=["exploration", "travel", "social", "danger_zone", "safe_zone"])
    p_scene.add_argument("--force-encounter", choices=["clear", "combat", "social", "environmental", "discovery"])
    p_scene.add_argument("--world-json", help="World state as JSON string")
    
    # Creature
    p_creature = subparsers.add_parser("creature", help="Generate a creature")
    p_creature.add_argument("--level", type=int, required=True)
    p_creature.add_argument("--threat", default="standard",
                            choices=["minion", "standard", "elite", "boss", "legendary"])
    p_creature.add_argument("--region", default="forest",
                            choices=["forest", "plains", "mountain", "swamp", "ruins", "urban", "crystal", "shadow"])
    p_creature.add_argument("--creature-type", help="Force specific creature type")
    p_creature.add_argument("--terrain", help="Terrain for encounter context")
    p_creature.add_argument("--time-of-day", default="day", choices=["dawn", "day", "dusk", "night"])
    
    # Creatures (group)
    p_creatures = subparsers.add_parser("creatures", help="Generate encounter group")
    p_creatures.add_argument("--level", type=int, required=True)
    p_creatures.add_argument("--difficulty", default="medium",
                             choices=["easy", "medium", "hard", "deadly"])
    p_creatures.add_argument("--region", default="forest",
                             choices=["forest", "plains", "mountain", "swamp", "ruins", "urban", "crystal", "shadow"])
    p_creatures.add_argument("--terrain", help="Terrain for encounter context")
    p_creatures.add_argument("--time-of-day", default="day", choices=["dawn", "day", "dusk", "night"])
    
    # NPC
    p_npc = subparsers.add_parser("npc", help="Generate quick NPC")
    p_npc.add_argument("--faction", help="Faction name")
    p_npc.add_argument("--faction-id", help="Faction ID")
    p_npc.add_argument("--archetype", help="Faction archetype")
    p_npc.add_argument("--role", help="NPC role")
    p_npc.add_argument("--disposition", default="neutral",
                       choices=["hostile", "wary", "neutral", "friendly", "allied"])
    
    # Awakened NPC
    p_awk = subparsers.add_parser("awakened-npc", help="Generate awakened NPC")
    p_awk.add_argument("--level", type=int, required=True)
    p_awk.add_argument("--tier", default="standard",
                       choices=["minion", "standard", "veteran", "elite", "boss"])
    p_awk.add_argument("--faction", help="Faction name")
    p_awk.add_argument("--archetype", help="Faction archetype")
    p_awk.add_argument("--role", help="NPC role")
    
    # Attack
    p_atk = subparsers.add_parser("attack", help="Resolve attack roll")
    p_atk.add_argument("--attacker", required=True)
    p_atk.add_argument("--target", required=True)
    p_atk.add_argument("--attack-mod", type=int, required=True)
    p_atk.add_argument("--defense-dc", type=int, required=True)
    p_atk.add_argument("--damage", type=int, required=True, help="Base damage")
    p_atk.add_argument("--damage-mod", type=int, default=0)
    p_atk.add_argument("--armor", type=int, default=0)
    p_atk.add_argument("--stance", default="balanced")
    p_atk.add_argument("--precision-mod", type=int, default=0)
    p_atk.add_argument("--advantage", action="store_true")
    p_atk.add_argument("--disadvantage", action="store_true")
    
    # Roll
    p_roll = subparsers.add_parser("roll", help="Roll 2d6")
    p_roll.add_argument("--modifier", type=int, default=0)
    p_roll.add_argument("--advantage", action="store_true")
    p_roll.add_argument("--disadvantage", action="store_true")
    p_roll.add_argument("--dc", type=int, help="DC to check against")
    p_roll.add_argument("--crit-threshold", type=int, default=12)
    
    # Loot
    p_loot = subparsers.add_parser("loot", help="Roll for loot")
    p_loot.add_argument("--source", default="standard",
                        choices=["minion", "standard", "elite", "boss"])
    
    # Adventure
    p_adv = subparsers.add_parser("adventure", help="Generate adventure hook")
    p_adv.add_argument("--world-json", help="World state as JSON string")
    p_adv.add_argument("--location", help="Current location name")
    p_adv.add_argument("--threat-level", type=int, default=2)
    p_adv.add_argument("--seed-type", choices=["conflict", "rescue", "heist", "mystery", "dilemma", "clock", "social"])
    p_adv.add_argument("--depth", type=int, default=2, choices=[1, 2, 3])
    
    # Clock Tick
    p_clock = subparsers.add_parser("clock-tick", help="Format clock tick")
    p_clock.add_argument("--clock", required=True, help="Clock name")
    p_clock.add_argument("--previous", type=int, required=True, help="Previous value")
    p_clock.add_argument("--change", type=int, required=True, help="Change amount")
    p_clock.add_argument("--max-value", type=int, required=True, help="Maximum value")
    p_clock.add_argument("--reason", required=True, help="Reason for tick")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Dispatch to command handler
    commands = {
        "session-zero": cmd_session_zero,
        "character": cmd_character,
        "scene": cmd_scene,
        "creature": cmd_creature,
        "creatures": cmd_creatures,
        "npc": cmd_npc,
        "awakened-npc": cmd_awakened_npc,
        "attack": cmd_attack,
        "roll": cmd_roll,
        "loot": cmd_loot,
        "adventure": cmd_adventure,
        "clock-tick": cmd_clock_tick,
    }
    
    try:
        commands[args.command](args)
    except Exception as e:
        error_output = {
            "error": True,
            "command": args.command,
            "message": str(e),
            "type": type(e).__name__
        }
        print(json.dumps(error_output, indent=2), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
