"""
EMERGENCE: THE EXILE — Character System
Derived stats, archetype bonuses, character state management.
"""

from typing import Dict, List, Optional

# ═══════════════════════════════════════════════════════════════════════════════
# ASPECTS AND ARCHETYPES
# ═══════════════════════════════════════════════════════════════════════════════

ASPECTS = {
    "ore": {
        "name": "Ore",
        "description": "Earth, metal, stability, endurance",
        "primary_bonus": "fortitude",
        "secondary_bonus": "might",
        "affinities": ["defense", "physical", "crafting"]
    },
    "tide": {
        "name": "Tide", 
        "description": "Water, ice, flow, adaptation",
        "primary_bonus": "precision",
        "secondary_bonus": "agility",
        "affinities": ["investigation", "medicine", "stealth"]
    },
    "pyre": {
        "name": "Pyre",
        "description": "Fire, heat, destruction, passion",
        "primary_bonus": "might",
        "secondary_bonus": "willpower",
        "affinities": ["damage", "combat", "intensity"]
    },
    "gale": {
        "name": "Gale",
        "description": "Air, lightning, speed, freedom",
        "primary_bonus": "agility",
        "secondary_bonus": "precision",
        "affinities": ["mobility", "ranged", "evasion"]
    },
    "radiance": {
        "name": "Radiance",
        "description": "Light, healing, truth, protection",
        "primary_bonus": "presence",
        "secondary_bonus": "wisdom",
        "affinities": ["healing", "support", "revelation"]
    },
    "shroud": {
        "name": "Shroud",
        "description": "Shadow, death, secrets, fear",
        "primary_bonus": "willpower",
        "secondary_bonus": "intellect",
        "affinities": ["stealth", "assassination", "fear"]
    },
    "anima": {
        "name": "Anima",
        "description": "Life, beasts, nature, instinct",
        "primary_bonus": "wisdom",
        "secondary_bonus": "fortitude",
        "affinities": ["beasts", "survival", "transformation"]
    },
    "aether": {
        "name": "Aether",
        "description": "Void, time, space, reality",
        "primary_bonus": "intellect",
        "secondary_bonus": "willpower",
        "affinities": ["magic", "manipulation", "transcendence"]
    }
}

ARCHETYPES = {
    "striker": {
        "name": "Striker",
        "description": "Maximum damage dealer",
        "primary_bonus": "might",
        "secondary_bonus": "fortitude",
        "role": "Melee DPS"
    },
    "guardian": {
        "name": "Guardian",
        "description": "Defensive tank",
        "primary_bonus": "fortitude",
        "secondary_bonus": "willpower",
        "role": "Tank"
    },
    "hunter": {
        "name": "Hunter",
        "description": "Ranged precision striker",
        "primary_bonus": "precision",
        "secondary_bonus": "agility",
        "role": "Ranged DPS"
    },
    "skirmisher": {
        "name": "Skirmisher",
        "description": "Mobile opportunist",
        "primary_bonus": "agility",
        "secondary_bonus": "precision",
        "role": "Mobile DPS"
    },
    "mender": {
        "name": "Mender",
        "description": "Healer and support",
        "primary_bonus": "wisdom",
        "secondary_bonus": "willpower",
        "role": "Healer"
    },
    "warden": {
        "name": "Warden",
        "description": "Battlefield controller",
        "primary_bonus": "willpower",
        "secondary_bonus": "wisdom",
        "role": "Controller"
    },
    "analyst": {
        "name": "Analyst",
        "description": "Knowledge and support",
        "primary_bonus": "intellect",
        "secondary_bonus": "wisdom",
        "role": "Support"
    },
    "speaker": {
        "name": "Speaker",
        "description": "Social and command",
        "primary_bonus": "presence",
        "secondary_bonus": "intellect",
        "role": "Face/Leader"
    }
}

# Class lookup table: CLASSES[aspect][archetype] = class_name
CLASSES = {
    "ore": {
        "striker": "Warlord", "guardian": "Knight", "hunter": "Arbalist",
        "skirmisher": "Saboteur", "mender": "Apothecary", "warden": "Sentinel",
        "analyst": "Artificer", "speaker": "Marshal"
    },
    "tide": {
        "striker": "Marauder", "guardian": "Bulwark", "hunter": "Deadeye",
        "skirmisher": "Corsair", "mender": "Wellspring", "warden": "Maelstrom",
        "analyst": "Diviner", "speaker": "Siren"
    },
    "pyre": {
        "striker": "Berserker", "guardian": "Immolator", "hunter": "Bombardier",
        "skirmisher": "Hellion", "mender": "Firekeeper", "warden": "Pyromancer",
        "analyst": "Alchemist", "speaker": "Firebrand"
    },
    "gale": {
        "striker": "Tempest", "guardian": "Vanguard", "hunter": "Windrunner",
        "skirmisher": "Dervish", "mender": "Monk", "warden": "Stormcaller",
        "analyst": "Tactician", "speaker": "Herald"
    },
    "radiance": {
        "striker": "Paladin", "guardian": "Templar", "hunter": "Inquisitor",
        "skirmisher": "Crusader", "mender": "Cleric", "warden": "Beacon",
        "analyst": "Oracle", "speaker": "Prophet"
    },
    "shroud": {
        "striker": "Reaper", "guardian": "Revenant", "hunter": "Wraith",
        "skirmisher": "Assassin", "mender": "Witch", "warden": "Hexer",
        "analyst": "Necromancer", "speaker": "Harbinger"
    },
    "anima": {
        "striker": "Savage", "guardian": "Beastmaster", "hunter": "Ranger",
        "skirmisher": "Prowler", "mender": "Druid", "warden": "Shaman",
        "analyst": "Sage", "speaker": "Chieftain"
    },
    "aether": {
        "striker": "Battlemage", "guardian": "Aegis", "hunter": "Warlock",
        "skirmisher": "Magus", "mender": "Mystic", "warden": "Spellbreaker",
        "analyst": "Arcanist", "speaker": "Enchanter"
    }
}

STAT_NAMES = ["might", "agility", "fortitude", "precision", "intellect", "wisdom", "willpower", "presence"]
STAT_ABBREV = {
    "might": "MIG", "agility": "AGI", "fortitude": "FOR", "precision": "PRC",
    "intellect": "INT", "wisdom": "WIS", "willpower": "WIL", "presence": "PRE"
}


# ═══════════════════════════════════════════════════════════════════════════════
# CLASS FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def get_class_name(aspect: str, archetype: str) -> str:
    """Get class name from aspect and archetype."""
    return CLASSES.get(aspect.lower(), {}).get(archetype.lower(), "Unknown")


# ═══════════════════════════════════════════════════════════════════════════════
# ATTRIBUTE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def get_modifier(score: int) -> int:
    """Get modifier from attribute score. (score - 10) // 2"""
    return (score - 10) // 2


def apply_aspect_archetype_bonuses(
    base_stats: Dict[str, int],
    aspect: str,
    archetype: str,
    level: int = 1
) -> Dict[str, int]:
    """
    Apply aspect and archetype bonuses to base stats.
    
    Aspect: +2 primary, +1 secondary
    Archetype: +2 primary, +1 secondary
    
    No level-based caps. Bonuses stack freely.
    Diminishing returns apply to level-up point investment (see attributes-core.md).
    """
    stats = base_stats.copy()
    
    # Aspect bonuses
    aspect_data = ASPECTS.get(aspect.lower())
    if aspect_data:
        stats[aspect_data["primary_bonus"]] = stats.get(aspect_data["primary_bonus"], 10) + 2
        stats[aspect_data["secondary_bonus"]] = stats.get(aspect_data["secondary_bonus"], 10) + 1
    
    # Archetype bonuses
    arch_data = ARCHETYPES.get(archetype.lower())
    if arch_data:
        stats[arch_data["primary_bonus"]] = stats.get(arch_data["primary_bonus"], 10) + 2
        stats[arch_data["secondary_bonus"]] = stats.get(arch_data["secondary_bonus"], 10) + 1
    
    # No caps applied - bonuses stack freely
    
    return stats


# ═══════════════════════════════════════════════════════════════════════════════
# DERIVED STATS
# ═══════════════════════════════════════════════════════════════════════════════

def calculate_derived_stats(
    stats: Dict[str, int],
    level: int = 1,
    armor_bonus: int = 0
) -> dict:
    """
    Calculate all derived stats from attributes.
    
    IMPORTANT: HP, Stamina, Mana, Composure use attribute SCORES, NOT modifiers.
    
    Returns dict with all derived values.
    """
    
    # Get scores (default to 10)
    mig = stats.get("might", 10)
    agi = stats.get("agility", 10)
    for_ = stats.get("fortitude", 10)
    prc = stats.get("precision", 10)
    int_ = stats.get("intellect", 10)
    wis = stats.get("wisdom", 10)
    wil = stats.get("willpower", 10)
    pre = stats.get("presence", 10)
    
    # Get modifiers
    mig_mod = get_modifier(mig)
    agi_mod = get_modifier(agi)
    for_mod = get_modifier(for_)
    prc_mod = get_modifier(prc)
    int_mod = get_modifier(int_)
    wis_mod = get_modifier(wis)
    wil_mod = get_modifier(wil)
    pre_mod = get_modifier(pre)
    
    # Resource pools (use SCORES, not modifiers)
    # HP: Split between MIG and FOR for balance
    hp = 20 + (mig * 2) + (for_ * 2) + (level * 3)
    stamina = 10 + (for_ * 2) + agi + level
    mana = 10 + (int_ * 2) + (wil * 2) + level
    # Composure: New resource for PRE-based characters
    composure = 10 + (pre * 2) + wil + level
    
    # Defense values (use modifiers)
    physical_def = 10 + agi_mod + armor_bonus
    mental_def = 10 + wil_mod
    resistance_dc = 10 + wis_mod + wil_mod
    
    # Combat values
    initiative = agi_mod + prc_mod
    base_movement = 6 + agi_mod
    
    # Crit threshold based on PRC
    if prc_mod >= 7:
        crit_threshold = 9
    elif prc_mod >= 5:
        crit_threshold = 10
    elif prc_mod >= 3:
        crit_threshold = 11
    else:
        crit_threshold = 12
    
    return {
        "hp": {"current": hp, "max": hp},
        "stamina": {"current": stamina, "max": stamina},
        "mana": {"current": mana, "max": mana},
        "composure": {"current": composure, "max": composure},
        "physical_def": physical_def,
        "mental_def": mental_def,
        "resistance_dc": resistance_dc,
        "initiative": initiative,
        "movement": base_movement,
        "crit_threshold": crit_threshold,
        "modifiers": {
            "might": mig_mod,
            "agility": agi_mod,
            "fortitude": for_mod,
            "precision": prc_mod,
            "intellect": int_mod,
            "wisdom": wis_mod,
            "willpower": wil_mod,
            "presence": pre_mod
        }
    }


def format_character_stats(
    name: str,
    stats: Dict[str, int],
    derived: dict,
    level: int,
    aspect: str,
    archetype: str
) -> str:
    """Format character stats for display."""
    lines = []
    
    class_name = get_class_name(aspect, archetype)
    lines.append(f"# {name}")
    lines.append(f"**Level {level} {class_name}** ({aspect.capitalize()} × {archetype.capitalize()})")
    lines.append("")
    
    # Attributes
    lines.append("## Attributes")
    lines.append("")
    attr_line = ""
    for stat in STAT_NAMES:
        score = stats.get(stat, 10)
        mod = derived["modifiers"][stat]
        abbrev = STAT_ABBREV[stat]
        attr_line += f"**{abbrev}** {score} ({mod:+d}) | "
    lines.append(attr_line.rstrip(" | "))
    lines.append("")
    
    # Resources
    lines.append("## Resources")
    lines.append("")
    lines.append(f"| Stat | Current / Max | Formula (Uses SCORES) |")
    lines.append(f"|------|---------------|----------------------|")
    lines.append(f"| **HP** | {derived['hp']['current']} / {derived['hp']['max']} | 20 + (FOR × 3) + MIG + (Lv × 2) |")
    lines.append(f"| **Stamina** | {derived['stamina']['current']} / {derived['stamina']['max']} | 15 + (FOR × 2) + AGI + Lv |")
    lines.append(f"| **Mana** | {derived['mana']['current']} / {derived['mana']['max']} | 10 + (INT × 2) + (WIL × 2) + Lv |")
    lines.append("")
    
    # Combat
    lines.append("## Combat")
    lines.append("")
    lines.append(f"| Physical DEF | Mental DEF | Initiative | Movement | Crit Threshold |")
    lines.append(f"|--------------|------------|------------|----------|----------------|")
    lines.append(f"| {derived['physical_def']} | {derived['mental_def']} | {derived['initiative']:+d} | {derived['movement']}m | {derived['crit_threshold']}+ |")
    
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# FORM SLOTS
# ═══════════════════════════════════════════════════════════════════════════════

FORM_SLOT_PROGRESSION = {
    1: 2, 4: 3, 8: 4, 12: 5, 16: 6, 20: 7, 24: 8, 28: 9
}

def get_form_slots(level: int) -> int:
    """Get number of form slots at given level."""
    slots = 2
    for lvl, slot_count in sorted(FORM_SLOT_PROGRESSION.items()):
        if level >= lvl:
            slots = slot_count
    return slots


# ═══════════════════════════════════════════════════════════════════════════════
# TALENT SLOTS
# ═══════════════════════════════════════════════════════════════════════════════

def get_talent_count(level: int) -> int:
    """Get number of talents at given level. +1 per level starting at 2."""
    return max(0, level - 1)


# ═══════════════════════════════════════════════════════════════════════════════
# TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== CHARACTER SYSTEM TEST ===\n")
    
    # Test class lookup
    print("--- Class Lookup ---")
    print(f"Ore × Guardian = {get_class_name('ore', 'guardian')}")
    print(f"Shroud × Skirmisher = {get_class_name('shroud', 'skirmisher')}")
    print(f"Radiance × Mender = {get_class_name('radiance', 'mender')}")
    
    # Base stats (before aspect/archetype)
    base_stats = {
        "might": 10, "agility": 10, "fortitude": 10, "precision": 10,
        "intellect": 10, "wisdom": 10, "willpower": 10, "presence": 10
    }
    
    print("\n--- Base Stats ---")
    print(base_stats)
    
    print("\n--- After Ore/Guardian (Knight) Bonuses ---")
    final_stats = apply_aspect_archetype_bonuses(base_stats, "ore", "guardian")
    print(f"Class: {get_class_name('ore', 'guardian')}")
    print(f"FOR should be capped at 12 (would be 14): {final_stats['fortitude']}")
    print(final_stats)
    
    print("\n--- Derived Stats (Level 4) ---")
    derived = calculate_derived_stats(final_stats, level=4, armor_bonus=3)
    print(f"HP: {derived['hp']['max']} (uses FOR score {final_stats['fortitude']})")
    print(f"Stamina: {derived['stamina']['max']}")
    print(f"Mana: {derived['mana']['max']}")
    print(f"Physical DEF: {derived['physical_def']} (includes +3 armor)")
    print(f"Mental DEF: {derived['mental_def']}")
    print(f"Initiative: {derived['initiative']:+d}")
    print(f"Movement: {derived['movement']}m")
    print(f"Crit Threshold: {derived['crit_threshold']}+")
    
    print("\n--- Form Slots by Level ---")
    for lvl in [1, 4, 8, 12, 16, 20, 24, 28, 30]:
        print(f"Level {lvl}: {get_form_slots(lvl)} slots")
    
    print("\n--- Formatted Character Sheet ---")
    print(format_character_stats(
        name="Test Knight",
        stats=final_stats,
        derived=derived,
        level=4,
        aspect="ore",
        archetype="guardian"
    ))
