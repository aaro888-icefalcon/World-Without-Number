"""
EMERGENCE: THE EXILE — Adventure Seed Generator
Connects scenes into adventures using situation tags, NPC character tags,
faction dynamics, and clocks from the tables package.
"""

import random
from typing import Optional, List, Dict

try:
    from .dice import generate_id
except ImportError:
    from dice import generate_id

import sys, os
_script_dir = os.path.dirname(os.path.abspath(__file__))
_parent_dir = os.path.dirname(_script_dir)
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)

try:
    from tables.adventure_seeds import generate_adventure_seed, generate_adventure_hook
    from tables.situation_tags import roll_situation_tags
    TABLES_AVAILABLE = True
except ImportError:
    TABLES_AVAILABLE = False


def generate_adventure(world_state: dict, current_location: dict = None,
                       seed_type: str = None, depth: int = 1) -> dict:
    """
    Generate an adventure from world state.
    depth: 1=hook, 2=hook+scenes, 3=full adventure with twist.
    """
    if not TABLES_AVAILABLE:
        return {"id": generate_id("adv_"), "seed_type": "conflict",
                "hook": "A crisis requires immediate action. Multiple factions involved.",
                "components": {}, "scenes": [],
                "stakes": "Success prevents disaster.", "failure_consequence": "Situation worsens."}

    threat_level = current_location.get("threat_level", 2) if current_location else 2
    seed = generate_adventure_seed(world_state, seed_type=seed_type, threat_level=threat_level)

    adventure = {
        "id": generate_id("adv_"), "seed_type": seed["seed_type"],
        "hook": seed["text"], "components": seed["components"], "scenes": [],
        "stakes": _stakes(seed), "failure_consequence": _failure(seed),
    }

    if depth >= 2:
        adventure["scenes"] = _scene_outline(seed)
    if depth >= 3:
        adventure["situation_context"] = roll_situation_tags(2)
        adventure["twist"] = _twist()

    return adventure


def _stakes(seed):
    by_type = {
        "conflict": ["Prevents escalation into full-scale war.", "Secures critical resources.", "Establishes reputation as a power that matters."],
        "rescue": ["Saves lives and earns fierce loyalty.", "Prevents a faction from losing a key member.", "Demonstrates people aren't expendable."],
        "heist": ["Acquires something that shifts the balance.", "Proves capability for high-risk ops.", "Denies the enemy a critical asset."],
        "mystery": ["Reveals a hidden truth.", "Prevents a danger nobody else identified.", "Builds intelligence network."],
        "dilemma": ["No clean win. Best outcome still costs something.", "Choosing well earns respect. Poorly earns enemies.", "The decision reveals character."],
        "clock": ["Buys time for the community.", "Prevents catastrophe.", "Demonstrates clocks can be stopped."],
        "social": ["Reshapes faction relationships.", "Builds alliances for the real crisis.", "Prevents internal collapse."],
    }
    return random.choice(by_type.get(seed["seed_type"], by_type["conflict"]))


def _failure(seed):
    return random.choice([
        "Situation deteriorates. Clock advances 1-2 segments.",
        "Someone dies who didn't need to. The community remembers.",
        "The enemy achieves their objective. Power shifts against players.",
        "An ally loses faith and pivots to another patron.",
        "The resource is lost, destroyed, or in wrong hands.",
        "Faction relations worsen. Future cooperation harder.",
        "Community morale takes a hit.",
        "The problem comes back worse next time.",
    ])


def _scene_outline(seed):
    structures = {
        "conflict": [{"name": "Intelligence Gathering", "type": "social", "goal": "Learn enemy disposition"}, {"name": "Approach", "type": "exploration", "goal": "Get into position"}, {"name": "Confrontation", "type": "danger_zone", "goal": "Execute the plan"}],
        "rescue": [{"name": "Finding the Trail", "type": "exploration", "goal": "Locate target"}, {"name": "Reaching the Target", "type": "danger_zone", "goal": "Navigate obstacles"}, {"name": "Extraction", "type": "danger_zone", "goal": "Get them out alive"}],
        "heist": [{"name": "Casing", "type": "social", "goal": "Gather intel on security"}, {"name": "Infiltration", "type": "exploration", "goal": "Get inside"}, {"name": "The Grab", "type": "danger_zone", "goal": "Acquire target and escape"}],
        "mystery": [{"name": "Initial Clues", "type": "social", "goal": "Interview and examine"}, {"name": "Following Thread", "type": "exploration", "goal": "Investigate leads"}, {"name": "Confronting Truth", "type": "social", "goal": "Reveal findings"}],
        "dilemma": [{"name": "Understanding Both Sides", "type": "social", "goal": "Gather perspectives"}, {"name": "Seeking Third Option", "type": "exploration", "goal": "Find alternative"}, {"name": "The Decision", "type": "social", "goal": "Choose and live with it"}],
        "clock": [{"name": "Assessment", "type": "exploration", "goal": "Determine needs"}, {"name": "Acquisition", "type": "danger_zone", "goal": "Get what you need"}, {"name": "Implementation", "type": "danger_zone", "goal": "Apply the solution"}],
        "social": [{"name": "Preparation", "type": "social", "goal": "Gather allies"}, {"name": "Main Event", "type": "social", "goal": "Navigate the challenge"}, {"name": "Aftermath", "type": "exploration", "goal": "Deal with consequences"}],
    }
    scenes = structures.get(seed["seed_type"], structures["conflict"])
    if len(scenes) >= 2:
        scenes[1]["complication"] = seed["components"].get("complication", "unexpected resistance")
    return scenes


def _twist():
    return random.choice([
        "The real enemy isn't who everyone thinks.",
        "The objective has already been compromised.",
        "An ally switches sides mid-adventure.",
        "Succeeding at the stated goal would make things worse.",
        "A third faction arrives with their own agenda.",
        "The person you're helping doesn't want help — and has good reasons.",
        "The 'enemy' has a legitimate grievance.",
        "A clock you didn't know about just completed.",
        "The macguffin isn't what it seems.",
        "Someone in the party's past is connected.",
    ])


if __name__ == "__main__":
    print(f"=== ADVENTURE GENERATOR TEST (tables={TABLES_AVAILABLE}) ===\n")
    ws = {
        "human_factions": [
            {"id": "f1", "name": "The Exchange", "npcs": [{"role": "Boss", "name": "Marcus Cole"}, {"role": "Negotiator", "name": "Ana Reyes"}]},
            {"id": "f2", "name": "Iron Watch", "npcs": [{"role": "Commander", "name": "Sarah Kim"}]},
        ],
        "external_threats": [{"id": "t1", "name": "The Thornwood Swarm"}],
        "clocks": [{"name": "Monster Pressure", "current": 4, "max": 6}],
    }
    adv = generate_adventure(ws, {"threat_level": 3}, depth=3)
    print(f"[{adv['seed_type'].upper()}] {adv['hook']}")
    print(f"Stakes: {adv['stakes']}")
    if adv.get("scenes"):
        for s in adv["scenes"]:
            print(f"  Scene: {s['name']} ({s['type']})")
    if adv.get("twist"):
        print(f"Twist: {adv['twist']}")
