"""
EMERGENCE: THE EXILE — Dice & Random Systems
Core rolling functions used by all other scripts.
"""

import random
from typing import Tuple, Optional, List

# ═══════════════════════════════════════════════════════════════════════════════
# CORE DICE
# ═══════════════════════════════════════════════════════════════════════════════

def roll_2d6(
    modifier: int = 0,
    advantage: bool = False,
    disadvantage: bool = False
) -> dict:
    """
    Roll 2d6 + modifier.
    Advantage: Roll 3d6, keep highest 2.
    Disadvantage: Roll 3d6, keep lowest 2.
    """
    if advantage and not disadvantage:
        dice = sorted([random.randint(1, 6) for _ in range(3)], reverse=True)
        d1, d2 = dice[0], dice[1]
        roll_type = "advantage"
    elif disadvantage and not advantage:
        dice = sorted([random.randint(1, 6) for _ in range(3)])
        d1, d2 = dice[0], dice[1]
        roll_type = "disadvantage"
    else:
        d1, d2 = random.randint(1, 6), random.randint(1, 6)
        dice = [d1, d2]
        roll_type = "normal"
    
    base = d1 + d2
    total = base + modifier
    
    # Check for criticals
    is_crit = (d1 == 6 and d2 == 6)
    is_fumble = (d1 == 1 and d2 == 1)
    
    return {
        "dice": dice,
        "d1": d1,
        "d2": d2,
        "base": base,
        "modifier": modifier,
        "total": total,
        "roll_type": roll_type,
        "is_crit": is_crit,
        "is_fumble": is_fumble
    }


def check_vs_dc(roll_result: dict, dc: int, crit_threshold: int = 12) -> dict:
    """
    Check a roll result against a DC.
    
    Returns hit band:
    - crit_hit: Natural crit (based on crit_threshold)
    - crit_miss: Double 1s
    - exceptional: Total >= DC + 4
    - hit: Total >= DC
    - graze: Total = DC-1 or DC-2
    - miss: Total <= DC-3
    """
    total = roll_result["total"]
    d1, d2 = roll_result["d1"], roll_result["d2"]
    
    # Check criticals first
    if d1 == 1 and d2 == 1:
        band = "crit_miss"
        success = False
    elif d1 + d2 >= crit_threshold:
        band = "crit_hit"
        success = True
    elif total >= dc + 4:
        band = "exceptional"
        success = True
    elif total >= dc:
        band = "hit"
        success = True
    elif total >= dc - 2:
        band = "graze"
        success = True  # Partial success
    else:
        band = "miss"
        success = False
    
    return {
        **roll_result,
        "dc": dc,
        "band": band,
        "success": success
    }


def get_crit_threshold(precision_mod: int) -> int:
    """
    Get crit threshold based on Precision modifier.
    Higher PRC = crits on lower totals.
    """
    if precision_mod >= 7:
        return 9   # 27.78% crit rate
    elif precision_mod >= 5:
        return 10  # 16.67%
    elif precision_mod >= 3:
        return 11  # 8.33%
    else:
        return 12  # 2.78% (default, double 6s only)


# ═══════════════════════════════════════════════════════════════════════════════
# LOOT TABLES
# ═══════════════════════════════════════════════════════════════════════════════

LOOT_TABLES = {
    "minion": {
        "nothing": 95,
        "common_item": 4,
        "skill_stone": 1
    },
    "standard": {
        "nothing": 85,
        "common_item": 10,
        "uncommon_item": 3,
        "technique_scroll_t1": 1,
        "skill_stone": 1
    },
    "elite": {
        "nothing": 60,
        "common_item": 15,
        "uncommon_item": 15,
        "rare_item": 3,
        "technique_scroll_t1": 3,
        "technique_scroll_t2": 2,
        "skill_stone": 2
    },
    "boss": {
        "nothing": 20,
        "uncommon_item": 25,
        "rare_item": 25,
        "epic_item": 10,
        "technique_scroll_t1": 5,
        "technique_scroll_t2": 5,
        "technique_scroll_t3": 5,
        "skill_stone": 5
    }
}

def roll_loot(source_type: str = "standard") -> dict:
    """
    Roll for loot based on enemy type.
    Returns loot category and whether anything dropped.
    """
    table = LOOT_TABLES.get(source_type.lower(), LOOT_TABLES["standard"])
    
    roll = random.randint(1, 100)
    cumulative = 0
    
    for category, chance in table.items():
        cumulative += chance
        if roll <= cumulative:
            return {
                "roll": roll,
                "source_type": source_type,
                "category": category,
                "dropped": category != "nothing"
            }
    
    return {
        "roll": roll,
        "source_type": source_type,
        "category": "nothing",
        "dropped": False
    }


# ═══════════════════════════════════════════════════════════════════════════════
# WEIGHTED RANDOM
# ═══════════════════════════════════════════════════════════════════════════════

def weighted_choice(options: List[Tuple[any, int]]) -> any:
    """
    Select from weighted options.
    options: List of (item, weight) tuples.
    """
    total = sum(weight for _, weight in options)
    roll = random.randint(1, total)
    
    cumulative = 0
    for item, weight in options:
        cumulative += weight
        if roll <= cumulative:
            return item
    
    return options[-1][0]  # Fallback


def roll_on_table(table: dict) -> str:
    """
    Roll on a simple {option: weight} table.
    """
    options = [(k, v) for k, v in table.items()]
    return weighted_choice(options)


# ═══════════════════════════════════════════════════════════════════════════════
# UTILITY
# ═══════════════════════════════════════════════════════════════════════════════

def roll_stat_array(total_points: int, num_stats: int = 8, min_val: int = 8, max_val: int = 20) -> List[int]:
    """
    Generate a stat array that sums to total_points.
    Used for NPC generation.
    """
    stats = [min_val] * num_stats
    remaining = total_points - (min_val * num_stats)
    
    while remaining > 0:
        idx = random.randint(0, num_stats - 1)
        if stats[idx] < max_val:
            add = min(remaining, random.randint(1, 3), max_val - stats[idx])
            stats[idx] += add
            remaining -= add
    
    return stats


def generate_id(prefix: str = "") -> str:
    """Generate a unique-ish ID."""
    return f"{prefix}{random.randint(10000, 99999)}"


# ═══════════════════════════════════════════════════════════════════════════════
# TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== DICE SYSTEM TEST ===\n")
    
    print("--- Basic Roll ---")
    result = roll_2d6(modifier=3)
    print(f"2d6+3: {result['dice']} + 3 = {result['total']}")
    
    print("\n--- Advantage Roll ---")
    result = roll_2d6(modifier=2, advantage=True)
    print(f"2d6+2 (adv): {result['dice']} keep best 2 + 2 = {result['total']}")
    
    print("\n--- DC Check ---")
    roll = roll_2d6(modifier=4)
    check = check_vs_dc(roll, dc=12)
    print(f"Roll {check['total']} vs DC 12: {check['band']}")
    
    print("\n--- Crit Thresholds ---")
    for prc in [0, 3, 5, 7]:
        thresh = get_crit_threshold(prc)
        print(f"PRC mod +{prc}: Crit on {thresh}+")
    
    print("\n--- Loot Rolls ---")
    for source in ["minion", "standard", "elite", "boss"]:
        loot = roll_loot(source)
        print(f"{source}: {loot['category']}")
    
    print("\n--- Stat Array ---")
    stats = roll_stat_array(80)
    print(f"80-point array: {stats} (sum: {sum(stats)})")
