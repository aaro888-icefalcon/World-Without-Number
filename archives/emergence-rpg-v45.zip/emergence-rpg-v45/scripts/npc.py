"""
EMERGENCE: THE EXILE — NPC Generation
Quick NPCs (social) and Awakened NPCs (combat) with deep character tags from tables.
"""

import random
from typing import Optional, List, Dict

try:
    from .dice import generate_id, roll_stat_array
except ImportError:
    from dice import generate_id, roll_stat_array

# Tables integration (graceful fallback)
try:
    import sys, os
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _parent_dir = os.path.dirname(_script_dir)
    if _parent_dir not in sys.path:
        sys.path.insert(0, _parent_dir)
    from tables.npc_depth import get_npc_depth
    TABLES_AVAILABLE = True
except ImportError:
    TABLES_AVAILABLE = False

# ═══════════════════════════════════════════════════════════════════════════════
# NAME GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

FIRST_NAMES = {
    "common": [
        "James", "Maria", "Michael", "Jennifer", "David", "Sarah", "Robert", "Lisa",
        "John", "Michelle", "William", "Jessica", "Richard", "Amanda", "Joseph", "Ashley",
        "Marcus", "Destiny", "Anthony", "Jasmine", "Kevin", "Nicole", "Brian", "Samantha",
        "Carlos", "Ana", "Jose", "Rosa", "Miguel", "Carmen", "Luis", "Elena",
        "Wei", "Mei", "Jin", "Li", "Chen", "Yan", "Raj", "Priya",
    ],
    "nickname": [
        "Doc", "Red", "Slim", "Tank", "Ghost", "Ace", "Zero", "Blade",
        "Spark", "Shade", "Bolt", "Ash", "Storm", "Crow", "Wolf", "Hawk",
    ],
}

LAST_NAMES = [
    "Chen", "Rodriguez", "Williams", "Garcia", "Johnson", "Martinez", "Brown", "Davis",
    "Miller", "Wilson", "Anderson", "Taylor", "Thomas", "Moore", "Jackson", "Lee",
    "Perez", "Thompson", "White", "Lopez", "Gonzalez", "Harris", "Clark", "Lewis",
    "Robinson", "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres",
    "Kim", "Patel", "Shah", "Singh", "Nguyen", "Tran", "Reyes", "Cruz",
]

def generate_name(use_nickname: bool = False) -> str:
    if use_nickname and random.random() < 0.3:
        return random.choice(FIRST_NAMES["nickname"])
    return f"{random.choice(FIRST_NAMES['common'])} {random.choice(LAST_NAMES)}"

# ═══════════════════════════════════════════════════════════════════════════════
# FALLBACK PERSONALITY (used when tables not available)
# ═══════════════════════════════════════════════════════════════════════════════

MOTIVATIONS_FALLBACK = [
    "Protect family/loved ones", "Accumulate power/resources", "Find meaning in the new world",
    "Return to normalcy", "Exploit the chaos", "Prove themselves", "Revenge against someone",
    "Survive at any cost", "Help others survive", "Understand the System",
    "Build something lasting", "Find someone missing",
]

SECRETS_FALLBACK = [
    "Killed someone during the chaos", "Hoarding critical supplies",
    "Working for a rival faction", "Hiding a loved one who's sick/injured",
    "Planning to betray their faction", "Has information about a threat",
    "Stole something valuable", "Witnessed something they shouldn't have",
    "Has a hidden awakened ability", "In debt to a dangerous person",
    "Knows a safe route/location", "Has pre-Transit skills useful here",
]

DISPOSITIONS = {
    "hostile": {"reaction_mod": -4, "trust_threshold": 16},
    "wary": {"reaction_mod": -2, "trust_threshold": 14},
    "neutral": {"reaction_mod": 0, "trust_threshold": 12},
    "friendly": {"reaction_mod": 2, "trust_threshold": 10},
    "allied": {"reaction_mod": 4, "trust_threshold": 8},
}

PERSONALITY_TRAITS = [
    "pragmatic", "idealistic", "paranoid", "trusting", "aggressive", "cautious",
    "greedy", "generous", "vengeful", "forgiving", "ambitious", "content",
    "curious", "incurious", "hopeful", "cynical", "loyal", "opportunistic",
]


def _get_depth(faction_archetype: str = None) -> dict:
    """Get NPC depth from tables or fallback."""
    if TABLES_AVAILABLE:
        return get_npc_depth(faction_archetype)
    return {
        "character_tags": None,
        "active_ambition": None,
        "active_dread": None,
        "leverage": None,
        "motivation": random.choice(MOTIVATIONS_FALLBACK),
        "secret": random.choice(SECRETS_FALLBACK) if random.random() < 0.5 else None,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# QUICK NPC GENERATION (Non-Combat)
# ═══════════════════════════════════════════════════════════════════════════════

def generate_quick_npc(
    faction_id: str = None, faction_name: str = None,
    faction_archetype: str = None,
    role: str = None, disposition: str = None, name: str = None,
) -> dict:
    """
    Generate a quick NPC for social encounters.
    Now includes character tags, ambitions, dreads, and leverage from tables.
    """
    if name is None:
        name = generate_name(use_nickname=(role and "criminal" in role.lower()))
    if role is None:
        role = random.choice(["Survivor", "Scavenger", "Guard", "Trader", "Messenger", "Refugee"])
    if disposition is None:
        disposition = random.choice(["wary", "neutral", "neutral", "friendly"])

    traits = random.sample(PERSONALITY_TRAITS, 2)
    depth = _get_depth(faction_archetype)

    return {
        "id": generate_id("npc_"),
        "name": name,
        "role": role,
        "faction_id": faction_id,
        "faction_name": faction_name,
        "disposition": disposition,
        "traits": traits,
        # Deep character data from tables
        "character_tags": depth.get("character_tags"),
        "active_ambition": depth.get("active_ambition"),
        "active_dread": depth.get("active_dread"),
        "leverage": depth.get("leverage"),
        "motivation": depth["motivation"],
        "secret": depth["secret"],
        # State
        "status": "active",
        "location": None,
        "last_seen_day": None,
        "notes": "",
        "is_awakened": False,
        "combat_stats": None,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# AWAKENED NPC GENERATION (Combat-Capable)
# ═══════════════════════════════════════════════════════════════════════════════

ASPECTS = ["ore", "tide", "pyre", "gale", "radiance", "shroud", "anima", "aether"]
ARCHETYPES = ["striker", "guardian", "hunter", "skirmisher", "mender", "warden", "analyst", "speaker"]

ARCHETYPE_STATS = {
    "striker": {"primary": "might", "secondary": "fortitude", "dump": "intellect"},
    "guardian": {"primary": "fortitude", "secondary": "willpower", "dump": "agility"},
    "hunter": {"primary": "precision", "secondary": "agility", "dump": "presence"},
    "skirmisher": {"primary": "agility", "secondary": "precision", "dump": "willpower"},
    "mender": {"primary": "wisdom", "secondary": "willpower", "dump": "might"},
    "warden": {"primary": "willpower", "secondary": "wisdom", "dump": "agility"},
    "analyst": {"primary": "intellect", "secondary": "wisdom", "dump": "might"},
    "speaker": {"primary": "presence", "secondary": "intellect", "dump": "fortitude"},
}

STAT_NAMES = ["might", "agility", "fortitude", "precision", "intellect", "wisdom", "willpower", "presence"]
STAT_ABBREV = {"might": "MIG", "agility": "AGI", "fortitude": "FOR", "precision": "PRC",
               "intellect": "INT", "wisdom": "WIS", "willpower": "WIL", "presence": "PRE"}

def generate_stat_block(level: int, archetype: str) -> dict:
    arch_data = ARCHETYPE_STATS.get(archetype, ARCHETYPE_STATS["striker"])
    total = 70 + level
    stats = {name: 10 for name in STAT_NAMES}
    remaining = total - 80
    primary_add = int(remaining * 0.4)
    stats[arch_data["primary"]] += primary_add
    remaining -= primary_add
    secondary_add = int(remaining * 0.35)
    stats[arch_data["secondary"]] += secondary_add
    remaining -= secondary_add
    other_stats = [s for s in STAT_NAMES if s not in [arch_data["primary"], arch_data["secondary"], arch_data["dump"]]]
    while remaining > 0 and other_stats:
        stat = random.choice(other_stats)
        add = min(random.randint(1, 3), remaining)
        stats[stat] += add
        remaining -= add
    return stats


def calculate_npc_derived_stats(stats: dict, level: int, armor_bonus: int = 0) -> dict:
    mod = lambda s: (s - 10) // 2
    hp = 20 + (stats["fortitude"] * 2) + (stats["might"]) + (level * 5)
    stamina = 10 + (stats["fortitude"] * 2) + (stats["might"]) + level
    mana = 10 + (stats["intellect"] * 2) + (stats["willpower"] * 2) + level
    return {
        "hp": {"current": hp, "max": hp},
        "stamina": {"current": stamina, "max": stamina},
        "mana": {"current": mana, "max": mana},
        "physical_def": 10 + mod(stats["agility"]) + armor_bonus,
        "mental_def": 10 + mod(stats["willpower"]),
        "initiative": mod(stats["agility"]) + mod(stats["precision"]),
        "movement": 6 + mod(stats["agility"]),
    }


NPC_TIERS = {
    "grunt": {"level_mod": -2, "abilities": 0, "talents": 0},
    "veteran": {"level_mod": 0, "abilities": 1, "talents": 2},
    "awakened": {"level_mod": 0, "abilities": 2, "talents": 4},
    "champion": {"level_mod": 2, "abilities": 3, "talents": 6},
    "legend": {"level_mod": 4, "abilities": 4, "talents": 8},
}

SIGNATURE_ABILITIES = [
    {"name": "Crushing Blow", "effect": "+50% damage, target knocked prone", "cost": "3 Stamina"},
    {"name": "Whirlwind Strike", "effect": "Attack all adjacent enemies", "cost": "4 Stamina"},
    {"name": "Precise Strike", "effect": "Ignore armor, +2 crit range", "cost": "2 Stamina"},
    {"name": "Shield Bash", "effect": "Stun target for 1 round", "cost": "2 Stamina"},
    {"name": "Flame Burst", "effect": "3d6 fire damage in 3m radius", "cost": "5 Mana"},
    {"name": "Shadow Step", "effect": "Teleport 10m, next attack has advantage", "cost": "4 Mana"},
    {"name": "Healing Touch", "effect": "Heal ally for 2d6+WIS", "cost": "4 Mana"},
    {"name": "Battle Cry", "effect": "Allies gain +2 attack for 2 rounds", "cost": "3 Stamina"},
    {"name": "Evasive Maneuver", "effect": "Avoid one attack, move 4m", "cost": "Reaction"},
    {"name": "Counter Strike", "effect": "When hit, deal weapon damage to attacker", "cost": "Reaction"},
]


def generate_awakened_npc(
    level: int, tier: str = "awakened",
    faction_id: str = None, faction_name: str = None,
    faction_archetype: str = None,
    role: str = None, aspect: str = None, archetype: str = None, name: str = None,
) -> dict:
    """Generate a combat-capable Awakened NPC with deep character tags."""
    tier_data = NPC_TIERS.get(tier, NPC_TIERS["awakened"])
    effective_level = max(1, level + tier_data["level_mod"])

    if aspect is None: aspect = random.choice(ASPECTS)
    if archetype is None: archetype = random.choice(ARCHETYPES)
    if name is None: name = generate_name(use_nickname=True)
    if role is None:
        role = {"striker": "Assault", "guardian": "Tank", "hunter": "Sniper", "skirmisher": "Scout",
                "mender": "Medic", "warden": "Controller", "analyst": "Support", "speaker": "Commander"}.get(archetype, "Combatant")

    stats = generate_stat_block(effective_level, archetype)
    armor = {"striker": 2, "guardian": 4, "hunter": 1, "skirmisher": 1, "mender": 1, "warden": 2, "analyst": 1, "speaker": 2}.get(archetype, 2)
    derived = calculate_npc_derived_stats(stats, effective_level, armor)

    weapon = {"striker": {"name": "Heavy Weapon", "damage": "1d10", "type": "melee"},
              "guardian": {"name": "Sword & Shield", "damage": "1d8", "type": "melee"},
              "hunter": {"name": "Rifle", "damage": "1d10", "type": "ranged"},
              "skirmisher": {"name": "Paired Daggers", "damage": "1d6×2", "type": "melee"},
              "mender": {"name": "Staff", "damage": "1d6", "type": "melee"},
              "warden": {"name": "Polearm", "damage": "1d8", "type": "melee"},
              "analyst": {"name": "Pistol", "damage": "1d6", "type": "ranged"},
              "speaker": {"name": "Sword", "damage": "1d8", "type": "melee"}}.get(archetype, {"name": "Heavy Weapon", "damage": "1d10", "type": "melee"})

    primary_stat = ARCHETYPE_STATS[archetype]["primary"]
    attack_mod = (stats[primary_stat] - 10) // 2 + effective_level // 4
    damage_mod = (stats[primary_stat] - 10) // 2
    abilities = random.sample(SIGNATURE_ABILITIES, min(tier_data["abilities"], len(SIGNATURE_ABILITIES)))

    behaviors = {
        "striker": "Aggressive. Targets highest-value enemy. Uses heavy attacks.",
        "guardian": "Protective. Positions between enemies and allies. Absorbs damage.",
        "hunter": "Careful. Maintains distance. Focuses fire on wounded.",
        "skirmisher": "Mobile. Flanks. Disengages when pressured.",
        "mender": "Supportive. Heals allies. Avoids direct combat.",
        "warden": "Controlling. Uses area denial. Protects allies.",
        "analyst": "Tactical. Buffs allies. Debuffs enemies.",
        "speaker": "Commanding. Coordinates allies. Targets morale.",
    }

    depth = _get_depth(faction_archetype)

    return {
        "id": generate_id("npc_"), "name": name, "role": role, "tier": tier,
        "level": effective_level, "aspect": aspect, "archetype": archetype,
        "faction_id": faction_id, "faction_name": faction_name,
        "stats": stats, "derived": derived, "armor": armor, "weapon": weapon,
        "attack_mod": attack_mod, "damage_mod": damage_mod,
        "abilities": abilities, "behavior": behaviors.get(archetype, "Fights tactically."),
        "disposition": "hostile",
        # Deep character data
        "character_tags": depth.get("character_tags"),
        "active_ambition": depth.get("active_ambition"),
        "active_dread": depth.get("active_dread"),
        "leverage": depth.get("leverage"),
        "motivation": depth["motivation"],
        "secret": depth["secret"],
        "conditions": [], "zone": None, "telegraph": None,
        "status": "active", "is_awakened": True,
    }


if __name__ == "__main__":
    print(f"=== NPC GENERATION TEST (tables={TABLES_AVAILABLE}) ===\n")

    npc = generate_quick_npc(faction_name="The Exchange", faction_archetype="trade", role="Trader")
    print(f"**{npc['name']}** — {npc['role']} ({npc['faction_name']})")
    print(f"Traits: {', '.join(npc['traits'])} | Disposition: {npc['disposition']}")
    if npc.get("character_tags"):
        for tag in npc["character_tags"]:
            print(f"  Tag: [{tag['key']}] {tag['desc']}")
    if npc.get("active_ambition"):
        print(f"  Ambition: {npc['active_ambition']}")
    if npc.get("active_dread"):
        print(f"  Dread: {npc['active_dread']}")
    if npc.get("leverage"):
        print(f"  Leverage: {npc['leverage']}")
    print(f"  Motivation: {npc['motivation']}")
    if npc.get("secret"):
        print(f"  Secret: {npc['secret']}")

    print()
    awk = generate_awakened_npc(5, "veteran", faction_name="The Sentinels", faction_archetype="military")
    print(f"**{awk['name']}** — Lv{awk['level']} {awk['tier']} {awk['role']}")
    print(f"HP: {awk['derived']['hp']['max']} | DEF: {awk['derived']['physical_def']} | ATK: +{awk['attack_mod']}")
    if awk.get("character_tags"):
        for tag in awk["character_tags"]:
            print(f"  Tag: [{tag['key']}] {tag['desc']}")
