# Equipment

## Weapon System

### Weapon Categories

| Category | Examples | Default Attr | Base Damage | Range |
|----------|----------|--------------|-------------|-------|
| **Heavy Melee** | Greatsword, Maul, Greataxe | MIG | 10 | Melee |
| **Medium Melee** | Longsword, Mace, Spear | MIG | 8 | Melee |
| **Light Melee** | Dagger, Rapier, Shortsword | AGI | 6 | Melee |
| **Unarmed** | Fists, Kicks, Grappling | MIG | 4 | Melee |
| **Bows** | Shortbow, Longbow | PRC | 6 | 30m/60m |
| **Crossbows** | Hand, Light, Heavy | PRC | 4/6/8 | 20m/40m/60m |
| **Thrown** | Knives, Javelins | AGI | 4 | 10m/20m |

### Base Requirements

| Category | Requirement | Penalty If Unmet |
|----------|-------------|------------------|
| Heavy Melee | MIG 12 | -2 attack, -2 damage |
| Medium Melee | MIG 10 or AGI 10 | -1 attack |
| Light Melee | — | — |
| Bows | PRC 10 | -2 attack |
| Heavy Crossbow | FOR 12 | -2 attack, reload takes 2 AP |
| Thrown | — | — |

### Alternate Weapon Attributes (Talent Required)

| Weapon Type | Default | Alternate | Talent Name |
|-------------|---------|-----------|-------------|
| Heavy Melee | MIG | FOR | Enduring Grip |
| Medium Melee | MIG | AGI | Flowing Steel |
| Medium Melee | MIG | PRC | Measured Strike |
| Light Melee | AGI | PRC | Surgical Precision |
| Light Melee | AGI | MIG | Brutal Finesse |
| Bows | PRC | AGI | Snap Shot |
| Bows | PRC | WIS | Instinctive Archer |
| Crossbows | PRC | INT | Mechanical Precision |
| Crossbows | PRC | WIL | Patient Shot |
| Thrown | AGI | MIG | Power Throw |
| Thrown | AGI | PRC | Dead Eye |
| Unarmed | MIG | AGI | Martial Arts |
| Unarmed | MIG | FOR | Wrestler's Grip |

### Weapon Tiers

| Tier | Name | Req Increase | Damage Mod | Special |
|------|------|--------------|------------|---------|
| 1 | Common | Base | +0 | — |
| 2 | Uncommon | +2 | +1 | — |
| 3 | Rare | +4 | +2 | Minor ability |
| 4 | Epic | +6 | +3 | Ability |
| 5 | Legendary | +8 | +4 | Unique ability |

**Example — Greatsword (Base: MIG 12, Damage 10)**

| Tier | Name Example | Requirement | Damage |
|------|--------------|-------------|--------|
| 1 | Iron Greatsword | MIG 12 | 10 |
| 2 | Steel Greatsword | MIG 14 | 11 |
| 3 | Masterwork Greatsword | MIG 16 | 12 |
| 4 | Runed Greatsword | MIG 18 | 13 + ability |
| 5 | Worldcleaver | MIG 20 | 14 + unique |

---

## Armor System

### Armor Types

| Type | Defense | Requirements | Penalties If Unmet |
|------|---------|--------------|-------------------|
| None/Cloth | +0 | — | — |
| Light | +2 | AGI 12 | -1 AGI-based rolls |
| Medium | +4 | FOR 12 | -2 physical rolls, -1m move |
| Heavy | +6 | FOR 14, MIG 12 | -3 physical rolls, -2m move, disadvantage stealth |
| Shield (Light) | +1 | — | Occupies hand |
| Shield (Heavy) | +2 | FOR 12 | Occupies hand, -1 attack if FOR unmet |

### Armor Proficiency Talents

| Talent | Effect |
|--------|--------|
| Light Armor Training | Ignore AGI requirement for light armor |
| Medium Armor Training | Ignore FOR requirement for medium armor |
| Heavy Armor Training | Ignore FOR/MIG requirements for heavy armor |
| Shield Training | Ignore shield penalties |

### Armor Tiers

| Tier | Defense Bonus | Req Increase | Special |
|------|---------------|--------------|---------|
| 1 | Base | Base | — |
| 2 | +1 | +2 | — |
| 3 | +2 | +4 | Minor ability |
| 4 | +3 | +6 | Ability |
| 5 | +4 | +8 | Unique ability |

**Example — Heavy Armor (Base: FOR 14, MIG 12, Defense +6)**

| Tier | Defense | Requirements |
|------|---------|--------------|
| 1 | +6 | FOR 14, MIG 12 |
| 2 | +7 | FOR 16, MIG 14 |
| 3 | +8 | FOR 18, MIG 16 |
| 4 | +9 | FOR 20, MIG 18 |
| 5 | +10 | FOR 22, MIG 20 |
