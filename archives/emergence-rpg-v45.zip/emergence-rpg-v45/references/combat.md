# Combat System

## ⚠️ MANDATORY: Player Agency in Combat

**NEVER auto-resolve player turns.** Every player turn must:

1. **Display combat state** (AP, HP, enemies, zones)
2. **List available actions** with AP costs
3. **Ask "What do you do?"**
4. **STOP and WAIT** for player response
5. Only after player states action → resolve with dice

**Violations (DO NOT DO):**
- "You attack the wolf and..." (without asking first)
- Resolving multiple player attacks in sequence without input
- Assuming what the player wants to do
- Advancing combat without "What do you do?"

**Good Example:**
```
## Combat — Round 2 | Kira's Turn

**Stance:** Balanced | **AP:** 3/3 | **RP:** 1/1 | **Move:** 6m
**HP:** 24/31 (Wounded) | **Stamina:** 18/20 | **Mana:** 12/15

| Enemy | HP | DEF | ATK | DMG | Zone | Telegraphed |
|-------|-----|-----|-----|-----|------|-------------|
| Thornwolf A | 18/25 | 10 | +3 | 6 | Melee | Lunging at you |
| Thornwolf B | 25/25 | 10 | +3 | 6 | Near (5m) | Circling right |

### Available Actions
| Action | AP | Effect |
|--------|-----|--------|
| Attack Thornwolf A | 1 AP | Melee, +4 to hit |
| Attack Thornwolf B | 1 AP | Must move first |
| Move (per 2m) | 1 AP | 6m available |
| Defend | 1 AP | +2 DEF until next turn |
| Change Stance | 0 AP | Once per round |

**What do you do?**
```

Then STOP. Wait for player to say something like "Attack A twice and defend."

---

## Combat Initiation

1. Establish fictional situation
2. Determine surprise (if applicable)
3. Generate enemy stats (use `combat.py`)
4. Roll initiative for all
5. Establish battlefield zones
6. Display combat state
7. Begin Round 1

**Initiative:** 2d6 + AGI mod + PRC mod + (Level ÷ 4)

---

## Combat Stances

**Change Stance:** Free action at the start of your turn, before any other actions. Default to Balanced unless specified.

| Stance | AP | Move | ATK | DEF | DMG | Special |
|--------|-----|------|-----|-----|-----|---------|
| **Balanced** | 3 | +0 | +0 | +0 | +0 | Default, no penalties |
| **Aggressive** | 4 | +0 | +2 | -2 | +2 | Bonus damage to all attack types |
| **Defensive** | 2 | -2m | -2 | +4 | +0 | Cannot be critically hit |
| **Mobile** | 3 | +4m | +0 | +0 | +0 | Free disengage, no OA provoked |
| **Focused** | 2 | 0m | Adv | -2 | +0 | Advantage on all attacks, cannot move |

### Stance Rules

1. **One Change Per Turn:** You may only change stance once at the start of your turn
2. **Forced Stance:** Being Prone, Grappled, or Stunned forces Balanced stance
3. **Stance Memory:** Stance persists between turns until changed
4. **Combat Start:** Unless surprised, you may choose starting stance before initiative

### Special Stances (Unlocked via Talents/Evolutions)

| Stance | Source | Effects |
|--------|--------|---------|
| **Berserker** | Barbarian evolution | 5 AP, +4 ATK, +4 DMG, -4 DEF |
| **Iron Wall** | Guardian T3 talent | 2 AP, +6 DEF, cannot move or attack, allies gain +2 DEF |
| **Perfect Form** | Striker T4 talent | 3 AP, all attacks are called shots at no penalty |
| **Shadow** | Assassin evolution | 3 AP, invisible if no enemy within 5m at turn end |

---

## Action Economy

| Resource | Amount | Refreshes |
|----------|--------|-----------|
| Action Points (AP) | By Stance | Start of turn |
| Reaction Point (RP) | 1 | Start of turn |
| Movement | 6 + AGI mod meters | Start of turn |

### Action Costs

| Action | AP | Notes |
|--------|-----|-------|
| Basic Attack | 1 | Single weapon attack |
| Quick Skill | 1 | Novice/Apprentice abilities |
| Standard Skill | 2 | Journeyman/Expert abilities |
| Major Skill | 3 | Master+ abilities |
| Use Item | 1 | Potion, grenade, tool |
| Aim | 1 | +2 to next attack this turn |
| Disengage | 2 | Move without provoking (free in Mobile) |
| Sprint | 2 | Double movement; no attacks |
| Grapple | 2 | Opposed MIG or AGI |

### Reactions (1 RP each)

| Reaction | Trigger | Effect |
|----------|---------|--------|
| Opportunity Attack | Enemy leaves melee | One basic attack |
| Parry | Targeted by melee | Roll AGI vs attack; success negates |
| Dodge | Targeted by attack | +4 defense this attack |
| Intercept | Ally within 2m targeted | Take attack instead |

---

## Attack Resolution

**Attack:** 2d6 + attack mod + stance mod vs Defense DC

| Result | Condition | Damage |
|--------|-----------|--------|
| Critical Hit | Natural 12 (or 11+ at PRC mod 3+, or 10+ at PRC mod 5+) | ×2.0 + bonus effect |
| Exceptional | Natural 10-11 AND hit | ×1.5 |
| Hit | Total ≥ DC | ×1.0 |
| Grazing | Total = DC-1 or DC-2 | ×0.5 |
| Miss | Total ≤ DC-3 | 0 |
| Critical Miss | Natural 2 | 0 + consequence |

**Damage:** `(weapon_base + stat_mod × scaling + stance_damage) × multiplier - armor`

Minimum 1 damage on any hit.

### Critical Range by Precision

| PRC Mod | Crit on Natural | Crit Chance |
|---------|-----------------|-------------|
| +0 to +2 | 12 | 2.78% |
| +3 to +4 | 11-12 | 8.33% |
| +5 to +6 | 10-12 | 16.67% |
| +7+ | 9-12 | 27.78% |

---

## Called Shots

**Requirement:** PRC mod ≥ 2

| PRC Mod | Penalty |
|---------|---------|
| 2 | -3 |
| 3 | -2 |
| 4 | -1 |
| 5+ | None |

| Target | Hit Effect | Crit Effect |
|--------|------------|-------------|
| Head/Vitals | Normal damage | +100% damage |
| Arm | -2 to attacks | Arm disabled |
| Leg | -2m movement | Prone, leg disabled |
| Weapon | Drop weapon | Weapon damaged |
| Weak Point | Bypass 50% armor | Bypass all armor |

---

## Weapons (Common)

See `references/attributes.md` for weapon tiers, requirements, and alternate attribute talents.

| Weapon | Base | Default Attr | Properties |
|--------|------|--------------|------------|
| Unarmed | 4 | MIG | — |
| Dagger | 6 | AGI | Finesse, Concealable |
| Shortsword | 6 | AGI | Finesse |
| Longsword | 8 | MIG | Versatile |
| Greatsword | 10 | MIG (req 12) | Two-handed |
| Spear | 8 | MIG | Reach |
| Greataxe | 10 | MIG (req 12) | Two-handed, Armor Pierce 2 |
| Shortbow | 6 | PRC | Range 30m/60m |
| Longbow | 6 | PRC | Range 60m/120m |
| Light Crossbow | 6 | PRC | Range 40m/80m, reload 1 AP |
| Heavy Crossbow | 8 | PRC (FOR 12) | Range 60m/120m, reload 2 AP |

**Alternate Attributes (require talent):**
- Light Melee: AGI → PRC (Surgical Precision), AGI → MIG (Brutal Finesse)
- Medium Melee: MIG → AGI (Flowing Steel), MIG → PRC (Measured Strike)
- Heavy Melee: MIG → FOR (Enduring Grip)
- Bows: PRC → AGI (Snap Shot), PRC → WIS (Instinctive Archer)

## Armor

See `references/attributes.md` for armor tiers and requirements.

| Armor | DEF | Magic DEF | Move |
|-------|-----|-----------|------|
| None | +0 | +0 | 0 |
| Light | +2 | +0 | 0 |
| Medium | +4 | +1 | -1m |
| Heavy | +6 | +2 | -2m |
| Shield | +2 | +0 | 0 |

---

## Zone-Based Combat

Combat uses abstract zones rather than grid.

**Zone Properties:**
- **Cover:** +2 DEF vs ranged
- **Difficult:** Costs +2m to enter
- **Hazardous:** Damage or effect when entering/starting
- **Elevated:** +1 ranged attack, -2 melee defense

**Movement:**
- Moving within zone: Free
- Moving to adjacent zone: Movement cost
- Engaging/disengaging: May provoke

---

## Combat Display Format

```markdown
## Combat — Round X | [Name]'s Turn

**Stance:** [Current] | **AP:** X/X | **RP:** 1/1 | **Move:** Xm
**HP:** X/X ([State]) | **Stamina:** X | **Mana:** X
**Conditions:** [List or None]

### Enemies

| Enemy | HP | DEF | ATK | DMG | Zone | Telegraphed |
|-------|-----|-----|-----|-----|------|-------------|
| [Name] (Lv X) | X/X | X | +X | X | [Zone] | [Hint] |

### Zones

- **[Zone]:** [Occupants] | [Properties]

**What do you do?**
```

---

## Script Usage

```python
from scripts.combat import attack_roll, generate_enemy, display_combat_state

# Attack
result = attack_roll(
    attacker_name="Kira",
    attack_mod=4,
    target_name="Thornwolf",
    defense_dc=12,
    weapon_base=8,
    stat_mod=2,
    scaling=1.0,
    armor=1,
    stance="aggressive"
)

# Generate enemy
enemy = generate_enemy(level=3, threat="standard", enemy_type="Thornwolf")
```
