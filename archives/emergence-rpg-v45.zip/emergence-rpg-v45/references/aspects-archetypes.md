# Aspects and Archetypes

## Overview

**Aspects** (8 total) — Derived from background, personality, values. Determine:
- +2 to primary stat, +1 to secondary stat
- XP bonus to aspect-aligned skill categories
- Flavor/theme for Awakening ability
- Gate certain evolutions at later levels

**Archetypes** (8 total) — Derived from crisis response behavior. Determine:
- +2 to primary stat, +1 to secondary stat
- XP bonus to role-based skill categories
- Starting form pool
- Talent pool access

**Class** — The Aspect × Archetype intersection determines your Class (64 total). See `references/classes.md`.

---

## Stat Bonuses

Stat bonuses are applied automatically by the character creation script. For manual reference, see the `character.py` source or run:

```bash
python emergence_cli.py character --aspect [aspect] --archetype [archetype] --level 1
```

The script output shows all applied bonuses and final stats.

---

## The Eight Aspects

### ORE
**Elements:** Earth + Metal  
**Themes:** Permanence, foundation, patience, resilience, wealth drawn from depth  
**Motto:** *"I am the mountain. Endure. Outlast. Remain."*

**Background Triggers:** Engineer, construction worker, banker, miner, jeweler, security  
**Personality Triggers:** Stoic, patient, protective, values stability, endures hardship

**XP Bonus:** Crafting, Defense, Endurance, Earth Magic  
**Evolution Gates:** Earthshaper (10), Ironclad (20), Mountain Sovereign (30)

---

### TIDE
**Elements:** Water + Ice  
**Themes:** Adaptability, patience that erodes mountains, hidden depths, clarity  
**Motto:** *"Still waters cut stone. Flow or shatter."*

**Background Triggers:** Doctor, surgeon, researcher, detective, analyst, accountant  
**Personality Triggers:** Observant, methodical, adaptive, reveals truth, values clarity

**XP Bonus:** Investigation, Medicine, Stealth, Water/Ice Magic  
**Evolution Gates:** Tidecaller (10), Frostweaver (20), Abyssal Lord (30)

---

### PYRE
**Elements:** Fire + Wood  
**Themes:** Transformation, consumption that enables growth, sacrifice, passion  
**Motto:** *"Burn bright. From ash, new growth."*

**Background Triggers:** Firefighter, chef, athlete, soldier, activist  
**Personality Triggers:** Passionate, decisive, confrontational, values change

**XP Bonus:** Athletics, Intimidation, Survival, Fire/Nature Magic  
**Evolution Gates:** Ashborn (10), Verdant Fury (20), Phoenix (30)

---

### GALE
**Elements:** Wind + Lightning  
**Themes:** Freedom, speed, unpredictability, the strike that cannot be anticipated  
**Motto:** *"Strike before the thunder. The wind owes nothing."*

**Background Triggers:** Courier, pilot, dancer, thief, parkour athlete  
**Personality Triggers:** Impulsive, freedom-loving, quick-thinking, unpredictable

**XP Bonus:** Acrobatics, Theft, Speed, Lightning/Wind Magic  
**Evolution Gates:** Stormcaller (10), Windwalker (20), Tempest Incarnate (30)

---

### RADIANCE
**Elements:** Light + Life  
**Themes:** Revelation, vitality, hope, truth that cannot be hidden  
**Motto:** *"Light reveals. Life prevails. Dawn answers every darkness."*

**Background Triggers:** Doctor, nurse, teacher, priest, performer, leader  
**Personality Triggers:** Inspiring, hopeful, healing-focused, truthful

**XP Bonus:** Leadership, Medicine, Performance, Light/Healing Magic  
**Evolution Gates:** Dawnbringer (10), Lifewarden (20), Solar Paragon (30)

---

### SHROUD
**Elements:** Blood + Death  
**Themes:** Mortality, the price paid in flesh, inevitability, power through sacrifice  
**Motto:** *"All blood returns to the earth. Even kings become dust."*

**Background Triggers:** Mortician, coroner, soldier, surgeon, hospice worker  
**Personality Triggers:** Pragmatic about death, sacrificial, accepts costs

**XP Bonus:** Intimidation, Medicine (surgery), Occult, Blood/Death Magic  
**Evolution Gates:** Deathspeaker (10), Bloodbound (20), Grave Emperor (30)

---

### ANIMA
**Elements:** Primal + Spirit  
**Themes:** Instinct, the wild self beneath civilization, ancestral memory  
**Motto:** *"The wild remembers what we forget. Instinct is the oldest wisdom."*

**Background Triggers:** Veterinarian, park ranger, hunter, shaman, therapist  
**Personality Triggers:** Intuitive, connected to nature, trusts instinct

**XP Bonus:** Animal Handling, Nature, Perception, Spirit/Beast Magic  
**Evolution Gates:** Beastcaller (10), Spiritwalker (20), Primal Avatar (30)

---

### AETHER
**Elements:** Void + Time  
**Themes:** The space between spaces, causality as suggestion, knowledge that costs sanity  
**Motto:** *"Time is a river I walk upon. Reality is a door, not a wall."*

**Background Triggers:** Physicist, philosopher, programmer, mathematician  
**Personality Triggers:** Analytical, detached, sees patterns, questions reality

**XP Bonus:** Arcana, Technology, Research, Void/Time Magic  
**Evolution Gates:** Voidwalker (10), Chronomancer (20), Reality Weaver (30)

---

## The Eight Archetypes

### STRIKER
**Role:** DPS (Burst)  
**Combat Focus:** Overwhelming single-target damage, finishing blows

**Form Pool Affinities:** Heavy weapons, power attacks, unarmed  
**Talent Pool:** Offensive talents, damage multipliers, critical enhancement

**XP Bonus:** Heavy Weapons, Unarmed, Power Attacks

---

### GUARDIAN
**Role:** Tank  
**Combat Focus:** Damage mitigation, protecting allies, holding positions

**Form Pool Affinities:** Shield, defensive techniques, armor  
**Talent Pool:** Defensive talents, damage reduction, threat generation

**XP Bonus:** Shield Use, Armor, Defensive Techniques

---

### HUNTER
**Role:** DPS (Sustained/Precision)  
**Combat Focus:** Exploiting weaknesses, called shots, ranged excellence

**Form Pool Affinities:** Ranged weapons, traps, stealth  
**Talent Pool:** Precision talents, critical targeting, vulnerability exploitation

**XP Bonus:** Ranged Weapons, Called Shots, Trap-making

---

### SKIRMISHER
**Role:** DPS (Mobile)  
**Combat Focus:** Hit-and-run, flanking, avoiding damage through movement

**Form Pool Affinities:** Dual wield, light weapons, acrobatics  
**Talent Pool:** Mobility talents, evasion, opportunity attacks

**XP Bonus:** Light Weapons, Dual Wielding, Evasion

---

### MENDER
**Role:** Healer/Support  
**Combat Focus:** Restoring HP, removing conditions, keeping allies alive

**Form Pool Affinities:** Healing magic, medicine, protective wards  
**Talent Pool:** Healing talents, condition removal, buff application

**XP Bonus:** Healing, Condition Removal, Medicine

---

### WARDEN
**Role:** Controller/Support  
**Combat Focus:** Battlefield control, debuffs, denying enemy actions

**Form Pool Affinities:** Control magic, area denial, perception  
**Talent Pool:** Control talents, debuffs, area effects

**XP Bonus:** Debuffs, Area Control, Disruption

---

### ANALYST
**Role:** Tactical Support  
**Combat Focus:** Identifying weaknesses, buffing allies, tactical coordination

**Form Pool Affinities:** Knowledge, crafting, traps  
**Talent Pool:** Analysis talents, team buffs, tactical advantages

**XP Bonus:** Analysis, Coordination, Tactical Buffs

---

### SPEAKER
**Role:** Social/Morale Support  
**Combat Focus:** Rallying allies, demoralizing enemies, social combat

**Form Pool Affinities:** Social skills, performance, command  
**Talent Pool:** Morale talents, social combat, inspiration

**XP Bonus:** Persuasion, Leadership, Performance

---

## XP Bonus Application

When gaining skill XP, check for bonuses:

1. **Aspect match:** +50% XP if skill category matches aspect bonus list
2. **Archetype match:** +50% XP if skill category matches archetype bonus list
3. **Both match:** +100% XP (doubled)

---

## Evolution Gates

At levels 10, 20, 30, characters can evolve. Aspects gate which evolutions are available:

| Aspect | Level 10 | Level 20 | Level 30 |
|--------|----------|----------|----------|
| Ore | Earthshaper | Ironclad | Mountain Sovereign |
| Tide | Tidecaller | Frostweaver | Abyssal Lord |
| Pyre | Ashborn | Verdant Fury | Phoenix |
| Gale | Stormcaller | Windwalker | Tempest Incarnate |
| Radiance | Dawnbringer | Lifewarden | Solar Paragon |
| Shroud | Deathspeaker | Bloodbound | Grave Emperor |
| Anima | Beastcaller | Spiritwalker | Primal Avatar |
| Aether | Voidwalker | Chronomancer | Reality Weaver |

Archetypes do not gate evolutions but may provide evolution-specific talents.
