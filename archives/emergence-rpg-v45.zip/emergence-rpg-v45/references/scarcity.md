# Scarcity & Economy

## Loot Philosophy

**Default loot is NOTHING. Significant loot is RARE.**

This is not a power fantasy. Enforce scarcity.

---

## Session Loot Budget

| Tier | Per Session |
|------|-------------|
| Junk/Scraps | Unlimited |
| Common | 3-5 items |
| Uncommon | 1-2 items |
| Rare | 0-1 (boss only) |
| Epic+ | 0 (raid boss only) |

## Standard Monster Loot (2d6)

| Roll | Result |
|------|--------|
| 2-7 | Nothing useful |
| 8-9 | Scraps (junk value) |
| 10-11 | Common item |
| 12 | Uncommon item |

**80% of encounters yield nothing or scraps.**

---

## Skill Stone Rarity

| Source | Chance |
|--------|--------|
| Standard monster | 1% |
| Elite monster | 5% |
| Boss monster | 20% |
| Raid boss | 50% |

**Maximum per session:** 1 (unless boss killed)

---

## Currency System

**Credits** = Universal post-Transit currency (exchange tokens, barter equivalents)

| Wealth Level | Credits | Living Standard |
|--------------|---------|-----------------|
| Destitute | 0-50 | Starving |
| Poor | 51-200 | One meal/day |
| Surviving | 201-500 | Basic needs met |
| Comfortable | 501-1000 | Some luxuries |
| Wealthy | 1001-5000 | Significant resources |
| Rich | 5000+ | Faction-level wealth |

---

## Price Reference

### Necessities

| Item | Credits |
|------|---------|
| Food (1 day) | 5 |
| Water (1 day) | 3 |
| Basic medicine | 10 |
| Antibiotics | 50+ |
| Bandages (5) | 5 |

### Weapons

| Item | Credits |
|------|---------|
| Knife | 15 |
| Machete | 30 |
| Baseball bat | 10 |
| Bow (improvised) | 40 |
| Crossbow | 100 |
| Pistol | 200+ |
| Rifle | 500+ |
| Bullet (1) | 10-50 |

### Armor

| Item | Credits |
|------|---------|
| Leather jacket | 20 |
| Sports padding | 30 |
| Riot gear | 150 |
| Military vest | 300+ |

### Special

| Item | Credits |
|------|---------|
| Common Skill Stone | 100-200 |
| Uncommon Skill Stone | 500+ |
| Rare Skill Stone | 1000+ |
| Crystal (raw) | 20-50 |
| Crystal (refined) | 100+ |

---

## Equipment Quality Gates

| Level | Maximum Equipment |
|-------|-------------------|
| 1-4 | Improvised, scavenged |
| 5-7 | Quality mundane |
| 8-9 | Military-grade |
| 10-14 | Magical (minor) |
| 15-19 | Magical (moderate) |
| 20+ | Magical (major) |

**Players should NOT have:**
- Military-grade before Level 5
- Magical equipment before Level 8
- Full matched sets before Level 10
- Legendary items before Level 20

---

## Resource Pressure

### Food
- Requires 1 food/day minimum
- Starvation: -1 all rolls per day without food (max -4)
- 7 days without food: Death

### Water
- Requires water every 2 days
- Dehydration: -2 all rolls per day (max -6)
- 4 days without water: Death

### Ammunition
- Bullets are precious (no manufacturing)
- Track individual rounds
- Expected to run out eventually

### Medicine
- Modern medicine is finite
- No new manufacturing
- Magical alternatives exist but are rare

---

## NPC Economic Behavior

### Default Prices
- Fair market value (listed prices) for neutral NPCs
- +50% for distrustful NPCs
- +100% for hostile territory
- -25% for friendly NPCs
- -50% for allied NPCs

### Haggling
- Roll PRE vs NPC's WIS
- Success: 10-20% discount
- Exceptional: 25-30% discount
- Failure: Price firm
- Critical fail: +10% "attitude adjustment"

### Barter
- Most NPCs prefer barter to credits
- Useful items worth more than cash value
- Information has value

---

## Script Usage

```python
from scripts.dice import roll_loot

# Standard monster loot
loot = roll_loot("standard")  
# Returns: {loot_tier, loot_description, skill_stone (bool)}

# Boss loot
boss_loot = roll_loot("boss")
```
