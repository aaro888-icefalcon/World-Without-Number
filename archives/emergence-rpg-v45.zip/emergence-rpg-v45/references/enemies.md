# Enemy Generation

## Threat Tiers

| Tier | HP Mult | Stats | Abilities | XP |
|------|---------|-------|-----------|-----|
| Minion | 0.5× | 0.5× | None | 25% |
| Standard | 1.0× | 1.0× | 0-1 | 100% |
| Elite | 1.5× | 1.5× | 1-2 | 200% |
| Boss | 2.0× | 2.0× | 2-3 | 400% |

## Base Stat Formulas

| Stat | Formula (before tier mult) |
|------|---------------------------|
| HP | 10 + (Level × 8) |
| Armor | Level ÷ 3 |
| Attack | Level + 2 |
| Damage | 4 + (Level × 1.5) |
| Defense DC | 10 + (Level ÷ 2) + 0-3 |
| Initiative | 1-4 + (Level ÷ 3) |

## Scaling Guidelines

| Level | HP | Damage | Defense | vs Level 1 |
|-------|-----|--------|---------|------------|
| 1 | 12-18 | 4-6 | 10-11 | Fair fight |
| 3 | 28-36 | 8-10 | 12-13 | Dangerous |
| 5 | 45-55 | 12-14 | 13-15 | Deadly |
| 8 | 70-90 | 16-20 | 15-17 | Near-certain death |
| 10 | 90-110 | 20-24 | 16-18 | Certain death |

---

## Behavior by Intelligence

| INT | Behavior |
|-----|----------|
| 1-4 | **Bestial:** Attack whoever hurt them; pack tactics; flee when bloodied alone |
| 5-8 | **Cunning:** Target casters/wounded; use terrain; retreat if outmatched |
| 9-12 | **Intelligent:** Analyze threats; exploit weaknesses; call reinforcements |
| 13+ | **Genius:** Pre-positioned traps; counter-builds; psychological warfare |

---

## Enemy Stat Block Format

```markdown
**[NAME]** — Level X [Threat]

| HP | Armor | DEF | ATK | DMG | Init |
|-----|-------|-----|-----|-----|------|
| X | X | X | +X | X | +X |

**Abilities:**
- [Ability Name]: [Effect]

**Behavior:** [Pattern]
**Loot:** [Drop table]
```

---

## Sample Enemies

### THORNWOLF (Level 2 Standard)
| HP | Armor | DEF | ATK | DMG | Init |
|-----|-------|-----|-----|-----|------|
| 26 | 0 | 12 | +4 | 7 | +3 |

**Abilities:**
- Pack Tactics: +2 attack when ally adjacent
- Thorn Hide: Melee attackers take 2 damage

**Behavior:** Bestial. Test before commit; flee if bloodied and alone.
**Loot:** 70% nothing, 20% hide scraps, 10% intact hide

### GLOOM STALKER (Level 3 Standard)
| HP | Armor | DEF | ATK | DMG | Init |
|-----|-------|-----|-----|-----|------|
| 34 | 0 | 14 | +5 | 8 | +5 |

**Abilities:**
- Ambush: +4 damage from stealth
- Shadow Meld: Advantage on stealth in dim light

**Behavior:** Cunning. Ambush, hit hard, flee if spotted.
**Loot:** 60% nothing, 25% shadow essence, 15% common item

### KAELTHARI SOLDIER (Level 6 Elite)
| HP | Armor | DEF | ATK | DMG | Init |
|-----|-------|-----|-----|-----|------|
| 78 | 5 | 15 | +9 | 18 | +4 |

**Abilities:**
- Shield Wall: +2 Defense when adjacent to ally
- Disciplined: Immune to Frightened
- Cold Weakness: -2 all rolls in cold environments

**Behavior:** Intelligent. Formation fighting. Will capture rather than kill.
**Loot:** Equipment (scale armor, spear, shield)

### ROCKJAW (Level 4 Standard)
| HP | Armor | DEF | ATK | DMG | Init |
|-----|-------|-----|-----|-----|------|
| 42 | 3 | 12 | +6 | 10 | +2 |

**Abilities:**
- Burrow: Can emerge from ground as ambush
- Stone Hide: Half damage from slash/pierce
- Grapple: On hit, may grapple (opposed MIG)

**Behavior:** Cunning. Burrow ambush; retreat if can't escape.
**Loot:** 50% nothing, 30% stone hide scraps, 20% teeth

---

## Encounter Difficulty Guidelines

| Difficulty | Composition |
|------------|-------------|
| Easy | 1-2 enemies at party level - 2 |
| Medium | 2-3 enemies at party level |
| Hard | Elite + minions OR 3-4 at level + 1 |
| Deadly | Boss + support |

---

## Telegraphing

Enemies should telegraph dangerous actions.

| Action | Telegraph |
|--------|-----------|
| Big attack | "The creature rears back..." |
| Area attack | "Energy crackles around it..." |
| Special ability | "Its [body part] begins to glow..." |
| Retreat | "It glances toward the exit..." |
| Call allies | "It lets out a piercing cry..." |

---

## Script Usage

```python
from scripts.combat import generate_enemy, generate_encounter

# Single enemy
wolf = generate_enemy(level=2, threat="standard", enemy_type="Thornwolf", name="Alpha Thornwolf")

# Full encounter
encounter = generate_encounter(party_level=3, difficulty="hard", enemy_types=["Thornwolf"])
```
