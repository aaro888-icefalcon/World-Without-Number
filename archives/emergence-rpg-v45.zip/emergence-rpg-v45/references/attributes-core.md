# Attributes

## The Eight Attributes

| Attribute | Abbr | Primary Role | Combat Role | Utility Role |
|-----------|------|--------------|-------------|--------------|
| **Might** | MIG | Raw power | Heavy weapon damage, forced entry | Intimidation (physical), carrying |
| **Fortitude** | FOR | Durability | HP, stamina, physical resistance | Endurance, poison/disease resist |
| **Agility** | AGI | Speed | Physical Defense, initiative, movement | Stealth, acrobatics, reflexes |
| **Precision** | PRC | Accuracy | Crit range, called shots, ranged/finesse | Crafting, surgery, lockpicking |
| **Intellect** | INT | Knowledge | Arcane power, mana pool, analysis | Research, tactics, technology |
| **Wisdom** | WIS | Awareness | Resistance DC, divine/primal magic | Perception, insight, tracking |
| **Willpower** | WIL | Mental strength | Sustain, psionic/blood magic | Fear resist, concentration |
| **Presence** | PRE | Influence | Command abilities, morale effects | Persuasion, leadership, deception |

---

## Modifier Formula

**Modifier = floor((Attribute - 10) / 2)**

| Attribute | Mod | | Attribute | Mod |
|-----------|-----|---|-----------|-----|
| 6-7 | -2 | | 18-19 | +4 |
| 8-9 | -1 | | 20-21 | +5 |
| 10-11 | +0 | | 22-23 | +6 |
| 12-13 | +1 | | 24-25 | +7 |
| 14-15 | +2 | | 26-27 | +8 |
| 16-17 | +3 | | 28-29 | +9 |

---

## Attribute Investment

**No Hard Caps.** Attributes can grow without level-based limits, but investment costs increase at higher values.

### Investment Cost Table

| Target Score | Point Cost Each |
|--------------|-----------------|
| 10-14 | 1 point per +1 |
| 15-18 | 2 points per +1 |
| 19-22 | 3 points per +1 |
| 23-26 | 4 points per +1 |
| 27-30 | 5 points per +1 |

**Example:** Raising an attribute from 14 → 18 costs 8 points (4 increases × 2 each).

### Attribute Points Per Level

See `progression.md` for full table. Quick reference:
- **Every Level:** +2 attribute points
- **Milestone Levels (5, 10, 15, 20, 25, 30):** +3 total (+1 bonus)

### Practical Maximums by Level

| Level | Total Points | Realistic Max Single Stat |
|-------|--------------|---------------------------|
| 1 | 0 (creation only) | 14 (stacked bonuses) |
| 5 | 11 | 18 |
| 10 | 22 | 22 |
| 15 | 33 | 24 |
| 20 | 44 | 26 |
| 25 | 55 | 28 |
| 30 | 66 | 30 |

**Note:** Reaching 30 in one stat requires sacrificing breadth. A L30 character with 30 MIG likely has minimal investment elsewhere.

---

## Attribute Breakpoints

Each attribute has meaningful thresholds. These are passive benefits gained automatically.

### Might

| Mod | Benefit |
|-----|---------|
| +1 | Can use medium melee weapons effectively |
| +2 | Heavy weapon proficiency (no penalty) |
| +3 | Power Attack available: -2 hit, +4 damage |
| +4 | Cleave: On kill, free attack vs adjacent enemy |
| +5 | Devastating Blow: Crits cause knockback (2m) or prone |
| +6 | Sundering Strike: Damage enemy armor on crit |
| +7+ | Titanic Force: +1 damage per excess MIG mod |

### Fortitude

| Mod | Benefit |
|-----|---------|
| +1 | Poison/disease resistance (+2 to saves) |
| +2 | Medium armor proficiency, +5 carry capacity |
| +3 | Second Wind: 1/combat, recover Stamina = FOR |
| +4 | Heavy armor proficiency, Die Hard: Act at 0 HP for 1 round |
| +5 | Unstoppable: Ignore first crit effect per combat |
| +6 | Iron Constitution: Immune to minor poisons/diseases |
| +7+ | Legendary Endurance: +2 HP per excess FOR mod |

### Agility

| Mod | Benefit |
|-----|---------|
| +1 | +1m movement speed |
| +2 | Light armor bonus (+1 defense in light armor) |
| +3 | Evasion: Half damage on successful defense vs AoE |
| +4 | Uncanny Dodge: 1/round, reduce incoming damage by AGI mod |
| +5 | Lightning Reflexes: Advantage on initiative |
| +6 | Blur: First attack against you each round has disadvantage |
| +7+ | Impossible Speed: +1m movement per excess AGI mod |

### Precision

| Mod | Benefit |
|-----|---------|
| +1 | Ranged weapon proficiency |
| +2 | Called Shots unlocked (see Called Shots section) |
| +3 | Crit range expands to 11-12 |
| +4 | Called Shot penalty reduced to -2 |
| +5 | Crit range expands to 10-12, Called Shots at -1 |
| +6 | Called Shots at no penalty |
| +7 | Crit range expands to 9-12 (maximum) |
| +8+ | Perfect Precision: +1 to called shot effects |

### Intellect

| Mod | Benefit |
|-----|---------|
| +1 | Read/write, basic research |
| +2 | Identify Weakness: 1/combat, learn one enemy vulnerability |
| +3 | Tactical Insight: 1/combat, grant ally +2 to one roll |
| +4 | Analyze Pattern: Predict one enemy action (GM reveals telegraph) |
| +5 | Exploit Weakness: +50% damage to analyzed target |
| +6 | Mastermind: Tactical Insight becomes +3, usable 2/combat |
| +7+ | Genius: +1 to analysis-related rolls per excess INT mod |

### Wisdom

| Mod | Benefit |
|-----|---------|
| +1 | Sense Motive: Know if NPC is hostile |
| +2 | Detect Hidden: +2 to find concealed objects/creatures |
| +3 | Danger Sense: Cannot be surprised |
| +4 | Read Intentions: Know if NPC is lying (not what truth is) |
| +5 | Premonition: 1/day, reroll one failed save |
| +6 | True Sight: See through mundane disguises/illusions |
| +7+ | Enlightened: +1 to perception-related rolls per excess WIS mod |

### Willpower

| Mod | Benefit |
|-----|---------|
| +1 | Resist fear effects (+2 to saves) |
| +2 | Fear Immunity: Cannot be frightened |
| +3 | Concentration: Maintain spell/ability while taking damage |
| +4 | Mental Fortress: Advantage vs mind-affecting effects |
| +5 | Indomitable: 1/combat, break free from control effect |
| +6 | Unbreakable Will: Immune to charm, advantage vs all mental |
| +7+ | Iron Mind: +1 to resist mental effects per excess WIL mod |

### Presence

| Mod | Benefit |
|-----|---------|
| +1 | First impressions: NPCs start one step more favorable |
| +2 | Rally: Remove fear from one ally (1/combat) |
| +3 | Inspire: Grant ally +2 to one roll (1/combat) |
| +4 | Commanding Presence: Rally/Inspire range increases to 10m |
| +5 | Legendary Reputation: NPCs may have heard of you |
| +6 | Aura of Authority: Enemies must pass WIL save to attack allies first |
| +7+ | Icon: +1 to social rolls per excess PRE mod |

---

## Called Shots

**Requirement:** PRC mod ≥ 2

**Base Penalty:** -3 to attack roll  
**Penalty Reduction:** -1 per PRC mod above 2

| PRC Mod | Called Shot Penalty |
|---------|---------------------|
| 2 | -3 |
| 3 | -2 |
| 4 | -1 |
| 5 | -0 |
| 6+ | +0 (no penalty) |

### Called Shot Targets

| Target | Effect on Hit | Effect on Crit |
|--------|---------------|----------------|
| **Head/Vitals** | Normal damage | +100% damage |
| **Arm** | -2 to attacks until healed | Arm disabled |
| **Leg** | -2m movement until healed | Leg disabled, prone |
| **Weapon** | Target drops weapon | Weapon damaged |
| **Weak Point** | Bypass 50% armor | Bypass all armor |

---

## Attribute-to-Roll Guide

| Roll Type | Primary | Situational Alternates |
|-----------|---------|------------------------|
| Melee Attack | Weapon default | See equipment.md |
| Ranged Attack | PRC | WIS (instinct), AGI (snap) |
| Spell Attack | Magic type default | See magic.md |
| Physical Defense | AGI | — |
| Mental Resistance | WIS + WIL | — |
| Initiative | AGI + PRC | — |
| Stealth | AGI | — |
| Perception | WIS | INT (search), PRC (spot detail) |
| Athletics | MIG | AGI (acrobatics), FOR (endurance) |
| Crafting | PRC | INT (complex), WIS (intuitive) |
| Medicine | WIS | PRC (surgery), INT (diagnosis) |
| Persuasion | PRE | WIS (empathy), INT (logic) |
| Intimidation | PRE | MIG (physical), WIL (staredown) |
| Deception | PRE | INT (complex lies), WIS (read mark) |
| Survival | WIS | FOR (endurance), INT (planning) |
| Technology | INT | PRC (fine work), WIS (intuition) |
