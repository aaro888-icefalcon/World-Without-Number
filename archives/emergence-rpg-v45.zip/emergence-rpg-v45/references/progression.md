# Character Progression

## Level Progression

### XP Requirements

| Level | XP Required | Cumulative |
|-------|-------------|------------|
| 1 | 0 | 0 |
| 2 | 500 | 500 |
| 3 | 800 | 1,300 |
| 4 | 1,280 | 2,580 |
| 5 | 2,048 | 4,628 |
| 6 | 3,277 | 7,905 |
| 7 | 5,243 | 13,148 |
| 8 | 8,389 | 21,537 |
| 9 | 13,422 | 34,959 |
| 10 | 21,475 | 56,434 |

**Formula:** XP for next level = 500 × 1.6^(Level-1)

### Per-Level Rewards

| Level | Talent | Form Slot | Attribute | Passive | Evolution | Notes |
|-------|--------|-----------|-----------|---------|-----------|-------|
| 1 | — | 2 (1+empty) | — | — | — | Aspect/Archetype bonuses applied |
| 2 | +1 | — | +2 | — | — | |
| 3 | +1 | — | +2 | **Generate** | — | Procedural passive |
| 4 | +1 | **+1** | +2 | — | — | 3rd form slot |
| 5 | +1 | — | +3 **(+1 bonus)** | — | — | Milestone bonus |
| 6 | +1 | — | +2 | — | — | |
| 7 | +1 | — | +2 | **Generate** | — | Procedural passive |
| 8 | +1 | **+1** | +2 | — | — | 4th form slot |
| 9 | +1 | — | +2 | — | — | |
| 10 | +1 | — | +3 **(+1 bonus)** | — | **Choose** | First evolution |
| 11 | +1 | — | +2 | — | — | |
| 12 | +1 | **+1** | +2 | **Generate** | — | 5th form, passive |
| 13 | +1 | — | +2 | — | — | |
| 14 | +1 | — | +2 | — | — | |
| 15 | +1 | — | +3 **(+1 bonus)** | — | — | Milestone bonus |
| 16 | +1 | **+1** | +2 | — | — | 6th form slot |
| 17 | +1 | — | +2 | — | — | |
| 18 | +1 | — | +2 | **Generate** | — | Procedural passive |
| 19 | +1 | — | +2 | — | — | |
| 20 | +1 | **+1** | +3 **(+1 bonus)** | — | **Choose** | 7th form, 2nd evolution |
| 21 | +1 | — | +2 | — | — | |
| 22 | +1 | — | +2 | — | — | |
| 23 | +1 | — | +2 | — | — | |
| 24 | +1 | **+1** | +2 | — | — | 8th form slot |
| 25 | +1 | — | +3 **(+1 bonus)** | **Generate** | — | Milestone, passive |
| 26 | +1 | — | +2 | — | — | |
| 27 | +1 | — | +2 | — | — | |
| 28 | +1 | **+1** | +2 | — | — | 9th form slot |
| 29 | +1 | — | +2 | — | — | |
| 30 | +1 | — | +3 **(+1 bonus)** | — | **Choose** | 3rd evolution |

**Note:** Level 1 characters receive stat bonuses from Aspect (+2/+1) and Archetype (+2/+1), not free attribute points. Free attribute points begin at level 2. See `classes.md` for bonus tables.

---

## Attribute Progression

### Points per Level
- **Base:** +2 attribute points per level (starting level 2)
- **Milestone Bonus:** +1 additional at levels 5, 10, 15, 20, 25, 30
- **Total by Level 30:** 64 points (58 base + 6 milestone)

### Investment Costs (No Caps)

Attributes have no hard caps. Instead, reaching higher values costs more points:

| Target Score | Point Cost Each |
|--------------|-----------------|
| 10-14 | 1 point per +1 |
| 15-18 | 2 points per +1 |
| 19-22 | 3 points per +1 |
| 23-26 | 4 points per +1 |
| 27-30 | 5 points per +1 |

**Example:** Raising an attribute from 14 → 18 costs 8 points (4 increases × 2 each).

### Typical Progression (Primary Attribute)

| Level | Points Available | Primary Attr | Modifier | Investment Strategy |
|-------|------------------|--------------|----------|---------------------|
| 1 | 0 (creation) | 13-14 | +1-2 | Aspect/Archetype bonuses only |
| 5 | 11 | 17-18 | +3-4 | Focused primary |
| 10 | 22 | 20-22 | +5-6 | Primary maxed for tier |
| 15 | 33 | 22-24 | +6-7 | Breadth or depth trade-off |
| 20 | 44 | 24-26 | +7-8 | Near-superhuman |
| 25 | 55 | 26-28 | +8-9 | Legendary specialist |
| 30 | 66 | 28-30 | +9-10 | Mythic single-stat or balanced veteran |

---

## Form Slot Progression

| Level | Total Slots | Notes |
|-------|-------------|-------|
| 1 | 2 | 1 chosen + 1 empty |
| 4 | 3 | +1 slot |
| 8 | 4 | +1 slot |
| 12 | 5 | +1 slot |
| 16 | 6 | +1 slot |
| 20 | 7 | +1 slot |
| 24 | 8 | +1 slot |
| 28 | 9 | +1 slot |

### Form Acquisition

**Starting (Level 1):** Choose 1 from derived pool
- Pool = Archetype base (5 forms) + Aspect modifier (swap 1-2)
- Second slot starts EMPTY
- See `references/classes.md` for pool derivation

**Form Discovery (Sessions 2-5):** GM discretion, narrative means
- Form Scrolls (loot)
- Form Teachers (NPCs who know the form)
- Survival Unlocks (crisis triggers awakening)
- Form Manuals (quest rewards, purchases)

**After Session 5:** All forms must be FOUND through play

---

## Talent Progression

### Acquisition
- +1 talent at each level starting level 2
- Total at level 30: 29 talents

### Pool Access
- **General Pool:** Always available (100 talents)
- **Archetype Pool:** Matching archetype only (20 talents)
- **Aspect Pool:** Matching aspect only (18 talents)
- **Evolution Pools:** After taking that evolution (5-6 talents each)

### Tier Prerequisites

| Tier | Prerequisites |
|------|---------------|
| 1 | None (general) or Attr 10+ (open proficiency) |
| 2 | Tier 1 talent in tree + Level 5+ OR Attr 14+ (standard proficiency) |
| 3 | Tier 2 talent in tree + Level 10+ OR Attr 18+ (mastery proficiency) |
| 4 | Tier 3 talent in tree + Level 15+ |

**Proficiency Talents:** See `talents-expanded.md` for the three-tier proficiency system (Open/Standard/Mastery).

---

## Technique Progression

### Unlocks Per Form

Each form has 4 tiers of techniques:
- **Tier 1:** 3 base techniques + 1 variant unique
- **Tier 2:** 3 base techniques + 1 variant unique
- **Tier 3:** 2 base techniques + 1 variant unique
- **Tier 4:** 0 base + 1 variant unique (mastery)

### Unlock Methods

| Method | Time | Requirement |
|--------|------|-------------|
| **Scroll/Manual** | Instant (read) | Find the scroll |
| **Master Teacher** | 1 week × tier | Find teacher, pay/quest |
| **Survival Unlock** | Instant | Meet specific condition |
| **Witnessed Learning** | 1 week (instant on crit) | See technique, pass INT/WIS check |

### Scroll Drop Rates

| Source | T1 | T2 | T3 | T4 |
|--------|-----|-----|-----|-----|
| Minion | 0.5% | — | — | — |
| Standard | 2% | 0.5% | — | — |
| Elite | 5% | 2% | 0.5% | — |
| Boss | 10% | 5% | 2% | 0.5% |

---

## Skill Progression

### Skill Acquisition
Skills are obtained ONLY from Skill Stones (dropped loot).

| Source | Drop Chance |
|--------|-------------|
| Standard monster | 1% |
| Elite monster | 5% |
| Boss monster | 20% |
| Raid boss | 50% |
| Quest reward | Guaranteed (specific) |

### Skill Ranks

| Rank | Uses Required | Milestone |
|------|---------------|-----------|
| Novice | 0 | Starting |
| Apprentice | 100 | Choose Path (3 options) |
| Expert | 300 | Gain Path Techniques (2) |
| Master | 600 | Ultimate transformation |

### Skill XP
- Using skill in meaningful situation (stakes exist)
- Defeating enemies while skill contributed
- Training with teacher (time + resources)

---

## Procedural Passive Progression

**Trigger Levels:** 3, 7, 12, 18, 25

At each trigger, generate 3 options:
- **Option A:** Amplifies primary strength
- **Option B:** Mitigates weakness or adds synergy
- **Option C:** Rewards actual playstyle

### Power Budget by Level

| Level | Stat Equivalent | Effect Type |
|-------|-----------------|-------------|
| 3 | +3-5 | Conditional bonus (+2-4) |
| 7 | +5-8 | 1/combat moderate effect |
| 12 | +8-12 | Significant always-on |
| 18 | +12-18 | Major fight-changing |
| 25 | +18-25 | Build-altering |

---

## Evolution Progression

**Trigger Levels:** 10, 20, 30

At each trigger, offer 5 options:
- **3 Core:** Aspect-gated, pre-defined evolutions
- **2 Branch:** Build-derived, procedurally generated

### Evolution Components

Each evolution provides:
1. **Core Passive:** ~2× procedural passive power
2. **Signature Ability:** 1/rest, ~Epic skill power
3. **Talent Tree:** 5-6 new talents unlocked

### Power Budget by Level

| Level | Passive Value | Signature Power |
|-------|---------------|-----------------|
| 10 | +16-24 stat equiv | 4d6+mod + strong rider |
| 20 | +24-36 stat equiv | 6d6+mod + multiple effects |
| 30 | +36-50 stat equiv | 8d6+mod + fight-ending |

---

## Summary: Character at Level 30

- **Attributes:** 64 points invested (58 base + 6 milestone), primary at 28-30 or balanced 18-22
- **Form Slots:** 9 (2 starting + 7 found)
- **Techniques:** Variable (based on what was found/learned)
- **Talents:** 29 (from ~138 accessible)
- **Skills:** Variable (based on Skill Stone drops)
- **Procedural Passives:** 5 (at levels 3, 7, 12, 18, 25)
- **Evolutions:** 3 (at levels 10, 20, 30)
