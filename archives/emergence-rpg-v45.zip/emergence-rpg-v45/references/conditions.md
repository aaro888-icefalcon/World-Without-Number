# Conditions & Status Effects

## Physical Conditions

| Condition | Effect | Cleared By |
|-----------|--------|------------|
| **Bleeding** | -2 HP per round | First aid (DC 9) |
| **Burning** | -3 HP per round | Extinguish (1 AP), water, roll |
| **Poisoned** | -1 all rolls | Treatment or time (varies) |
| **Exhausted** | -2 physical rolls, half move | Long rest |
| **Slowed** | Half movement | 3 rounds or cure |
| **Prone** | -2 DEF vs melee, +2 DEF vs ranged | Stand (1 AP) |
| **Grappled** | Cannot move, -2 attacks | Escape (opposed MIG/AGI) |
| **Restrained** | Cannot move, -4 DEF | Break free (DC varies) |
| **Paralyzed** | Cannot act or move | Duration ends or cure |
| **Unconscious** | Helpless, unaware | Damage, healing, or time |

## Mental Conditions

| Condition | Effect | Cleared By |
|-----------|--------|------------|
| **Stunned** | Cannot act this turn | End of turn |
| **Dazed** | 1 AP only | End of next turn |
| **Frightened** | Cannot approach source, -2 attacks | 3 rounds, courage, or source removed |
| **Charmed** | Cannot attack source, favorable | Duration or hostile action |
| **Confused** | Random action each turn | 3 rounds or cure |
| **Blinded** | -4 attacks, auto-fail sight checks | Cure or duration |
| **Deafened** | Auto-fail hearing, -2 initiative | Cure or duration |

## Magical Conditions

| Condition | Effect | Cleared By |
|-----------|--------|------------|
| **Mana Drained** | Cannot cast, -2 mental rolls | Rest or mana restoration |
| **Cursed** | Varies by curse | Specific cure |
| **Silenced** | Cannot speak or cast verbal | Duration or dispel |
| **Marked** | +2 attacks against you | 3 rounds or marker's death |

## Beneficial Conditions

| Condition | Effect | Duration |
|-----------|--------|----------|
| **Blessed** | +1 all rolls | Until used or combat ends |
| **Hasted** | +1 AP, +2 movement | 3 rounds |
| **Protected** | DR 2 (reduce damage by 2) | Until hit 3 times |
| **Invisible** | Cannot be targeted, advantage on attacks | Until attack or duration |
| **Regenerating** | +2 HP per round | Duration or damage type |

---

## Condition Stacking

- **Same condition:** Does not stack (refresh duration)
- **Different conditions:** Stack normally
- **Beneficial + Detrimental:** Both apply

---

## HP States Reference

| HP % | State | Penalty |
|------|-------|---------|
| 75-100% | Healthy | None |
| 50-74% | Wounded | None |
| 25-49% | Bloodied | -1 physical |
| 10-24% | Critical | -2 all |
| 1-9% | Near Death | -3 all |
| 0 | Down | Unconscious |
| <0 | Dying | See death rules |

---

## Death & Dying

### At 0 HP
- Fall unconscious immediately
- Begin dying (3 round countdown)
- Can be stabilized with First Aid (DC 11) or healing

### Stabilization
- First Aid: DC 11, takes 1 AP
- Any healing: Automatic stabilization
- Stabilized character remains at 0 HP, unconscious

### Death Occurs When
- 3 rounds pass without stabilization
- Damage reduces to -FOR or -10 (whichever more negative)
- Threat reaches helpless character with intent to kill
- Massive damage (single hit > max HP) is instant death

### Recovering from 0 HP
- Any healing brings to at least 1 HP
- Wake up after 1d6 × 10 minutes if stabilized
- Exhausted condition until long rest

---

## First Aid Actions

| Action | AP | DC | Effect |
|--------|----|----|--------|
| Stop Bleeding | 1 | 9 | Remove Bleeding |
| Stabilize | 1 | 11 | Stop dying countdown |
| Treat Poison | 2 | 11 | Remove Poisoned |
| Bandage | 1 | 7 | Heal 1d6 (once per combat) |

---

## Rest & Recovery

### Short Rest (1 hour)
- Regain Stamina: 50%
- Regain Mana: 50%
- No HP recovery without treatment

### Long Rest (8 hours)
- Regain HP: 100%
- Regain Stamina: 100%
- Regain Mana: 100%
- Remove Exhausted
- Clear most conditions

### Rest Interruption
- If rest interrupted, gain partial benefit (proportional)
- Combat during rest: No benefit from that rest
