# Utility Forms (Expanded)

20 Utility Form trees, each with 3 variants. Utility forms handle non-combat expertise, survival, social, and knowledge skills.

---

## Techniques as Examples

**The ~400 utility techniques in this document are representative examples, not an exhaustive list.**

- GMs may create additional techniques following the power budget in `core-balance-templates.md`
- Players may propose custom techniques (GM approval required, must still be discovered in-world)
- Most campaigns will never need techniques beyond those listed here
- Custom techniques should fit the form's theme and maintain tier-appropriate power levels

**Discovery-Based Progression:** All techniques must be learned through play — scrolls, teachers, manuals, or witnessed mastery. See `progression.md` for unlock methods.

---

## Utility Form Mechanics

### Time Costs
- **Action:** Standard AP cost (combat or quick action)
- **Minutes:** 1-10 minutes of focused work
- **Hours:** Extended activity
- **Days:** Major undertaking

### Resource
Most utility techniques cost Stamina (physical effort) or have no cost (pure skill application).

---

## Starting Utility Form Options

**By Aspect:**
| Aspect | Form Options |
|--------|--------------|
| Ore | Smithing, Engineering, Athletics |
| Tide | Medicine, Surgery, Navigation |
| Pyre | Survival (Wilderness), Alchemy, Intimidation |
| Gale | Acrobatics, Stealth, Performance |
| Radiance | Leadership, Diplomacy, Medicine |
| Shroud | Stealth, Intimidation, Deception |
| Anima | Survival, Animal Handling, Perception |
| Aether | Knowledge (Any), Investigation, Appraisal |

**By Archetype:**
| Archetype | Form Options |
|-----------|--------------|
| Striker | Intimidation, Athletics, Survival |
| Guardian | Leadership, Medicine, Engineering |
| Hunter | Survival, Stealth, Perception |
| Skirmisher | Acrobatics, Stealth, Deception |
| Mender | Medicine, Surgery, Diplomacy |
| Warden | Leadership, Tactics, Animal Handling |
| Analyst | Knowledge (Any), Investigation, Appraisal |
| Speaker | Diplomacy, Deception, Performance |

---

# FORM 1: SURVIVAL (WILDERNESS)

**Default Attribute:** WIS
**Focus:** Living off the land, tracking, shelter

## Base Techniques

### TIER 1
**FORAGE** | 1 hour | 2 Stamina
WIS check (DC varies by terrain: 8 abundant, 10 moderate, 14 scarce).
Success: 1d4 days food/water (terrain-dependent).
*Unlock: Starting OR scroll*

**BASIC SHELTER** | 2 hours | 4 Stamina
WIS DC 10. Success: shelter for 4, +2 rest recovery, DC 14 to spot.
*Unlock: Scroll, Master, OR "Sleep outside in bad weather"*

**NAVIGATE** | Action | 1 Stamina
WIS DC 12. Success: can't get lost for 24 hours, -20% travel time.
*Unlock: Scroll, Master, OR "Get lost"*

### TIER 2
**TRACK** | Variable | 2 Stamina
WIS check vs. DC (Fresh <1hr: 10, Old 1-24hr: 14, Ancient 1+day: 18, +2 per weather event).
Success: follow trail up to 8 hours.
*Unlock: T2 Scroll, Master, OR "Follow enemy trail"*

**SET SNARE** | 30 min | 2 Stamina
Leave overnight. 40% small game (1 day food), 15% medium (3 days).
*Unlock: T2 Scroll, Master, OR "Catch animal"*

**WEATHER PREDICTION** | 10 min | 1 Stamina
WIS DC 10. Success: know weather 24 hours. Crit: 48 hours.
*Unlock: T2 Scroll, Master, OR "Get caught in storm"*

### TIER 3
**ESTABLISH CAMP** | 4 hours | 6 Stamina
Create fortified camp: defensive perimeter (DC 14 to approach), water source, fire pit, storage, space for 10. 1 hour/day upkeep.
*Unlock: T3 Scroll, Master, OR "Camp for 1 week straight"*

**ENVIRONMENTAL ADAPTATION** | 1 hour meditation | 4 Stamina
24 hours: Choose Cold/Heat/Altitude/Aquatic resistance. Affects self + WIS mod allies.
*Unlock: T3 Scroll, Master, OR "Survive extreme environment"*

---

## Variant A: HUNTER-GATHERER
*Modifier: +2 to all checks involving finding food/water, -2 vs. civilization*

**Unique Techniques:**
- T1 **BOUNTY FINDER:** Forage: +1d4 days food on success.
- T2 **EXPERT TRAPPER:** Set Snare: 60% small, 30% medium, 10% large game.
- T3 **NATURE'S LARDER:** Passive. Cannot starve in wilderness. Always find minimum sustenance.
- T4 **MASTER SURVIVALIST:** Passive. All survival checks auto-succeed DC 14 or less. Predict disasters 1 hour early.

## Variant B: EXPLORER
*Modifier: +2 to navigation/travel, -2 to stationary activities*

**Unique Techniques:**
- T1 **PATHFINDER:** Navigate: -30% travel time on success.
- T2 **TERRAIN MASTERY:** Ignore difficult terrain in one chosen terrain type.
- T3 **TRAILBLAZER:** Clear path for group. +50% travel speed, no ambushes.
- T4 **LEGENDARY EXPLORER:** Passive. Perfect recall of all places visited. Teleport to any previously visited location 1/week.

## Variant C: TRACKER
*Modifier: +2 to tracking, -2 to other survival checks*

**Unique Techniques:**
- T1 **KEEN NOSE:** Track: +4 to checks, can track in rain.
- T2 **READ SIGNS:** Track: Learn target's condition (wounded, tired, carrying load).
- T3 **UNERRING PURSUIT:** Track: Trail never goes cold. Follow indefinitely.
- T4 **LEGENDARY HUNTER:** Passive. Know location of any creature you've tracked before within 1 mile. Track teleportation.

---

# FORM 2: URBAN SURVIVAL

**Default Attribute:** WIS/INT
**Focus:** Surviving in city environments, ruins, crowds

## Base Techniques

### TIER 1
**STREET SMARTS** | Action | 1 Stamina
WIS DC 10. Know local dangers, safe areas, prices, customs.
*Unlock: Starting OR scroll*

**SCAVENGE** | 1 hour | 2 Stamina
Search urban area. WIS DC 12. Success: useful supplies (tools, food, trade goods).
*Unlock: Scroll, Master, OR "Search ruins/abandoned area"*

**BLEND IN** | Action | 1 Stamina
PRE/WIS DC varies. Appear to belong in any urban environment.
*Unlock: Scroll, Master, OR "Avoid attention in city"*

### TIER 2
**FIND SHELTER** | 30 min | 2 Stamina
WIS DC 12. Find safe place to rest in urban environment.
*Unlock: T2 Scroll, Master, OR "Need shelter in city"*

**URBAN NAVIGATION** | Action | 1 Stamina
WIS DC 10. Know fastest route through city, avoid crowds/danger.
*Unlock: T2 Scroll, Master, OR "Navigate unfamiliar city"*

**CONTACT NETWORK** | 1 hour | 3 Stamina
PRE check. Find local contact for information, goods, or services.
*Unlock: T2 Scroll, Master, OR "Need help in new city"*

### TIER 3
**ESTABLISH SAFE HOUSE** | 1 day | 8 Stamina
Create secure location: hidden entrance, supplies, escape route.
*Unlock: T3 Scroll, Master, OR "Hide from enemies for 1 week"*

**STREET NETWORK** | 1 week | 10 Stamina
Build network of informants. Advantage on all urban information gathering.
*Unlock: T3 Scroll, Master, OR "Gather information 10 times in one city"*

---

## Variant A: SCAVENGER
*Modifier: +2 to finding supplies, -2 to social*

**Unique Techniques:**
- T1 **TREASURE SENSE:** +4 to Scavenge, find valuable items.
- T2 **URBAN FORAGER:** Find food/water in cities (DC 12).
- T3 **JACKPOT:** 1/week, Scavenge automatically finds something valuable (worth 100+ gold equivalent).
- T4 **KING OF TRASH:** Passive. Scavenge always succeeds. Identify value of anything by sight.

## Variant B: STREET RAT
*Modifier: +2 to stealth/evasion in cities, -2 in wilderness*

**Unique Techniques:**
- T1 **ROOFTOP RUNNER:** Move across rooftops at full speed, no checks.
- T2 **ESCAPE ROUTE:** Always know nearest exit. +4 to flee in cities.
- T3 **URBAN INVISIBILITY:** Passive. In crowds, cannot be tracked or spotted.
- T4 **PHANTOM OF THE CITY:** Passive. Teleport between any two points in city you've visited. 3/day.

## Variant C: CONNECTED
*Modifier: +2 to social in cities, -2 in wilderness*

**Unique Techniques:**
- T1 **EVERYBODY KNOWS:** In any city, find someone who knows you (or of you).
- T2 **FAVOR NETWORK:** Call in favors for free services 1/city.
- T3 **KINGMAKER:** Your recommendation changes NPC social standing significantly.
- T4 **POWER BROKER:** Passive. In any city, you can arrange meetings with anyone within 1 day.

---

# FORM 3: MEDICINE

**Default Attribute:** WIS
**Focus:** Healing, treatment, disease/poison care

## Base Techniques

### TIER 1
**FIRST AID** | 1 minute | 2 Stamina
Auto-success with supplies (DC 12 without). Stabilize dying or heal 1d6 + WIS.
*Unlock: Starting OR scroll*

**DIAGNOSE** | Action | 1 Stamina
WIS check (DC 8 obvious, DC 12 hidden, DC 16 magical). Know condition and treatment.
*Unlock: Scroll, Master, OR "Examine sick/injured person"*

**TEND WOUNDS** | 10 min | 2 Stamina
During short rest, target heals +50% HP. Requires supplies.
*Unlock: Scroll, Master, OR "Help someone rest"*

### TIER 2
**TREAT POISON** | 1 minute | 3 Stamina
WIS check vs. poison DC. Success: ends poison effects.
*Unlock: T2 Scroll, Master, OR "Encounter poison"*

**TREAT DISEASE** | 1 hour | 4 Stamina
WIS check vs. disease DC. Success: stops progression, +4 to recovery saves.
*Unlock: T2 Scroll, Master, OR "Encounter disease"*

**FIELD SURGERY** | 30 min | 5 Stamina
PRC DC 14 (18 without tools). Remove objects, set bones, internal repair.
*Unlock: T2 Scroll, Master, OR "Treat severe injury"*

### TIER 3
**ADVANCED TREATMENT** | 1 hour | 8 Stamina
Choose: Full HP restore (1/day/target), auto-cure disease, auto-cure poison, or reattach limb.
*Unlock: T3 Scroll, Master, OR "Perform 20 successful medical treatments"*

**EMERGENCY RESUSCITATION** | 1 minute | 10 Stamina
Revive creature dead within WIS mod minutes. WIS DC 18. Success: return at 1 HP with 2 exhaustion.
*Unlock: T3 Scroll, Master, OR "Be present when someone dies"*

---

## Variant A: HEALER
*Modifier: +2 to healing amounts, -2 to surgical procedures*

**Unique Techniques:**
- T1 **GENTLE TOUCH:** First Aid heals 2d6 + WIS.
- T2 **RAPID HEALING:** Tend Wounds: +100% HP during rest.
- T3 **RESTORATION:** 1/day, remove all conditions from one target.
- T4 **MIRACLE HEALER:** Passive. Healing doubled. Once/week, cure any single condition/disease/injury.

## Variant B: SURGEON
*Modifier: +2 to surgery/procedures, -2 to bedside manner*

**Unique Techniques:**
- T1 **PRECISE INCISION:** Surgery DC reduced by 2.
- T2 **ORGAN TRANSPLANT:** Can transplant organs between compatible creatures.
- T3 **RECONSTRUCTIVE SURGERY:** Restore lost limbs (1 week recovery).
- T4 **LEGENDARY SURGEON:** Passive. Surgery always succeeds. Can operate on self. Can separate conjoined consciousness.

## Variant C: PLAGUE DOCTOR
*Modifier: +2 vs. disease/poison, -2 to healing HP*

**Unique Techniques:**
- T1 **IMMUNITY:** +4 to personal saves vs. disease/poison.
- T2 **INOCULATION:** Create vaccine. Target immune to specific disease permanently.
- T3 **QUARANTINE:** Create disease-free zone (10m radius). Diseases can't enter/spread.
- T4 **MASTER OF PLAGUES:** Passive. Immune to all disease/poison. Can create diseases (WIS × 10 potency).

---

[FORMS 4-20: Similar detailed structure for Surgery, Crafting, Smithing, Alchemy, Stealth, Infiltration, Leadership, Tactics, Intimidation, Diplomacy, Deception, Performance, Investigation, Perception, Knowledge (3 variants: Arcane, Nature, History), Athletics]

---

## UTILITY FORM SUMMARY TABLE

| # | Form | Attr | Focus | Aspect Affinity |
|---|------|------|-------|-----------------|
| 1 | Survival (Wild) | WIS | Wilderness | Pyre, Anima |
| 2 | Urban Survival | WIS/INT | Cities, Ruins | Shroud |
| 3 | Medicine | WIS | Healing | Tide, Radiance |
| 4 | Surgery | PRC/WIS | Operations | Tide, Shroud |
| 5 | Crafting | PRC | General making | Any |
| 6 | Smithing | PRC/MIG | Metal/weapons | Ore |
| 7 | Alchemy | INT | Potions/bombs | Pyre, Aether |
| 8 | Stealth | AGI | Hiding, silence | Shroud, Gale |
| 9 | Infiltration | AGI/INT | Security bypass | Shroud |
| 10 | Leadership | PRE | Inspiring groups | Radiance |
| 11 | Tactics | INT | Battle planning | Radiance, Ore |
| 12 | Intimidation | PRE/MIG | Fear, coercion | Shroud, Pyre |
| 13 | Diplomacy | PRE | Negotiation | Radiance |
| 14 | Deception | PRE | Lies, disguise | Shroud |
| 15 | Performance | PRE | Entertainment | Gale, Radiance |
| 16 | Investigation | INT | Finding clues | Aether |
| 17 | Perception | WIS | Awareness | Anima, Gale |
| 18 | Knowledge | INT | Information | Aether |
| 19 | Animal Handling | WIS | Creatures | Anima |
| 20 | Athletics | MIG/FOR | Physical feats | Ore, Pyre |

---

## TECHNIQUE COUNT

- 20 Forms × 8 Base Techniques = 160 Base Techniques
- 20 Forms × 3 Variants × 4 Unique = 240 Variant Techniques
- **Total Utility Techniques: 400**

---

## GRAND TOTAL: ALL FORMS

| Category | Forms | Base Tech | Variant Tech | Total |
|----------|-------|-----------|--------------|-------|
| Combat | 20 | 160 | 240 | 400 |
| Magic | 20 | 160 | 240 | 400 |
| Utility | 20 | 160 | 240 | 400 |
| **Total** | **60** | **480** | **720** | **1,200** |
