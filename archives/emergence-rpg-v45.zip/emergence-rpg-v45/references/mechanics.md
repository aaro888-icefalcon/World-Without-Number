# Core Resolution Mechanics

## The Fundamental Rule

**Fiction First, Always.**
1. Player declares action (fiction)
2. Determine if mechanics apply
3. If uncertain AND stakes exist: roll
4. Translate result back to fiction

## When to Roll

**ROLL when:** Outcome uncertain AND stakes exist AND player declared intent.

**DON'T ROLL when:** Success trivial (auto-succeed), success impossible (explain why), no meaningful stakes.

---

## The Roll

All contested outcomes: **2d6 + Modifier vs DC**

### Resolution Bands

| Result | Condition | Outcome |
|--------|-----------|---------|
| **Critical** | Natural 12 (see crit range expansion) | ×2 damage + bonus effect |
| **Exceptional** | Natural 10-11 AND total ≥ DC | ×1.5 damage |
| **Success** | Total ≥ DC | Achieve intent fully |
| **Partial** | Total = DC-1 or DC-2 | Achieve with cost/complication, half damage |
| **Failure** | Total ≤ DC-3 | Do not achieve; GM makes move |
| **Critical Failure** | Natural 2 | Fail + additional consequence |

### Critical Range Expansion (Precision)

Higher Precision expands what counts as a critical hit:

| PRC Modifier | Crit on Natural | Crit Chance |
|--------------|-----------------|-------------|
| +0 to +2 | 12 only | 2.78% |
| +3 to +4 | 11-12 | 8.33% |
| +5 to +6 | 10-12 | 16.67% |
| +7+ | 9-12 (cap) | 27.78% |

**Note:** Critical range is based on the NATURAL dice roll before modifiers.

### Called Shots (Requires PRC mod ≥ 2)

High-precision characters can target specific body parts. See `references/attributes.md` for full details.

| PRC Mod | Called Shot Penalty |
|---------|---------------------|
| 2 | -3 |
| 3 | -2 |
| 4 | -1 |
| 5+ | No penalty |

### Difficulty Classes

| DC | Difficulty | Example |
|----|------------|---------|
| 5 | Trivial | Climbing a ladder |
| 7 | Easy | Hiding from distracted guard |
| 9 | Standard | Fighting equal opponent |
| 11 | Hard | Fighting elite enemy |
| 13 | Very Hard | Fighting boss creature |
| 15 | Extreme | Legendary feat |
| 17 | Legendary | Should not be possible |
| 19+ | Mythic | Defying reality |

---

## Modifier Calculation

**Total Modifier = Attribute Mod + Skill Mod + Circumstance**

### Attribute Modifiers

**Formula:** `floor((Attribute - 10) / 2)`

| Attribute | Mod | | Attribute | Mod |
|-----------|-----|---|-----------|-----|
| 6-7 | -2 | | 18-19 | +4 |
| 8-9 | -1 | | 20-21 | +5 |
| 10-11 | +0 | | 22-23 | +6 |
| 12-13 | +1 | | 24-25 | +7 |
| 14-15 | +2 | | 26-27 | +8 |
| 16-17 | +3 | | 28+ | +9+ |

**Attribute Caps by Level:**

Formula: Cap = 12 + (Level ÷ 2, rounded down)

| Level | Cap | Max Mod |
|-------|-----|---------|
| 1 | 12 | +1 |
| 5 | 14 | +2 |
| 10 | 17 | +3 |
| 15 | 19 | +4 |
| 20 | 22 | +6 |
| 25 | 24 | +7 |
| 30 | 27 | +8 |

See `references/attributes.md` for full attribute system, weapon/spell assignments, and equipment tiers.

### Skill Modifiers

| Rank | Mod |
|------|-----|
| Untrained | -2 |
| Novice | +0 |
| Apprentice | +1 |
| Journeyman | +2 |
| Expert | +3 |
| Master | +4 |
| Grandmaster | +5 |

### Circumstance Modifiers

| Circumstance | Mod |
|--------------|-----|
| Ideal conditions | +2 |
| Favorable | +1 |
| Unfavorable | -1 |
| Terrible | -2 |
| Appropriate tools | +1 |
| Improvised/lacking | -1 |
| Severely wounded (<25% HP) | -2 |

---

## Advantage and Disadvantage

**Advantage:** Roll 3d6, keep highest 2.
**Disadvantage:** Roll 3d6, keep lowest 2.

If both apply, they cancel.

---

## Script Usage

```python
from scripts.dice import roll_2d6

# Basic roll
result = roll_2d6(modifier=4, dc=11, description="Attack vs Goblin")

# With advantage
result = roll_2d6(modifier=2, dc=13, description="Stealth", advantage=True)
```
