# Magic Forms (Expanded)

20 Magic Form trees, each with 3 variants. Each variant modifies all techniques and adds 1 unique technique per tier.

---

## Techniques as Examples

**The ~400 magic techniques in this document are representative examples, not an exhaustive list.**

- GMs may create additional techniques following the power budget in `core-balance-templates.md`
- Players may propose custom techniques (GM approval required, must still be discovered in-world)
- Most campaigns will never need techniques beyond those listed here
- Custom techniques should fit the form's theme and maintain tier-appropriate power levels

**Discovery-Based Progression:** All techniques must be learned through play — scrolls, teachers, manuals, or witnessed mastery. See `progression.md` for unlock methods.

---

## Starting Magic Form Options

**By Aspect:**
| Aspect | Form Options |
|--------|--------------|
| Ore | Earth, Metal, Warding |
| Tide | Water/Ice, Healing, Spirit |
| Pyre | Fire, Light, Force |
| Gale | Lightning, Wind, Force |
| Radiance | Light, Healing, Warding |
| Shroud | Blood, Death, Shadow |
| Anima | Beast/Nature, Spirit, Plant |
| Aether | Void, Time, Illusion |

**By Archetype:**
| Archetype | Form Options |
|-----------|--------------|
| Striker | Fire, Lightning, Force |
| Guardian | Warding, Earth, Metal |
| Hunter | Wind, Shadow, Illusion |
| Skirmisher | Shadow, Lightning, Force |
| Mender | Healing, Light, Spirit |
| Warden | Any control form (Earth, Water/Ice, Plant, Mind) |
| Analyst | Illusion, Mind, Time |
| Speaker | Mind, Light, Spirit |

---

# FORM 1: FIRE

**Default Attribute:** INT
**Damage Type:** Fire
**Aspect Affinity:** Pyre

## Base Techniques

### TIER 1
**FLAME BOLT** | 1 AP | 2 Mana | 30m
Spell attack. 2d6 + INT fire damage.
*Unlock: Starting OR scroll*

**IGNITE** | 1 AP | 1 Mana | 10m
Set object on fire or deal 1d6 fire + burning (2/round, 3 rounds).
*Unlock: Scroll, Master, OR "Set something on fire"*

**WARMTH** | 0 AP | 1 Mana | Self, 3m radius
1 hour: Allies immune to cold weather, resist cold damage.
*Unlock: Scroll, Master, OR "Survive in cold environment"*

### TIER 2
**BURNING HANDS** | 2 AP | 4 Mana | 5m cone
All in cone: AGI save. Fail: 3d6 fire. Pass: half.
*Unlock: T2 Scroll, Master, OR "Hit 3 enemies with fire"*

**FLAME SHIELD** | 1 AP | 3 Mana | Self, 3 rounds
Melee attackers take 1d6 fire. Resist cold.
*Unlock: T2 Scroll, Master, OR "Take cold damage"*

**HEAT METAL** | 2 AP | 4 Mana | 30m, 3 rounds
Metal object becomes searing. Worn: 2d6 fire/round, WIL save or drop.
*Unlock: T2 Scroll, Master, OR "Fight armored enemy with fire"*

### TIER 3
**FIREBALL** | 3 AP | 8 Mana | 60m, 6m radius
Classic. AGI save. Fail: 6d6 fire. Pass: half. Ignites everything.
*Unlock: T3 Scroll, Master, OR "Deal 30 fire damage in one turn"*

**WALL OF FLAME** | 3 AP | 7 Mana | 30m, 5 rounds
10m long, 3m high. Enter/start in: 4d6 fire. Provides cover.
*Unlock: T3 Scroll, Master, OR "Create barrier with fire"*

---

## Variant A: INFERNO
*Modifier: +1 fire damage per die, +1 Mana cost*

**Unique Techniques:**
- T1 **SEARING BOLT:** 1 AP, 3 Mana. 2d6+2 fire, target burns (3/round, 2 rounds).
- T2 **CONFLAGRATION:** 2 AP, 5 Mana. 5m radius. 2d6 fire, all flammables ignite.
- T3 **HELLFIRE:** 3 AP, 10 Mana. 8d6 fire, 5m radius. Fire damage ignores resistance.
- T4 **LORD OF FLAMES:** Passive. Fire damage +50%. Immune to fire. Command fire elementals.

## Variant B: CONTROLLED BURN
*Modifier: Can exclude allies from AOE, -1 damage per die*

**Unique Techniques:**
- T1 **PRECISE FLAME:** 1 AP, 2 Mana. 2d6 fire, never hits unintended targets.
- T2 **SHAPED CHARGE:** 2 AP, 4 Mana. Fireball but YOU choose exact area shape.
- T3 **SELECTIVE IMMOLATION:** 3 AP, 7 Mana. All enemies in 10m: 4d6 fire. Allies untouched.
- T4 **FLAME SCULPTOR:** Passive. All fire AOE: choose targets. Can create shapes that persist.

## Variant C: EMBER
*Modifier: Burns last +1 round, -1 damage per tick*

**Unique Techniques:**
- T1 **LINGERING FLAMES:** 1 AP, 2 Mana. 1d6 fire, burning 5 rounds.
- T2 **SPREADING FIRE:** Passive. Burning targets ignite adjacent enemies (1d6/round, 2 rounds).
- T3 **ETERNAL FLAME:** 3 AP, 8 Mana. Target burns permanently until magically extinguished.
- T4 **PHOENIX EMBER:** Passive. When you die, explode (6d6 fire, 5m), revive at 25% HP. 1/day.

---

# FORM 2: WATER/ICE

**Default Attribute:** INT
**Damage Type:** Cold/Bludgeoning
**Aspect Affinity:** Tide

## Base Techniques

### TIER 1
**FROST RAY** | 1 AP | 2 Mana | 30m
Spell attack. 2d6 cold, -2m speed for 1 round.
*Unlock: Starting OR scroll*

**CREATE WATER** | 1 AP | 1 Mana | 10m
10 gallons water. Can extinguish fires.
*Unlock: Scroll, Master, OR "Need water"*

**ICE SLICK** | 1 AP | 2 Mana | 20m, 3m radius, 5 rounds
AGI save or prone when entering.
*Unlock: Scroll, Master, OR "Make enemy fall"*

### TIER 2
**FREEZING BLAST** | 2 AP | 4 Mana | 15m cone
3d6 cold, AGI half. Fail: Slowed 2 rounds.
*Unlock: T2 Scroll, Master, OR "Slow 3 enemies"*

**WATER BREATHING** | 1 AP | 3 Mana | Touch, 1 hour
Target breathes underwater. +2 Mana per additional target.
*Unlock: T2 Scroll, Master, OR "Go underwater"*

**ICE ARMOR** | 2 AP | 4 Mana | Self, combat duration
+3 DEF, resist fire. Shatters if 15+ damage in one hit.
*Unlock: T2 Scroll, Master, OR "Take 15+ damage in one hit"*

### TIER 3
**FLASH FREEZE** | 2 AP | 6 Mana | 30m
FOR save. Fail: Frozen (incapacitated, 0 DEF, vulnerable to blunt). Pass: Slowed + 4d6 cold.
*Unlock: T3 Scroll, Master, OR "Freeze an enemy"*

**TIDAL WAVE** | 3 AP | 8 Mana | 40m
10m wide, 5m tall wave travels 20m. All in path: 5d6 bludgeon, AGI half, prone + pushed.
*Unlock: T3 Scroll, Master, OR "Push 5 enemies"*

---

## Variant A: GLACIER
*Modifier: Cold damage slows target 1m, +1 Mana cost*

**Unique Techniques:**
- T1 **CREEPING COLD:** 1 AP, 3 Mana. 2d6 cold, Slowed 1 round.
- T2 **GLACIAL SPIKE:** 2 AP, 5 Mana. 4d6 cold, single target. Frozen on crit.
- T3 **ABSOLUTE ZERO:** 3 AP, 10 Mana. 5m radius. FOR save or Frozen. Pass: 6d6 cold.
- T4 **ICE EMPEROR:** Passive. Cold damage +50%. Immune to cold/freeze. Walk on water (freezes).

## Variant B: CURRENT
*Modifier: Techniques push 2m, -1 damage per die*

**Unique Techniques:**
- T1 **WATER JET:** 1 AP, 2 Mana. 1d6 bludgeon, push 4m.
- T2 **UNDERTOW:** 2 AP, 4 Mana. All in 5m radius: MIG save or pulled 5m toward you.
- T3 **MAELSTROM:** 3 AP, 8 Mana. 10m radius whirlpool. Enemies: 3d6/round, can't leave (MIG save).
- T4 **TIDE LORD:** Passive. Control water in 30m. Underwater: +4 all rolls. Breathe water.

## Variant C: MIST
*Modifier: Create concealment with all techniques, -1 damage die*

**Unique Techniques:**
- T1 **FOG CLOUD:** 1 AP, 2 Mana. 10m radius fog, lightly obscures, 5 minutes.
- T2 **FREEZING MIST:** 2 AP, 4 Mana. Fog deals 1d6 cold/round to enemies inside.
- T3 **BLINDING BLIZZARD:** 3 AP, 7 Mana. 20m radius. 2d6 cold/round, heavily obscured, difficult terrain.
- T4 **PHANTOM MIST:** Passive. You see through mist/fog. Can teleport between connected mist areas.

---

# FORM 3: LIGHTNING

**Default Attribute:** INT
**Damage Type:** Lightning
**Aspect Affinity:** Gale

## Base Techniques

### TIER 1
**SHOCK** | 1 AP | 2 Mana | 30m
Spell attack. 2d6 lightning. +2 vs metal armor.
*Unlock: Starting OR scroll*

**STATIC SHIELD** | 1 AP | 2 Mana | Self, 3 rounds
First melee attacker takes 2d6 lightning, shield ends.
*Unlock: Scroll, Master, OR "Get hit in melee"*

**ARC** | 1 AP | 2 Mana | 15m
Hit target and one adjacent enemy. 1d6 each.
*Unlock: Scroll, Master, OR "Hit grouped enemies"*

### TIER 2
**LIGHTNING BOLT** | 2 AP | 5 Mana | 60m line, 2m wide
AGI save. Fail: 4d6 lightning. Pass: half. Arcs through water.
*Unlock: T2 Scroll, Master, OR "Hit 3 enemies with lightning"*

**CHARGED WEAPON** | 1 AP | 3 Mana | Touch, 5 rounds
Weapon deals +2d6 lightning on hit.
*Unlock: T2 Scroll, Master, OR "Enhance ally's weapon"*

**ELECTROMAGNETIC PULSE** | 2 AP | 4 Mana | 10m radius
Disrupts technology/constructs. 3d6 to constructs, disables electronics.
*Unlock: T2 Scroll, Master, OR "Fight construct/technology"*

### TIER 3
**CHAIN LIGHTNING** | 3 AP | 8 Mana | 40m
Hit target, arc to 3 more within 10m. 4d6 each. Can't hit same twice.
*Unlock: T3 Scroll, Master, OR "Hit 4 enemies in one turn"*

**CALL LIGHTNING** | 3 AP | 7 Mana | 60m, 3 rounds
Summon storm. Each round as 1 AP: call bolt, 3d6, single target.
*Unlock: T3 Scroll, Master, OR "Fight in storm/rain"*

---

## Variant A: THUNDER
*Modifier: Lightning damage also deafens 1 round, +1 Mana cost*

**Unique Techniques:**
- T1 **THUNDERCLAP:** 1 AP, 3 Mana. 3m radius. 2d6 thunder, FOR save or Deafened 1 minute.
- T2 **SONIC BOOM:** 2 AP, 5 Mana. 15m cone. 3d6 thunder, pushed 3m, Deafened.
- T3 **THUNDERSTORM:** 3 AP, 9 Mana. 20m radius storm, 3 rounds. 2d6 lightning+thunder/round.
- T4 **STORM GOD:** Passive. Immune to lightning/thunder/deafness. Thunder damage stuns 1 round.

## Variant B: SPEED
*Modifier: You gain +2m movement when casting, -1 damage per die*

**Unique Techniques:**
- T1 **QUICKSTEP:** 0 AP, 1 Mana. Move 4m without provoking.
- T2 **LIGHTNING REFLEXES:** Reaction, 2 Mana. +4 DEF vs one attack.
- T3 **FLASH STEP:** 2 AP, 5 Mana. Teleport up to 30m in a lightning flash.
- T4 **LIVING LIGHTNING:** Passive. Move at double speed. Once/round, move through enemies (2d6 each).

## Variant C: CONDUCTOR
*Modifier: Enemies in metal armor take +2 damage, -1 vs. unarmored*

**Unique Techniques:**
- T1 **MAGNETIZE:** 1 AP, 2 Mana. Target's metal equipment: -2 to hit, +2 to be hit, 3 rounds.
- T2 **CHAIN CONDUCTOR:** Passive. Lightning arcs to ALL metal-armored enemies within 5m of target.
- T3 **MAGNETIC PULL:** 2 AP, 5 Mana. All metal objects in 10m fly to point you choose.
- T4 **STORM CONDUIT:** Passive. Absorb lightning (heals you). Redirect enemy lightning spells.

---

# FORM 4: WIND

**Default Attribute:** INT
**Damage Type:** Bludgeoning/Slashing (air pressure)
**Aspect Affinity:** Gale

## Base Techniques

### TIER 1
**GUST** | 1 AP | 1 Mana | 20m
Push target 4m. Clear smoke/gas. Slam doors.
*Unlock: Starting OR scroll*

**AIR BLADE** | 1 AP | 2 Mana | 30m
Spell attack. 2d6 slashing.
*Unlock: Scroll, Master, OR "Attack with wind"*

**FEATHER FALL** | Reaction | 1 Mana | Self
Negate fall damage for you and allies within 10m.
*Unlock: Scroll, Master, OR "Fall from height"*

### TIER 2
**WIND WALL** | 2 AP | 4 Mana | 30m, 5 rounds
10m long, 5m high. Ranged auto-miss. Small creatures can't pass.
*Unlock: T2 Scroll, Master, OR "Block ranged attack"*

**TAILWIND** | 1 AP | 3 Mana | Self, 5m radius, 5 rounds
You and allies: +4m movement, +2 DEF vs ranged.
*Unlock: T2 Scroll, Master, OR "Help allies move"*

**VACUUM BURST** | 2 AP | 4 Mana | 10m, 3m radius
Remove air. All in area: 2d6 damage, can't speak/cast for 1 round.
*Unlock: T2 Scroll, Master, OR "Stop enemy spellcaster"*

### TIER 3
**CYCLONE** | 3 AP | 7 Mana | 30m, 3 rounds
5m radius tornado. Enter/start: MIG save or pulled to center, 3d6. Move 10m/round.
*Unlock: T3 Scroll, Master, OR "Create wind effect"*

**HURRICANE FORCE** | 3 AP | 8 Mana | 60m cone
All: 5d6 bludgeon, AGI half, pushed to edge and prone.
*Unlock: T3 Scroll, Master, OR "Push 5 enemies at once"*

---

## Variant A: RAZOR WIND
*Modifier: All damage becomes slashing, +1 damage per die*

**Unique Techniques:**
- T1 **CUTTING GUST:** 1 AP, 2 Mana. 2d6 slashing, bleeds on 10+.
- T2 **WIND SCYTHE:** 2 AP, 4 Mana. 10m line, 3d6 slashing, bleeds.
- T3 **THOUSAND CUTS:** 3 AP, 7 Mana. Single target: 6d6 slashing, bleed 2d6/round 3 rounds.
- T4 **BLADE STORM:** Passive. 5m aura deals 1d6 slashing to enemies entering/starting. You're immune.

## Variant B: FLIGHT
*Modifier: Gain 2m hover while concentrating on wind spell, -1 damage die*

**Unique Techniques:**
- T1 **LEVITATE:** 1 AP, 2 Mana. Hover 2m off ground for 5 rounds.
- T2 **FLY:** 2 AP, 4 Mana. Fly equal to walk speed for 10 minutes.
- T3 **WINDBORN:** 3 AP, 6 Mana. You and allies (up to 4) fly for 1 hour.
- T4 **MASTER OF AIR:** Passive. Permanent flight. Immune to fall damage. Control all air in 30m.

## Variant C: PRESSURE
*Modifier: Techniques push 2m, -1 to hit*

**Unique Techniques:**
- T1 **FORCE PUSH:** 1 AP, 2 Mana. Push target 6m. MIG save or prone.
- T2 **PRESSURE WAVE:** 2 AP, 4 Mana. 5m radius. All pushed 4m from center.
- T3 **CRUSH:** 3 AP, 7 Mana. Single target: 4d6 bludgeon, Restrained (compressed air) 2 rounds.
- T4 **GRAVITY WELL:** Passive. Enemies in 10m: -2m movement. You can walk on walls/ceiling.

---

[FORMS 5-20: Similar detailed structure for Earth, Metal, Light, Shadow, Healing, Blood, Death, Spirit, Beast/Nature, Plant, Force, Illusion, Mind, Warding, Time, Void]

---

## MAGIC FORM SUMMARY TABLE

| # | Form | Attr | Damage Type | Aspect Affinity |
|---|------|------|-------------|-----------------|
| 1 | Fire | INT | Fire | Pyre |
| 2 | Water/Ice | INT | Cold/Bludgeon | Tide |
| 3 | Lightning | INT | Lightning | Gale |
| 4 | Wind | INT | Bludgeon/Slash | Gale |
| 5 | Earth | INT/WIS | Bludgeon | Ore |
| 6 | Metal | INT | Pierce/Slash | Ore |
| 7 | Light | WIS | Radiant | Radiance |
| 8 | Shadow | INT/WIL | Necrotic | Shroud |
| 9 | Healing | WIS | — (Healing) | Radiance, Tide |
| 10 | Blood | WIL | Necrotic | Shroud |
| 11 | Death | WIL | Necrotic | Shroud |
| 12 | Spirit | WIS | Psychic | Anima, Tide |
| 13 | Beast/Nature | WIS | Nature | Anima |
| 14 | Plant | WIS | Poison/Bludgeon | Anima |
| 15 | Force | INT | Force | Any |
| 16 | Illusion | INT | Psychic | Aether |
| 17 | Mind | WIL | Psychic | Aether, Radiance |
| 18 | Warding | WIS/INT | — (Protection) | Radiance, Ore |
| 19 | Time | INT | — (Control) | Aether |
| 20 | Void | INT/WIL | Force | Aether |

---

## TECHNIQUE COUNT

- 20 Forms × 8 Base Techniques = 160 Base Techniques
- 20 Forms × 3 Variants × 4 Unique = 240 Variant Techniques
- **Total Magic Techniques: 400**

Full details in supplementary files:
- forms-magic-elemental.md (Forms 1-6)
- forms-magic-divine.md (Forms 7-11)
- forms-magic-primal.md (Forms 12-14)
- forms-magic-arcane.md (Forms 15-20)
