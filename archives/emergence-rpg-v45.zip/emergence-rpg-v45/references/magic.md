# Magic System

## Magic Types

| Type | Flavor | Default Attr | Source |
|------|--------|--------------|--------|
| **Arcane** | Direct manipulation, elements | INT | Study, innate talent |
| **Divine** | Granted power, healing | WIS | Faith, deity connection |
| **Primal** | Nature, beasts, elements | WIS | Nature bond, ancestry |
| **Blood** | Life force, sacrifice | WIL | Self, life energy |
| **Psionic** | Mental, telekinetic | WIL | Mind, consciousness |
| **Command** | Inspiration, fear, morale | PRE | Personality, leadership |

---

## Alternate Spell Attributes (Talent Required)

| Magic Type | Default | Alternate | Talent Name |
|------------|---------|-----------|-------------|
| Arcane | INT | WIL | Raw Channeling |
| Divine | WIS | PRE | Devoted Faith |
| Divine | WIS | WIL | Iron Faith |
| Primal | WIS | INT | Studied Nature |
| Primal | WIS | FOR | Elemental Body |
| Blood | WIL | FOR | Blood Price |
| Blood | WIL | INT | Calculated Sacrifice |
| Psionic | WIL | INT | Logic Mind |
| Psionic | WIL | WIS | Empathic Link |
| Command | PRE | WIL | Force of Personality |
| Command | PRE | WIS | Read the Room |

---

## Spell Tiers

| Tier | Name | Attr Req | Level Req | Typical Effects | Mana Cost |
|------|------|----------|-----------|-----------------|-----------|
| 0 | Cantrip | — | — | Minor utility, 1d6 damage | 0 |
| 1 | Novice | 12+ | — | Basic combat/utility, 2d6 damage | 2-3 |
| 2 | Journeyman | 14+ | 3+ | Solid effects, 3d6 damage | 4-6 |
| 3 | Expert | 16+ | 7+ | Strong effects, 4d6 damage | 8-10 |
| 4 | Master | 18+ | 12+ | Powerful effects, 5d6 damage | 12-15 |
| 5 | Grandmaster | 20+ | 18+ | Devastating, 6d6 damage | 18-22 |
| 6 | Legendary | 24+ | 25+ | Reality-altering | 25+ |

**Spell Power = Attribute mod + (Level ÷ 3)**

### Overcasting

Characters may attempt to cast spells one tier above their qualification:

- **Mana Cost:** Double normal cost
- **Disadvantage:** All spell attack rolls and effect DCs
- **Failure Cost:** On failed attack or save, caster takes 1d6 psychic damage per tier overcast
- **Example:** A L5 caster (Tier 2 qualified) casts a Tier 3 spell at double mana, with disadvantage, taking 3d6 psychic damage on failure.

**Overcasting is risky but enables dramatic moments when stakes demand it.**

---

## Spell Schools by Aspect

| Aspect | Primary School | Secondary School |
|--------|----------------|------------------|
| Ore | Earth, Metal | Force, Gravity |
| Tide | Water, Ice | Divination, Flow |
| Pyre | Fire, Heat | Wood, Growth |
| Gale | Wind, Lightning | Sound, Force |
| Radiance | Light, Healing | Truth, Purification |
| Shroud | Shadow, Death | Blood, Fear |
| Anima | Beast, Nature | Spirit, Instinct |
| Aether | Void, Time | Space, Reality |

---

## Magic Schools by Type

Each magic form (school) belongs to one or more magic types. The type determines the default casting attribute.

| Form | Default Attr | Magic Type | Notes |
|------|--------------|------------|-------|
| Fire | INT | Arcane | Raw elemental manipulation |
| Water/Ice | INT | Arcane | Fluid elemental |
| Lightning | INT | Arcane | Energy manipulation |
| Wind | INT | Arcane | Air elemental |
| Earth | INT | Arcane **OR** Primal | Choose at form acquisition |
| Metal | INT | Arcane | Transmutation magic |
| Light | WIS | Divine | Sacred illumination |
| Healing | WIS | Divine | Restorative magic |
| Warding | WIS | Divine | Protective barriers |
| Shadow | INT **OR** WIL | Arcane **OR** Psionic | Choose at form acquisition |
| Blood | WIL | Blood | Life force manipulation |
| Death | WIL | Blood | Entropy and undeath |
| Spirit | WIS | Primal **OR** Divine | Choose at form acquisition |
| Beast/Nature | WIS | Primal | Wild magic, animals |
| Plant | WIS | Primal | Botanical magic |
| Force | INT | Arcane | Telekinetic manipulation |
| Time | INT | Arcane | Temporal effects |
| Illusion | INT **OR** WIL | Arcane **OR** Psionic | Choose at form acquisition |
| Mind | WIL | Psionic | Mental manipulation |
| Void | INT/WIL | Arcane | Use highest of INT or WIL |

**Dual-Type Forms:** Forms marked with "OR" require the player to choose one type at acquisition. This choice is permanent and affects which alternate attribute talents apply.

---

## Mana Recovery

| Condition | Recovery Rate |
|-----------|---------------|
| Short rest (10 min) | Level + INT mod |
| Long rest (8 hours) | Full |
| Meditation (1 hour) | WIL mod × 2 |
| Mana potion | Varies by tier |

---

## Concentration

Spells marked (Concentration) require:
- Cannot cast another concentration spell
- Taking damage: WIL check DC 10 + damage taken
- WIL mod +3 breakpoint: Can maintain while taking damage
- Unconscious = concentration ends
