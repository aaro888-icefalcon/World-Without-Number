# Combat Forms (Expanded)

20 Combat Form trees, each with 3 variants. Each variant modifies all techniques and adds 1 unique technique per tier.

---

## Techniques as Examples

**The ~400 combat techniques in this document are representative examples, not an exhaustive list.**

- GMs may create additional techniques following the power budget in `core-balance-templates.md`
- Players may propose custom techniques (GM approval required, must still be discovered in-world)
- Most campaigns will never need techniques beyond those listed here
- Custom techniques should fit the form's theme and maintain tier-appropriate power levels

**Discovery-Based Progression:** All techniques must be learned through play — scrolls, teachers, manuals, or witnessed mastery. See `progression.md` for unlock methods.

---

## Form Slot Progression

| Level | Slots | Source |
|-------|-------|--------|
| 1 | 2 | Starting (Aspect×Archetype choice of 4) |
| 4 | 3 | +1 |
| 8 | 4 | +1 |
| 12 | 5 | +1 |
| 16 | 6 | +1 |
| 20 | 7 | +1 |
| 24 | 8 | +1 |
| 28 | 9 | +1 |

## Starting Form Options

**By Aspect (choose 2 available):**
| Aspect | Form Options |
|--------|--------------|
| Ore | Heavy Crush, Shield, Defensive Arts |
| Tide | Finesse Blade, Grappling, Thrown |
| Pyre | Heavy Blade, Axe, Aggressive Arts |
| Gale | Light Blade, Shortbow, Thrown |
| Radiance | Medium Blade, Shield, Defensive Arts |
| Shroud | Light Blade, Finesse Blade, Unarmed Strike |
| Anima | Unarmed Strike, Grappling, Environmental |
| Aether | Crossbow, Defensive Arts, Any (wild card) |

**By Archetype (choose 2 available):**
| Archetype | Form Options |
|-----------|--------------|
| Striker | Heavy Blade, Heavy Crush, Aggressive Arts |
| Guardian | Shield, Defensive Arts, Medium Crush |
| Hunter | Longbow, Crossbow, Thrown |
| Skirmisher | Light Blade, Finesse Blade, Dual Wield |
| Mender | Medium Blade, Defensive Arts, Shield |
| Warden | Polearm, Shield, Environmental |
| Analyst | Crossbow, Finesse Blade, Thrown |
| Speaker | Medium Blade, Finesse Blade, Defensive Arts |

---

## Technique Unlock Methods

Techniques are NOT unlocked by use count. They must be discovered:

1. **Scroll/Manual:** Found as loot or purchased
2. **Master NPC:** Taught by skilled teacher
3. **Survival Unlock:** Specific combat conditions trigger
4. **Witnessed:** See enemy use, INT/WIS check to learn

---

## Variant System

Each form has 3 variants. When you acquire a form, choose a variant. The variant:
- Applies a **Modifier** to ALL techniques in the form
- Provides **1 Unique Technique** per tier (4 total)

Variant choice is permanent but you can learn the same form again with a different variant (costs a slot).

---

# FORM 1: HEAVY BLADE

**Default Attribute:** MIG
**Weapons:** Greatsword, Claymore, Zweihander, Flamberge

## Base Techniques

### TIER 1
**POWER STRIKE** | 1 AP | 2 Stamina
Attack with +3 damage. +5 damage vs. full HP targets.
*Unlock: Starting technique OR any T1 scroll*

**WIDE SWEEP** | 2 AP | 3 Stamina
Attack all enemies in melee range. Single roll vs. each.
*Unlock: Scroll, Master, OR "Hit 3+ enemies in one round"*

**STAGGERING BLOW** | 1 AP | 2 Stamina
Attack. On hit, target -2 ATK and -2 DEF until end of your next turn.
*Unlock: Scroll, Master, OR "Witness enemy use stagger effect"*

### TIER 2
**CRUSHING OVERHEAD** | 2 AP | 4 Stamina
+2 to hit. On hit, FOR save or knocked prone.
*Unlock: T2 Scroll, Master (1 week), OR "Knock 5 enemies prone total"*

**CLEAVE** | Reaction | 2 Stamina
When you drop enemy to 0 HP, free attack vs. another in reach at -2.
*Unlock: T2 Scroll, Master, OR "Kill 2 enemies in same turn"*

**INTIMIDATING PRESENCE** | Passive | —
Enemies you've damaged have -1 to attack you.
*Unlock: T2 Scroll, Master, OR "Survive combat vs. 5+ enemies"*

### TIER 3
**EXECUTIONER'S SWING** | 2 AP | 5 Stamina
Attack enemy below 50% HP at +50% damage. On crit vs. target ≤30 HP, instant kill.
*Unlock: T3 Scroll, Master (2 weeks), OR "Execute 3 enemies with finishing blows"*

**EARTHSHAKER** | 3 AP | 8 Stamina
Slam ground. 3m radius: MIG×2 damage, AGI save or prone and immobile 1 turn.
*Unlock: T3 Scroll, Master, OR "Deal 50+ damage in single attack"*

---

## Variant A: DEVASTATOR
*Modifier: All techniques +1 damage, -1 to hit*

**Unique Techniques:**
- T1 **BRUTAL CHOP:** 1 AP, 3 Stam. Attack at -2 to hit, +6 damage.
- T2 **SUNDER ARMOR:** 2 AP, 4 Stam. On hit, reduce target armor by 2 permanently (repairs fix).
- T3 **ANNIHILATING STRIKE:** 3 AP, 7 Stam. Attack. Damage ignores armor and resistance.
- T4 **WORLD CLEAVER:** Passive. Crits deal +100% (not +50%). Once/rest, auto-crit on any attack.

## Variant B: WARDEN BLADE
*Modifier: All techniques +1 DEF until next turn after use, +1 Stamina cost*

**Unique Techniques:**
- T1 **DEFENSIVE SWEEP:** 2 AP, 4 Stam. Wide Sweep that also grants +2 DEF for 1 round.
- T2 **BLADE BARRIER:** 1 AP, 3 Stam. Hold blade defensively. +3 DEF, can't attack until next turn.
- T3 **RETALIATING GUARD:** Reaction, 4 Stam. When hit, reduce damage by MIG mod and counterattack.
- T4 **FORTRESS OF STEEL:** Passive. +2 DEF while wielding heavy blade. Allies adjacent gain +1 DEF.

## Variant C: FLOWING GREATSWORD
*Modifier: All techniques allow 2m movement after use, +1 AP cost on T2+*

**Unique Techniques:**
- T1 **PASSING SLASH:** 1 AP, 2 Stam. Attack while moving through enemy space.
- T2 **MOMENTUM STRIKE:** 2 AP, 4 Stam. +2 damage for every 2m moved before attack (max +8).
- T3 **WHIRLWIND:** 3 AP, 6 Stam. Spin while moving. Attack everyone you pass within 2m.
- T4 **DANCE OF DEATH:** Passive. No opportunity attacks while wielding heavy blade. +4m move/turn.

---

# FORM 2: HEAVY CRUSH

**Default Attribute:** MIG
**Weapons:** Maul, Warhammer, Tetsubo, Great Flail

## Base Techniques

### TIER 1
**CRUSHING BLOW** | 1 AP | 2 Stamina
Attack with +2 damage. Ignores 2 armor.
*Unlock: Starting OR scroll*

**SKULL CRACK** | 1 AP | 3 Stamina
Attack. On hit, target WIL save or Dazed (-2 all rolls) 1 round.
*Unlock: Scroll, Master, OR "Daze an enemy with any attack"*

**DEMOLISH** | 2 AP | 3 Stamina
Attack object or structure. Triple damage to inanimate objects.
*Unlock: Scroll, Master, OR "Destroy a door/barrier in combat"*

### TIER 2
**PULVERIZE** | 2 AP | 5 Stamina
Attack at +4 damage. If target already damaged this combat, +6 instead.
*Unlock: T2 Scroll, Master, OR "Deal 30+ damage to single enemy in one combat"*

**GROUND SLAM** | 2 AP | 4 Stamina
Hit ground. All within 2m: MIG mod damage, AGI save or prone.
*Unlock: T2 Scroll, Master, OR "Knock 3 enemies prone in one combat"*

**ARMOR BREAKER** | Passive | —
Your attacks reduce target's armor by 1 for the combat (stacks to -3).
*Unlock: T2 Scroll, Master, OR "Fight enemy with 6+ armor"*

### TIER 3
**THUNDEROUS IMPACT** | 3 AP | 7 Stamina
Attack at +8 damage. On hit, target pushed 4m and all adjacent to impact point take MIG mod damage.
*Unlock: T3 Scroll, Master, OR "Push enemy into hazard/wall for damage"*

**BONE SHATTER** | 2 AP | 6 Stamina
Called shot to limb at -2. On hit, limb disabled (arm: can't use, leg: speed halved) until healed.
*Unlock: T3 Scroll, Master, OR "Cripple 2 enemies in different combats"*

---

## Variant A: BREAKER
*Modifier: +2 vs. armored targets (4+ armor), -1 vs. unarmored*

**Unique Techniques:**
- T1 **DENT ARMOR:** 1 AP, 2 Stam. On hit, -1 armor to target permanently.
- T2 **CRUSH THROUGH:** 2 AP, 5 Stam. Attack ignores all armor.
- T3 **SHATTER EQUIPMENT:** 2 AP, 6 Stam. On hit, destroy one piece of target's equipment (their choice).
- T4 **UNSTOPPABLE FORCE:** Passive. Ignore all damage reduction and armor. Deal double damage to objects.

## Variant B: STUNNER
*Modifier: All hits require FOR save or -1 to next roll, +1 Stamina cost*

**Unique Techniques:**
- T1 **RINGING BLOW:** 1 AP, 3 Stam. On hit, target can't take reactions until end of their turn.
- T2 **CONCUSSIVE STRIKE:** 2 AP, 5 Stam. On hit, WIL save or Stunned (lose next action).
- T3 **BRAIN RATTLER:** 2 AP, 6 Stam. On hit, INT/WIS-based abilities fail for 2 rounds.
- T4 **MIND BREAKER:** Passive. Enemies you Stun take +50% damage. Stun duration +1 round.

## Variant C: TITAN
*Modifier: +1 damage per 10 HP you're missing, takes double Stamina below 50% HP*

**Unique Techniques:**
- T1 **DESPERATE SMASH:** 1 AP, 2 Stam. +1 damage per 5 HP missing (max +10).
- T2 **BLOODIED FURY:** Passive. Below 50% HP: +2 to hit, +2 damage.
- T3 **LAST STAND SLAM:** 3 AP, 8 Stam. Only usable below 25% HP. Attack all adjacent at +10 damage.
- T4 **AVATAR OF RUIN:** Passive. Cannot die from damage while attacking. Die at end of turn if 0 HP.

---

# FORM 3: POLEARM

**Default Attribute:** MIG (or AGI for light polearms)
**Weapons:** Spear, Halberd, Pike, Glaive, Naginata

## Base Techniques

### TIER 1
**LONG THRUST** | 1 AP | 2 Stamina
Attack at 3m range (instead of melee). +1 damage.
*Unlock: Starting OR scroll*

**DEFENSIVE REACH** | Passive | —
Enemies entering your reach provoke opportunity attacks.
*Unlock: Scroll, Master, OR "Make 3 opportunity attacks in one combat"*

**SWEEPING SHAFT** | 1 AP | 2 Stamina
Hit with shaft. 1d6 damage, target AGI save or prone.
*Unlock: Scroll, Master, OR "Knock enemy prone"*

### TIER 2
**IMPALE** | 2 AP | 4 Stamina
Attack at +2. On crit, target is impaled (your weapon stuck, they take 1d6 at start of each turn, MIG check to remove).
*Unlock: T2 Scroll, Master, OR "Crit with polearm"*

**BRACE FOR CHARGE** | Reaction (Special) | 3 Stamina
Declare at start of enemy turn. If enemy moves toward you, free attack at +4 damage.
*Unlock: T2 Scroll, Master, OR "Hit charging enemy"*

**POLEARM MASTERY** | Passive | —
+1 to hit and damage with all polearms. Can attack adjacent despite reach.
*Unlock: T2 Scroll, Master, OR "Use polearm for 10 combats"*

### TIER 3
**SKEWERING THRUST** | 2 AP | 6 Stamina
Attack all enemies in a 6m line. Single roll vs. each.
*Unlock: T3 Scroll, Master, OR "Hit 3 enemies with polearms in one combat"*

**WHIRLWIND SWEEP** | 3 AP | 7 Stamina
Attack all enemies within 3m. On hit, pushed 2m away.
*Unlock: T3 Scroll, Master, OR "Fight while surrounded (3+ enemies adjacent)"*

---

## Variant A: LANCER
*Modifier: +2 damage on first attack each combat, -1 damage after*

**Unique Techniques:**
- T1 **OPENING THRUST:** 1 AP, 2 Stam. First attack of combat at +4 damage, +2 to hit.
- T2 **CAVALRY CHARGE:** 2 AP, 4 Stam. Move up to speed, attack at end at +6 damage.
- T3 **DEVASTATING CHARGE:** 3 AP, 7 Stam. Move double speed in line, attack all in path at +8 damage.
- T4 **FIRST BLOOD:** Passive. First attack each combat auto-crits. +50% damage vs. uninjured targets.

## Variant B: HOPLITE
*Modifier: +1 DEF while not moving, -1 DEF if you moved this turn*

**Unique Techniques:**
- T1 **HOLD THE LINE:** 1 AP, 1 Stam. +2 DEF until you move. Ends if you move.
- T2 **PHALANX POSITION:** Passive. Adjacent allies with polearms/shields: all gain +1 DEF.
- T3 **WALL OF SPEARS:** 2 AP, 5 Stam. Until next turn, enemies can't enter your reach without AGI save.
- T4 **IMMOVABLE GUARDIAN:** Passive. Can't be moved or prone while holding polearm. +3 DEF vs. charges.

## Variant C: REAPER
*Modifier: +1 damage vs. multiple targets, -1 vs. single target*

**Unique Techniques:**
- T1 **SCYTHING SWEEP:** 2 AP, 3 Stam. Attack two adjacent enemies.
- T2 **HARVEST:** 2 AP, 4 Stam. Attack all enemies in 180° arc. -2 damage each.
- T3 **DEATH'S REACH:** 3 AP, 6 Stam. All enemies in 3m: attack at full damage.
- T4 **REAPER'S CIRCLE:** Passive. Wide attacks +2 damage per enemy hit. Max 3 targets becomes 5.

---

# FORM 4: AXE

**Default Attribute:** MIG
**Weapons:** Battleaxe, Greataxe, Handaxe, Dane Axe, Tomahawk

## Base Techniques

### TIER 1
**HACKING BLOW** | 1 AP | 2 Stamina
Attack at +2 damage. On 11-12, target bleeds (2 damage/round, 3 rounds).
*Unlock: Starting OR scroll*

**RENDING STRIKE** | 1 AP | 3 Stamina
Attack. On hit, target bleeds (3 damage/round, 2 rounds, stacks).
*Unlock: Scroll, Master, OR "Apply bleed 3 times"*

**CHOP** | 1 AP | 2 Stamina
Attack at +1. Double damage to objects, +4 vs. wooden objects/creatures.
*Unlock: Scroll, Master, OR "Destroy object with axe"*

### TIER 2
**SAVAGE CLEAVE** | 2 AP | 4 Stamina
Attack. If it kills, free attack vs. adjacent at +2 damage.
*Unlock: T2 Scroll, Master, OR "Kill with axe attack"*

**HAMSTRING CHOP** | 2 AP | 4 Stamina
Attack legs at -1. On hit, half movement until healed or rested.
*Unlock: T2 Scroll, Master, OR "Cripple enemy's movement"*

**BERSERKER SPIRIT** | Passive | —
+1 damage for each enemy you've damaged this combat (max +3).
*Unlock: T2 Scroll, Master, OR "Damage 4 different enemies in one combat"*

### TIER 3
**DECAPITATING SWING** | 3 AP | 7 Stamina
Attack enemy below 25% HP. On hit, FOR save or instant death (creatures immune: just +50% damage).
*Unlock: T3 Scroll, Master, OR "Kill enemy with critical hit"*

**WHIRLWIND AXE** | 3 AP | 6 Stamina
Spin attack. All within melee range take weapon damage. You are dizzy (-2 DEF) for 1 round.
*Unlock: T3 Scroll, Master, OR "Hit 4+ enemies with axes total"*

---

## Variant A: RAIDER
*Modifier: +2 damage on first hit per enemy, -1 on subsequent hits to same enemy*

**Unique Techniques:**
- T1 **OPENING HACK:** 1 AP, 2 Stam. +4 damage vs. enemy you haven't hit yet.
- T2 **TERRIFYING CHARGE:** 2 AP, 4 Stam. Charge + attack. Target WIL save or Frightened.
- T3 **RAMPAGE:** 3 AP, 6 Stam. Attack 3 different enemies. +2 damage each.
- T4 **DEATH DEALER:** Passive. First hit each enemy: auto-bleed. Killing blow: +5 temp HP.

## Variant B: WOODSMAN
*Modifier: +2 damage vs. larger creatures/objects, -1 vs. smaller*

**Unique Techniques:**
- T1 **TIMBER STRIKE:** 1 AP, 2 Stam. +4 damage vs. creatures larger than you.
- T2 **MIGHTY CHOP:** 2 AP, 5 Stam. +8 damage vs. objects and constructs.
- T3 **FELL THE GIANT:** 3 AP, 7 Stam. Attack large+ creature. On hit, AGI save or prone.
- T4 **GIANT KILLER:** Passive. +50% damage vs. creatures 2+ sizes larger. They can't crit you.

## Variant C: DUAL AXE
*Modifier: Can dual wield handaxes, -1 damage per axe, +1 attack per turn*

**Unique Techniques:**
- T1 **TWIN CHOP:** 1 AP, 3 Stam. Attack with both axes. Off-hand at -2.
- T2 **CROSSING AXES:** 2 AP, 4 Stam. Attack with both, same target. +4 damage if both hit.
- T3 **BUZZSAW:** 3 AP, 6 Stam. Spin with both axes. All adjacent take damage from each axe.
- T4 **WHIRLING DEATH:** Passive. Off-hand penalty removed. On kill, free off-hand attack.

---

# FORM 5: MEDIUM BLADE

**Default Attribute:** MIG (or AGI via Flowing Steel)
**Weapons:** Longsword, Katana, Saber, Bastard Sword

## Base Techniques

### TIER 1
**MEASURED THRUST** | 1 AP | 2 Stamina
+2 to hit. Cannot crit but cannot miss by more than 2.
*Unlock: Starting OR scroll*

**DEFENSIVE SLASH** | 1 AP | 2 Stamina
Attack. Gain +2 DEF until start of next turn.
*Unlock: Scroll, Master, OR "Successfully defend 3 times in combat"*

**DISARMING CUT** | 1 AP | 3 Stamina
-2 to hit. On hit, MIG save or target drops weapon.
*Unlock: Scroll, Master, OR "Witness disarm"*

### TIER 2
**RIPOSTE** | Reaction | 2 Stamina
When enemy misses melee, attack at +2.
*Unlock: T2 Scroll, Master, OR "Dodge 5 attacks in one combat"*

**VERSATILE TECHNIQUE** | Passive | —
Two-handed: +2 damage. One-handed with shield: +1 DEF.
*Unlock: T2 Scroll, Master, OR "Use both grips in one combat"*

**FEINT** | 1 AP | 2 Stamina
Target -4 DEF vs. your next attack this turn. If it hits, +2 damage.
*Unlock: T2 Scroll, Master, OR "Hit enemy with 6+ DEF"*

### TIER 3
**BLADE DANCE** | 3 AP | 6 Stamina
Make 3 attacks at -1 each. Can split between targets.
*Unlock: T3 Scroll, Master, OR "Hit 3 times in one turn"*

**PRECISION COUNTER** | Reaction | 4 Stamina
When enemy attacks ally in reach, attack. If you deal more damage than they would, their attack misses.
*Unlock: T3 Scroll, Master, OR "Protect ally from damage"*

---

## Variant A: DUELIST
*Modifier: +1 to hit vs. single enemy in reach, -1 if 2+ enemies in reach*

**Unique Techniques:**
- T1 **SINGLE COMBAT:** 1 AP, 2 Stam. Challenge one enemy. +2 to hit them, -2 vs. others.
- T2 **PARRY AND THRUST:** Reaction, 3 Stam. When attacked, roll AGI vs attack. Beat it: negate and counterattack.
- T3 **PERFECT RIPOSTE:** Passive. Riposte deals +4 damage and auto-crits if enemy missed by 4+.
- T4 **MASTER DUELIST:** Passive. 1v1: +3 to all rolls. Can parry any attack (even ranged) once/round.

## Variant B: KNIGHT
*Modifier: +1 DEF while in Defensive stance, -1 DEF in other stances*

**Unique Techniques:**
- T1 **GUARDIAN'S STRIKE:** 1 AP, 2 Stam. Attack. Adjacent ally gains +2 DEF for 1 round.
- T2 **SHIELD OF BLADES:** 2 AP, 4 Stam. Until next turn, block attacks on adjacent allies (you take the hit).
- T3 **CHIVALRIC CHALLENGE:** 2 AP, 4 Stam. Target must attack only you for 3 rounds (WIL save each turn).
- T4 **STALWART DEFENDER:** Passive. When ally in reach hit, you may take half the damage. +2 DEF.

## Variant C: IAIJUTSU
*Modifier: +3 damage from sheathed, must sheathe after each attack*

**Unique Techniques:**
- T1 **QUICK DRAW:** 1 AP, 1 Stam. Draw and attack. +2 damage.
- T2 **FLASH BLADE:** 1 AP, 3 Stam. Draw, attack, sheathe. +4 damage, target doesn't know they're hit until turn ends.
- T3 **FOUR WINDS CUT:** 2 AP, 6 Stam. Draw. Attack all adjacent. Sheathe. They don't realize until you sheathe.
- T4 **PERFECT DRAW:** Passive. First attack from sheathed: auto-crit. Can draw/sheathe as free actions.

---

# FORM 6: MEDIUM CRUSH

**Default Attribute:** MIG
**Weapons:** Mace, Morningstar, Flail, War Pick

## Base Techniques

### TIER 1
**SMASH** | 1 AP | 2 Stamina
Attack at +1 damage. Ignores 1 armor.
*Unlock: Starting OR scroll*

**SHIELD BREAKER** | 1 AP | 3 Stamina
Attack at -1. On hit, shield provides half bonus until repaired.
*Unlock: Scroll, Master, OR "Hit enemy with shield"*

**HOBBLING STRIKE** | 1 AP | 2 Stamina
Attack legs. On hit, -2m movement for 2 rounds.
*Unlock: Scroll, Master, OR "Reduce enemy movement"*

### TIER 2
**CHAIN WRAP** | 2 AP | 4 Stamina (Flail only)
Attack. On hit, target grappled by weapon. They can escape (MIG vs MIG) or you can release.
*Unlock: T2 Scroll, Master, OR "Grapple enemy"*

**SHIELD BASH** | 1 AP | 2 Stamina (With shield)
Hit with shield. 1d6 + FOR damage, push 2m.
*Unlock: T2 Scroll, Master, OR "Push enemy"*

**ARMOR DENT** | Passive | —
Each hit reduces target armor by 1 (stacks to -3, resets after combat).
*Unlock: T2 Scroll, Master, OR "Fight armored enemy"*

### TIER 3
**METEOR STRIKE** | 3 AP | 7 Stamina
Jump and bring weapon down. +8 damage, AGI save or prone and Dazed.
*Unlock: T3 Scroll, Master, OR "Deal 25+ damage in one hit"*

**FLURRY OF BLOWS** | 3 AP | 6 Stamina
Make 4 attacks at -2 each.
*Unlock: T3 Scroll, Master, OR "Hit same enemy 3 times in one turn"*

---

## Variant A: TEMPLAR
*Modifier: +2 damage vs. unholy/undead, -1 vs. living*

**Unique Techniques:**
- T1 **HOLY SMITE:** 1 AP, 3 Stam. Attack deals radiant damage. +4 vs. undead.
- T2 **BANISHING BLOW:** 2 AP, 5 Stam. On hit, undead/fiend: WIL save or destroyed (if HP < your level × 3).
- T3 **DIVINE WRATH:** 3 AP, 7 Stam. All undead in 5m: 4d6 radiant, WIL save half.
- T4 **HOLY WARRIOR:** Passive. Immune to fear, disease, poison. Mace deals radiant. Undead can't regenerate.

## Variant B: GLADIATOR
*Modifier: +1 to hit per spectator (max +3), no bonus if alone*

**Unique Techniques:**
- T1 **CROWD PLEASER:** 1 AP, 2 Stam. Flashy attack. +2 damage if allies watching.
- T2 **SHOWSTOPPER:** 2 AP, 4 Stam. Dramatic strike. On kill, all allies +2 to next roll.
- T3 **CHAMPION'S BLOW:** 3 AP, 6 Stam. Attack at +6 damage. All witnesses (friend/foe) must WIL save or be impressed.
- T4 **LEGENDARY GLADIATOR:** Passive. Can't be surprised if anyone watching. Killing blow: recover 10 HP.

## Variant C: SKULLCRUSHER
*Modifier: +2 to Daze/Stun effects, all techniques +1 Stamina cost*

**Unique Techniques:**
- T1 **RATTLING HIT:** 1 AP, 3 Stam. On hit, WIL save or Dazed 1 round.
- T2 **MIND BREAKER:** 2 AP, 5 Stam. On hit, INT/WIS save or confused (random action) 1 round.
- T3 **CONCUSSION WAVE:** 3 AP, 7 Stam. 3m radius. All: FOR save or Stunned 1 round.
- T4 **BRAIN SMASHER:** Passive. Stuns you cause last +1 round. Stunned enemies take +50% damage.

---

[Continuing with Forms 7-20...]

# FORM 7: LIGHT BLADE

**Default Attribute:** AGI
**Weapons:** Dagger, Shortsword, Kukri, Tanto

## Base Techniques

### TIER 1
**QUICK STRIKE** | 1 AP | 1 Stamina
+2 to hit, -2 damage.
*Unlock: Starting OR scroll*

**OPPORTUNISTIC STAB** | Passive | —
+3 damage vs. enemies who haven't acted this combat.
*Unlock: Scroll, Master, OR "Attack before enemy acts"*

**SLIP AWAY** | 1 AP | 2 Stamina
Attack then move 3m without provoking.
*Unlock: Scroll, Master, OR "Escape melee without being hit"*

### TIER 2
**FLURRY** | 2 AP | 4 Stamina
Two attacks vs. same target at -2 damage each.
*Unlock: T2 Scroll, Master, OR "Hit twice in one turn"*

**HAMSTRING** | 1 AP | 3 Stamina
-2 to hit. On hit, speed halved until end of their next turn.
*Unlock: T2 Scroll, Master, OR "Prevent enemy from escaping"*

**EXPLOIT OPENING** | Reaction | 2 Stamina
When ally hits enemy in reach, attack at +2.
*Unlock: T2 Scroll, Master, OR "Fight alongside ally"*

### TIER 3
**DEATH OF A THOUSAND CUTS** | 3 AP | 5 Stamina
Four attacks, any targets in reach. Damage without stat mod.
*Unlock: T3 Scroll, Master, OR "Hit 4 times total with light blade"*

**VITAL STRIKE** | 2 AP | 4 Stamina
Auto-targets vitals (no called shot penalty). +50% damage, +100% on crit.
*Unlock: T3 Scroll, Master, OR "Land 5 critical hits with light blade"*

---

## Variant A: ASSASSIN
*Modifier: +3 damage from stealth/surprise, -1 damage otherwise*

**Unique Techniques:**
- T1 **SILENT KILL:** 1 AP, 2 Stam. From stealth: attack at +4 damage. No sound on kill.
- T2 **POISON BLADE:** 1 AP, 3 Stam. Apply poison to blade. Next 3 hits: +2d6 poison damage.
- T3 **DEATH STRIKE:** 2 AP, 6 Stam. From stealth vs. unaware: triple damage.
- T4 **PERFECT ASSASSIN:** Passive. Kills don't break stealth. Auto-crit from stealth.

## Variant B: BRAWLER
*Modifier: Can attack as part of grapple, -1 to non-grapple attacks*

**Unique Techniques:**
- T1 **SHANK:** 1 AP, 1 Stam. Attack while grappling at +2. Doesn't break grapple.
- T2 **HOLD AND STAB:** 2 AP, 4 Stam. Grapple + attack in one action.
- T3 **GUTTING:** 2 AP, 5 Stam. While grappling: attack that auto-crits if they fail escape.
- T4 **CLOSE-QUARTERS MASTER:** Passive. Grappled enemies can't attack you. +4 damage while grappling.

## Variant C: THROWN SPECIALIST
*Modifier: Light blades can be thrown (10m), -1 damage melee*

**Unique Techniques:**
- T1 **QUICK THROW:** 1 AP, 1 Stam. Throw dagger at +2 to hit within 10m.
- T2 **FAN OF KNIVES:** 2 AP, 4 Stam. Throw 3 daggers at different targets.
- T3 **RETURNING BLADE:** Passive. Thrown blades return to hand (magical or skill).
- T4 **BLADE STORM:** 3 AP, 7 Stam. Throw at all enemies you can see. Auto-return after.

---

# FORM 8: FINESSE BLADE

**Default Attribute:** AGI (or PRC via Surgical Precision)
**Weapons:** Rapier, Estoc, Smallsword, Épée

## Base Techniques

### TIER 1
**PRECISE THRUST** | 1 AP | 2 Stamina
+2 to hit. If you beat DEF by 4+, +3 damage.
*Unlock: Starting OR scroll*

**EN GARDE** | 0 AP | 1 Stamina
Defensive stance specific to rapier. +2 DEF until you attack.
*Unlock: Scroll, Master, OR "Avoid 3 attacks in one combat"*

**LUNGE** | 1 AP | 2 Stamina
Attack at +2m reach, +2 damage. -2 DEF until next turn.
*Unlock: Scroll, Master, OR "Attack enemy just out of reach"*

### TIER 2
**PARRY** | Reaction | 2 Stamina
Roll AGI vs attack roll. Beat: attack negated.
*Unlock: T2 Scroll, Master, OR "Successfully dodge 3 times in one combat"*

**RIPOSTE** | Reaction (after Parry) | 1 Stamina
If Parry succeeds, free attack at +2.
*Unlock: T2 Scroll, Master, OR "Parry twice in one combat"*

**BINDING BLADE** | 1 AP | 3 Stamina
Lock blades. Target can't attack others until they pass MIG/AGI check to break.
*Unlock: T2 Scroll, Master, OR "Fight enemy with sword"*

### TIER 3
**FLÈCHE** | 2 AP | 5 Stamina
Charge up to speed, attack at +4 damage, continue 2m past.
*Unlock: T3 Scroll, Master, OR "Kill enemy with single thrust"*

**WHIRLWIND RIPOSTE** | Reaction | 5 Stamina
When enemy misses, attack them AND another enemy in reach.
*Unlock: T3 Scroll, Master, OR "Riposte 5 times total"*

---

## Variant A: COURT SWORD
*Modifier: +1 to Persuasion/Intimidation while drawn, -1 damage*

**Unique Techniques:**
- T1 **FLOURISH:** 0 AP, 1 Stam. Impressive display. +2 to social rolls this scene.
- T2 **FIRST BLOOD:** 1 AP, 2 Stam. In formal duel: first hit wins. Attack at +2.
- T3 **NOBLE'S CHALLENGE:** 2 AP, 4 Stam. Challenge enemy to duel. If they refuse, allies +2 vs them.
- T4 **LEGENDARY DUELIST:** Passive. In 1v1: +4 to all rolls. Fame: enemies may refuse to fight.

## Variant B: MAIN GAUCHE (Off-hand dagger)
*Modifier: +1 DEF, requires off-hand dagger, -1 damage without*

**Unique Techniques:**
- T1 **TRAP BLADE:** Reaction, 2 Stam. Catch enemy blade with dagger. -2 their next attack.
- T2 **DOUBLE PARRY:** Reaction, 3 Stam. Parry with dagger AND sword (two separate attempts).
- T3 **RIPOSTE COMBO:** Reaction, 4 Stam. After parry: attack with both rapier and dagger.
- T4 **TWIN BLADE MASTER:** Passive. Parry costs no Stamina. Off-hand dagger adds +2 to parry.

## Variant C: SPORTING
*Modifier: +1 to hit unarmored, -2 vs heavily armored (5+ DEF from armor)*

**Unique Techniques:**
- T1 **TARGET PRACTICE:** 1 AP, 2 Stam. +4 to hit vs. unarmored targets.
- T2 **FIND THE GAP:** 2 AP, 4 Stam. Attack ignores armor if you beat DEF by 4+.
- T3 **PERFECT STRIKE:** 2 AP, 5 Stam. Attack at +4 to hit. On hit, max damage.
- T4 **SURGICAL PRECISION:** Passive. Called shots at no penalty. Crits ignore armor entirely.

---

# FORMS 9-12: RANGED

[Similar detailed structure for Longbow, Shortbow, Crossbow, Thrown - each with 8 base techniques and 3 variants with 4 unique techniques each]

# FORMS 13-16: DEFENSIVE/SPECIAL

[Similar detailed structure for Shield, Dual Wield, Unarmed Strike, Grappling - each with 8 base techniques and 3 variants]

# FORMS 17-20: COMBAT STYLES

[Similar detailed structure for Defensive Arts, Aggressive Arts, Mounted Combat, Environmental Combat - each with 8 base techniques and 3 variants]

---

## FORM SUMMARY TABLE

| # | Form | Attr | Aspect Affinity | Archetype Affinity |
|---|------|------|-----------------|-------------------|
| 1 | Heavy Blade | MIG | Pyre | Striker |
| 2 | Heavy Crush | MIG | Ore | Striker |
| 3 | Polearm | MIG | Ore, Radiance | Guardian, Warden |
| 4 | Axe | MIG | Pyre | Striker |
| 5 | Medium Blade | MIG/AGI | Radiance | Any |
| 6 | Medium Crush | MIG | Ore | Guardian |
| 7 | Light Blade | AGI | Shroud, Gale | Skirmisher |
| 8 | Finesse Blade | AGI/PRC | Tide, Radiance | Skirmisher |
| 9 | Longbow | PRC | Gale | Hunter |
| 10 | Shortbow | AGI/PRC | Gale, Anima | Hunter, Skirmisher |
| 11 | Crossbow | PRC/INT | Aether | Hunter, Analyst |
| 12 | Thrown | AGI | Gale, Tide | Hunter, Skirmisher |
| 13 | Shield | FOR | Ore, Radiance | Guardian |
| 14 | Dual Wield | AGI | Shroud, Gale | Skirmisher |
| 15 | Unarmed Strike | MIG/AGI | Anima, Pyre | Striker |
| 16 | Grappling | MIG/FOR | Anima, Tide | Any |
| 17 | Defensive Arts | FOR/AGI | Ore, Radiance | Guardian |
| 18 | Aggressive Arts | MIG/WIL | Pyre, Shroud | Striker |
| 19 | Mounted Combat | MIG/AGI | Anima, Gale | Any |
| 20 | Environmental | WIS/INT | Anima, Aether | Warden, Analyst |

---

## TECHNIQUE COUNT

- 20 Forms × 8 Base Techniques = 160 Base Techniques
- 20 Forms × 3 Variants × 4 Unique = 240 Variant Techniques
- **Total Combat Techniques: 400**

Each form fully detailed in supplementary files:
- forms-combat-ranged.md (Forms 9-12)
- forms-combat-defensive.md (Forms 13-16)
- forms-combat-styles.md (Forms 17-20)
