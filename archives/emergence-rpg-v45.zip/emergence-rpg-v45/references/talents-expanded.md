# Talents (Expanded)

~400 talents organized into General, Archetype, and Aspect pools.

---

## Talent Acquisition

- **Level 1:** No talents
- **Level 2+:** +1 talent per level
- **Level 30:** 29 talents total

## Pool Access

| Pool | Access | Count |
|------|--------|-------|
| General | Everyone | 100 |
| Archetype | Matching only | 20 each × 8 = 160 |
| Aspect | Matching only | 18 each × 8 = 144 |
| **Total** | | **~404** |

A character accesses: General (100) + Archetype (20) + Aspect (18) = **138 options**
They take 29 over career = significant choice space.

---

## Power Budget Reference

| Tier | Prerequisites | Combat Value | eHP | DPR |
|------|---------------|--------------|-----|-----|
| 1 | None / Attr 10+ (Open Proficiency) | Minor | +5-10 | +0.5-1.0 |
| 2 | T1 + Lv5+ OR Attr 14+ (Standard Prof) | Moderate | +10-20 | +1.0-2.0 |
| 3 | T2 + Lv10+ OR Attr 18+ (Mastery Prof) | Strong | +20-35 | +2.0-4.0 |
| 4 | T3 + Lv15+ | Defining | +35-60 | +4.0-8.0 |

---

# GENERAL POOL (100 Talents)

Available to all characters.

---

## Survivability Tree (16 talents)

### TOUGH (T1)
+8 maximum HP.

### TOUGHER (T2)
*Prereq: Tough, FOR 12+ or Lv5+*
+20 HP total. +2 saves vs poison/disease.

### UNKILLABLE (T3)
*Prereq: Tougher, FOR 16+ or Lv10+*
+35 HP total. Once/rest, 0 HP → 1 HP instead.

### DEATHLESS (T4)
*Prereq: Unkillable, Lv15+*
+50 HP total. Once/rest, would die → stabilize at 1 HP, skip 1 round.

### QUICK (T1)
+1 initiative, +1m movement.

### LIGHTNING REFLEXES (T2)
*Prereq: Quick, AGI 12+ or Lv5+*
+3 initiative total, +2m movement total, can't be surprised.

### UNCATCHABLE (T3)
*Prereq: Lightning Reflexes, AGI 16+ or Lv10+*
+5 initiative total, +4m movement total. Once/combat, move full speed as reaction when targeted.

### GHOST (T4)
*Prereq: Uncatchable, Lv15+*
Double movement speed. Can move through enemies. Once/combat, become untargetable for 1 round.

### RESILIENT (T1)
+1 all saves.

### IRON WILL (T2)
*Prereq: Resilient, WIL 12+ or Lv5+*
+2 all saves total. Advantage vs fear/charm.

### UNBREAKABLE SPIRIT (T3)
*Prereq: Iron Will, WIL 16+ or Lv10+*
+3 all saves total. Immune to fear. Once/rest, auto-succeed mental save.

### INDOMITABLE (T4)
*Prereq: Unbreakable Spirit, Lv15+*
+4 all saves total. Immune to charm. Once/rest, negate any condition affecting you.

### THICK SKIN (T1)
Reduce all physical damage by 1.

### ARMOR SKIN (T2)
*Prereq: Thick Skin, FOR 12+ or Lv5+*
Reduce all physical damage by 2 total.

### IRON BODY (T3)
*Prereq: Armor Skin, FOR 16+ or Lv10+*
Reduce all physical damage by 3 total. Immune to bleed.

### ADAMANTINE BODY (T4)
*Prereq: Iron Body, Lv15+*
Reduce ALL damage by 3. Immune to crit extra damage.

---

## Combat Fundamentals Tree (20 talents)

### WEAPON FOCUS (T1)
Choose category (Heavy/Medium/Light/Ranged/Unarmed). +1 attack.

### WEAPON SPECIALIZATION (T2)
*Prereq: Weapon Focus, relevant attr 12+ or Lv5+*
+2 attack, +2 damage with chosen category.

### WEAPON MASTERY (T3)
*Prereq: Weapon Specialization, relevant attr 16+ or Lv10+*
+3 attack, +4 damage. Crits deal +50% extra.

### WEAPON LEGEND (T4)
*Prereq: Weapon Mastery, Lv15+*
+4 attack, +6 damage. Once/combat, treat any roll as natural 12.

### DEFENSIVE STANCE MASTERY (T1)
Defensive stance: +1 additional DEF (total +5).

### AGGRESSIVE STANCE MASTERY (T1)
Aggressive stance: +1 additional damage (total +3).

### MOBILE STANCE MASTERY (T1)
Mobile stance: +2m additional movement (total +6m).

### FOCUSED STANCE MASTERY (T1)
Focused stance: advantage also applies to damage.

### STANCE DANCER (T2)
*Prereq: Two stance masteries, Lv5+*
Change stance as free action anytime. Can change twice/turn.

### STANCE MASTER (T3)
*Prereq: Stance Dancer, Lv10+*
Gain +1 benefit from every stance simultaneously.

### PERFECT STANCE (T4)
*Prereq: Stance Master, Lv15+*
All stance benefits active simultaneously. Can adopt unique "Perfect" stance: +2 all rolls.

### OPPORTUNITY STRIKER (T1)
Opportunity attacks: +3 damage.

### SENTINEL (T2)
*Prereq: Opportunity Striker, MIG 12+ or Lv5+*
Opportunity attacks: +5 damage, hit stops target's movement.

### THREATENING REACH (T3)
*Prereq: Sentinel, MIG 16+ or Lv10+*
+2m opportunity attack range. Enemies starting in reach provoke if they attack others.

### ZONE OF DEATH (T4)
*Prereq: Threatening Reach, Lv15+*
Unlimited opportunity attacks per round. Enemies in reach: -2 to all rolls.

### CRITICAL FOCUS (T1)
+1 to crit confirmation rolls. Crit range expanded by 1 on natural 11.

### IMPROVED CRITICAL (T2)
*Prereq: Critical Focus, PRC 12+ or Lv5+*
Crit range expanded by 1 (10-12 crits).

### DEVASTATING CRITICAL (T3)
*Prereq: Improved Critical, PRC 16+ or Lv10+*
Crits deal +100% instead of +50%.

### OVERWHELMING CRITICAL (T4)
*Prereq: Devastating Critical, Lv15+*
Crits: +100% damage, target FOR save or Stunned 1 round.

---

## Resource Management Tree (12 talents)

### ENDURING (T1)
+10 maximum Stamina.

### TIRELESS (T2)
*Prereq: Enduring, FOR 12+ or Lv5+*
+25 Stamina total. Once/rest, recover FOR×3 Stamina as free action.

### INEXHAUSTIBLE (T3)
*Prereq: Tireless, FOR 16+ or Lv10+*
+40 Stamina total. All Stamina costs -1 (min 1).

### DEEP RESERVES (T1)
+10 maximum Mana.

### EFFICIENT CHANNELING (T2)
*Prereq: Deep Reserves, INT/WIL 12+ or Lv5+*
+25 Mana total. Once/rest, recover INT/WIL×3 Mana as free action.

### ARCANE WELLSPRING (T3)
*Prereq: Efficient Channeling, INT/WIL 16+ or Lv10+*
+40 Mana total. All Mana costs -1 (min 1).

### SECOND WIND (T1)
Once/combat, 1 AP: recover FOR×2 HP.

### RALLYING RECOVERY (T2)
*Prereq: Second Wind, FOR 12+ or Lv5+*
Second Wind: FOR×3 HP, allies within 5m half that.

### PHOENIX SURGE (T3)
*Prereq: Rallying Recovery, FOR 16+ or Lv10+*
Second Wind: FOR×4 HP, removes one condition. Free action below 25% HP.

### COMBAT MEDITATION (T2)
*Prereq: Any T1 resource talent, WIS 12+ or Lv5+*
1 AP: recover 5 Stamina OR 5 Mana. Once/combat.

### EFFICIENT COMBAT (T3)
*Prereq: Combat Meditation, Lv10+*
First technique each combat costs no resources.

### PERFECT EFFICIENCY (T4)
*Prereq: Efficient Combat + Inexhaustible or Arcane Wellspring, Lv15+*
All resource costs halved (round up).

---

## Utility Tree (16 talents)

### KEEN SENSES (T1)
+2 Perception. See in dim light.

### ALERTNESS (T2)
*Prereq: Keen Senses, WIS 12+ or Lv5+*
+4 Perception total. Can't be surprised. +2 initiative.

### PRETERNATURAL AWARENESS (T3)
*Prereq: Alertness, WIS 16+ or Lv10+*
+6 Perception total. Sense invisible/hidden in 10m. Once/rest, ask GM yes/no about threats.

### SILVER TONGUE (T1)
+2 Persuasion and Deception.

### DIPLOMAT (T2)
*Prereq: Silver Tongue, PRE 12+ or Lv5+*
+4 Persuasion/Deception total. Once/scene, reroll failed social.

### MASTER NEGOTIATOR (T3)
*Prereq: Diplomat, PRE 16+ or Lv10+*
+6 Persuasion/Deception total. NPCs start one disposition step friendlier. Attempt to persuade hostile.

### QUICK LEARNER (T1)
+10% XP gains.

### DEDICATED STUDENT (T2)
*Prereq: Quick Learner, INT 12+ or Lv5+*
+20% XP total. Techniques unlock 20% faster.

### PRODIGY (T3)
*Prereq: Dedicated Student, INT 16+ or Lv10+*
+30% XP total. Skills rank 25% faster. +1 Form slot.

### SCAVENGER (T1)
+1 loot rolls. 10% extra supplies when searching.

### RESOURCEFUL (T2)
*Prereq: Scavenger, WIS 12+ or Lv5+*
+2 loot rolls total. Consumables +25% effective. 20% don't consume single-use.

### MASTER SCROUNGER (T3)
*Prereq: Resourceful, WIS 16+ or Lv10+*
+3 loot rolls total. Skill Stone drop +1%. Always find food/water in wilderness.

### JACK OF ALL TRADES (T1)
+1 to all checks with skills you don't have proficiency in.

### POLYMATH (T2)
*Prereq: Jack of All Trades, INT 12+ or Lv5+*
+2 to all non-proficient checks. Once/rest, treat any check as if proficient.

### RENAISSANCE BEING (T3)
*Prereq: Polymath, INT 16+ or Lv10+*
Count as proficient in all skills at half your level.

### GRANDMASTER (T4)
*Prereq: Renaissance Being, Lv15+*
Proficient in everything. Once/day, treat any roll as natural 12.

---

## Attribute Proficiency Talents (20 talents)

Proficiency talents allow alternate attribute usage for weapons and magic. Three tiers exist with escalating requirements and power.

### Open Proficiency (Attr 10+) — Anyone can take these

**MARTIAL ARTS (T1)**
*Prereq: AGI 10+*
Unarmed attacks use AGI for attack roll.

**CAREFUL AIM (T1)**
*Prereq: WIS 10+*
Ranged attacks use WIS for attack roll.

**BRUTAL SWING (T1)**
*Prereq: MIG 10+*
Light melee uses MIG for damage roll.

### Standard Proficiency (Attr 14+) — Attack AND Damage

**SURGICAL PRECISION (T2)**
*Prereq: PRC 14+*
Light melee uses PRC for attack AND damage.

**FLOWING STEEL (T2)**
*Prereq: AGI 14+*
Medium melee uses AGI for attack AND damage.

**MEASURED STRIKE (T2)**
*Prereq: PRC 14+*
Medium melee uses PRC for attack AND damage.

**INSTINCTIVE ARCHER (T2)**
*Prereq: WIS 14+*
Bows use WIS for attack AND damage.

**WRESTLER'S GRIP (T2)**
*Prereq: FOR 14+*
Unarmed/grapple uses FOR for attack AND damage.

**POWER THROW (T2)**
*Prereq: MIG 14+*
Thrown uses MIG for attack AND damage.

### Mastery Proficiency (Attr 18+) — Build-Defining

**MIND OVER MATTER (T3)**
*Prereq: WIL 18+*
Any weapon may use WIL for attack roll.

**PERFECT FORM (T3)**
*Prereq: PRC 18+*
Once per combat, treat attack roll as 12.

**TRANSCENDENT TECHNIQUE (T3)**
*Prereq: Any physical 18+*
Advantage on all attacks with one chosen weapon type.

### Magic Proficiency (Alternate Attribute Talents)

**RAW CHANNELING (T2)**
*Prereq: WIL 14+, INT 12+*
Arcane spells may use WIL instead of INT.

**INTUITIVE MAGIC (T2)**
*Prereq: WIS 14+, INT 12+*
Arcane spells may use WIS instead of INT.

**DEVOTED FAITH (T2)**
*Prereq: PRE 14+, WIS 12+*
Divine spells may use PRE instead of WIS.

**IRON FAITH (T2)**
*Prereq: WIL 14+, WIS 12+*
Divine spells may use WIL instead of WIS.

**STUDIED NATURE (T2)**
*Prereq: INT 14+, WIS 12+*
Primal spells may use INT instead of WIS.

**ELEMENTAL BODY (T2)**
*Prereq: FOR 14+, WIS 12+*
Primal spells may use FOR instead of WIS.

**BLOOD PRICE (T2)**
*Prereq: FOR 14+, WIL 12+*
Blood magic may use FOR instead of WIL.

**CALCULATED SACRIFICE (T2)**
*Prereq: INT 14+, WIL 12+*
Blood magic may use INT instead of WIL.

**LOGIC MIND (T2)**
*Prereq: INT 14+, WIL 12+*
Psionic powers may use INT instead of WIL.

**EMPATHIC LINK (T2)**
*Prereq: WIS 14+, WIL 12+*
Psionic powers may use WIS instead of WIL.

---

## Defense Tree (8 talents)

### SHIELD BEARER (T1)
+1 DEF with shield.

### SHIELD EXPERT (T2)
*Prereq: Shield Bearer, FOR 12+ or Lv5+*
+2 DEF total with shield. Once/combat, reduce hit damage by shield bonus + 5.

### SHIELD MASTER (T3)
*Prereq: Shield Expert, FOR 16+ or Lv10+*
+3 DEF total with shield. Shield bash: bonus + FOR damage. Once/combat, negate one hit (shield may break).

### EVASIVE (T1)
+1 DEF when not wearing heavy armor.

### SLIPPERY (T2)
*Prereq: Evasive, AGI 12+ or Lv5+*
+2 DEF total unarmored. Once/round, Dodge: half damage from one attack.

### UNTOUCHABLE (T3)
*Prereq: Slippery, AGI 16+ or Lv10+*
+3 DEF total unarmored. AOE attacks deal half damage to you on failed saves.

### PARRY MASTER (T2)
*Prereq: Any defense T1, AGI 14+ or Lv5+*
Once/round, negate melee attack (AGI vs attack roll).

### PERFECT DEFENSE (T4)
*Prereq: Shield Master OR Untouchable, Lv15+*
Once/combat, become immune to all damage for 1 round.

---

## Teamwork Tree (8 talents)

### FLANKING BONUS (T1)
Flanking provides +2 to hit (instead of +1) and +2 damage.

### PACK TACTICS (T2)
*Prereq: Flanking Bonus, Lv5+*
+1 to hit for each ally adjacent to target (max +3).

### WOLF PACK (T3)
*Prereq: Pack Tactics, Lv10+*
When ally crits, you may make free attack vs same target.

### AID ANOTHER (T1)
Help action grants +3 (instead of +2).

### INSPIRING ALLY (T2)
*Prereq: Aid Another, PRE 12+ or Lv5+*
Help action grants +4 and 5 temp HP.

### PERFECT COORDINATION (T3)
*Prereq: Inspiring Ally, Lv10+*
Help is free action. Can help two allies/round.

### BODYGUARD (T1)
When adjacent ally hit, take half the damage.

### SHIELD WALL FORMATION (T2)
*Prereq: Bodyguard, FOR 12+ or Lv5+*
Adjacent allies with shields: all gain +2 DEF.

---

# ARCHETYPE POOLS (20 talents each)

---

## STRIKER POOL (20 talents)

### OVERWHELMING FORCE (T1)
+2 damage vs. full HP targets.

### MOMENTUM (T1)
Kill → next attack +3 to hit this turn.

### FINISHING BLOW (T1)
+3 damage vs. targets below 50% HP.

### FIRST STRIKE (T1)
+2 damage on your first attack each combat.

### DEVASTATING CHARGE (T2)
Move 4m+ before attack: +4 damage.

### CLEAVING STRIKES (T2)
Kill → free attack vs adjacent at -2.

### EXECUTION (T2)
+50% damage vs. targets below 25% HP.

### BRUTAL CRITICAL (T2)
Crits: +100% instead of +50%.

### RELENTLESS (T2)
+1 AP on turns you deal 20+ damage.

### BLOODLUST (T3)
Each kill: +1 AP next turn (max +2).

### UNRELENTING ASSAULT (T3)
Aggressive stance: 4 attacks/turn allowed.

### ANNIHILATOR (T3)
Once/combat, hit target below 25% HP: FOR save or instant death.

### AVATAR OF DESTRUCTION (T4)
Aggressive stance: +4 damage total, hits prevent healing, ignore 5 armor.

### MARKED FOR DEATH (T2)
Mark target. +4 damage vs marked. Mark shifts on kill.

### CULLING STRIKES (T3)
Attacks vs targets below 50% HP auto-crit.

### ENDLESS VIOLENCE (T3)
No maximum attacks per turn.

### DEATH DEALER (T4)
Killing blow: recover 10 HP, +1 AP immediately.

### BERSERKER FURY (T2)
Below 50% HP: +2 attack, +4 damage, -2 DEF.

### UNSTOPPABLE RAMPAGE (T3)
Below 25% HP: +4 attack, +8 damage, immune to fear/charm.

### GOD OF WAR (T4)
Once/rest, for 3 rounds: attacks can't miss, crits on 8+, immune to conditions.

---

## GUARDIAN POOL (20 talents)

### SHIELD WALL (T1)
Adjacent allies: +2 DEF while you hold shield.

### INTERCEPT (T1)
Ally within 3m attacked → move to them, become target.

### STURDY (T1)
+8 HP, +1 vs knockdown/movement.

### THREATENING PRESENCE (T1)
Adjacent enemies: -1 attack vs allies.

### FORTRESS STANCE (T2)
Defensive stance also grants +2 DEF to adjacent allies.

### CHAMPION'S GUARD (T2)
Intercept: no reaction cost, twice/round.

### ABSORB IMPACT (T2)
Once/combat, reduce damage by FOR×3.

### RALLY POINT (T2)
Allies starting adjacent: +1 all rolls that turn.

### INDOMITABLE BULWARK (T3)
Enemies can't move through your space. Shield Wall: +3 DEF.

### MARTYRDOM (T3)
Once/rest, ally within 10m would hit 0 HP → you take damage instead.

### UNBREAKABLE (T3)
Once/combat below 25% HP: +4 DEF, resist all damage, 1 round.

### LAST BASTION (T4)
While you have 1+ HP, allies within 5m can't drop below 1 HP. 0 HP: stand for WIL rounds.

### HOLD THE LINE (T2)
+2 DEF vs charges. Enemies can't push you.

### INSPIRING DEFENSE (T2)
When you block/parry, allies +2 to next roll.

### IRON CURTAIN (T3)
Attacks passing through your space: disadvantage.

### FORTRESS OF FLESH (T3)
Reduce all damage to allies within 5m by 2.

### IMMORTAL GUARDIAN (T4)
While defending ally: can't drop below 1 HP.

### TAUNT (T1)
1 AP: Target must attack you (WIL save).

### MASS TAUNT (T2)
Taunt affects all enemies in 5m.

### GUARDIAN AVATAR (T4)
All allies within 10m: +3 DEF, can't be crit.

---

## HUNTER POOL (20 talents)

### MARK PREY (T1)
Free action: mark visible enemy. +2 to hit marked.

### PATIENT SHOT (T1)
Don't move: +2 ranged attacks.

### EXPLOIT WEAKNESS (T1)
Attacks vs below 75% HP: ignore 2 armor.

### FAVORED ENEMY (T1)
Choose type. +2 damage vs that type.

### VULNERABILITY ANALYSIS (T2)
Mark → learn one vulnerability/resistance/ability.

### STEADY AIM (T2)
Aim action: +4 hit and +4 damage (instead of +2 hit).

### SURGICAL STRIKES (T2)
Ignore 4 armor vs below 75% HP. Called shots at -1.

### FAVORED TERRAIN (T2)
Choose terrain. +2 all rolls in that terrain.

### KILLSHOT (T3)
Aim then attack: natural 10+ auto-crits.

### HUNTER'S QUARRY (T3)
+50% damage vs marked. Kill marked → free mark another.

### DEATH FROM AFAR (T3)
No range penalties. Called shots at no penalty with ranged.

### APEX PREDATOR (T4)
Once/rest, Apex Quarry: auto-crit 9+, +100% damage, ignore all armor.

### TROPHY HUNTER (T2)
+4 damage vs creatures 3+ levels higher.

### GIANT SLAYER (T3)
+50% damage vs creatures 2+ sizes larger.

### PREPARED HUNTER (T2)
+2 to all rolls vs creatures you've fought before.

### NEMESIS (T3)
Choose one creature. +100% damage vs them. Know their location within 1 mile.

### PERFECT HUNTER (T4)
All attacks vs marked: advantage. Mark is permanent until target dies.

### AMBUSH PREDATOR (T1)
+4 damage from stealth/surprise.

### TRAP MASTER (T2)
Traps deal +50% damage, DC +2.

### ULTIMATE HUNTER (T4)
Choose creature type. Advantage on all rolls against them. They can't hide from you.

---

## SKIRMISHER POOL (20 talents)

### HIT AND RUN (T1)
After hit, move 2m without provoking.

### FLANKING EXPERT (T1)
+2 damage when flanking.

### NIMBLE (T1)
+2 DEF vs opportunity attacks, +1m speed.

### LIGHT FOOTED (T1)
Difficult terrain doesn't slow you.

### EVASIVE MANEUVERS (T2)
Once/round when missed, move 2m free.

### DUAL STRIKER (T2)
Off-hand deals full damage.

### AMBUSH EXPERT (T2)
+6 damage when flanking. +6 from stealth.

### MOBILE FIGHTER (T2)
Move through enemy spaces.

### GHOSTLY MOVEMENT (T3)
Don't provoke opportunity attacks.

### WHIRLWIND OF STEEL (T3)
Once/combat, attack every enemy in reach.

### SHADOW STEP (T3)
Once/combat, teleport 10m to shadow. +50% damage next attack.

### PERFECT MOBILITY (T4)
Double speed. Always act first. Free full move after attacking.

### ACROBATIC DODGE (T2)
Once/round, AGI check to negate attack.

### TUMBLING STRIKE (T2)
Move through enemy space + attack = +2 damage.

### UNPREDICTABLE (T3)
Enemies: -2 to hit you while you moved this turn.

### ELUSIVE TARGET (T3)
AOE attacks: auto-save or half damage.

### PHANTOM STRIKER (T4)
Invisible until you attack. After attack, can become invisible again (1/round).

### OPPORTUNIST (T1)
+2 damage vs enemies who attacked someone else.

### RIPOSTE (T2)
When missed, free attack at +2.

### UNTOUCHABLE BLADE (T4)
Once/combat, no attacks can hit you for 1 round.

---

## MENDER POOL (20 talents)

### HEALING TOUCH (T1)
Healing: +3 HP.

### TRIAGE (T1)
Stabilize as free action.

### PRESERVING CARE (T1)
Healing +50% on targets below 50% HP.

### SOOTHING PRESENCE (T1)
Allies within 5m: +2 saves vs fear/pain.

### CLEANSING LIGHT (T2)
Healing also removes one condition.

### BATTLEFIELD MEDIC (T2)
Stabilized targets at 1 HP. Move them 2m.

### VITAL SURGE (T2)
Once/combat, next heal auto-crits.

### EMERGENCY CARE (T2)
Healing at range (30m).

### MASS HEALING (T3)
Single-target heals may affect 3 allies at half.

### RESURRECTION PROTOCOL (T3)
Once/rest, revive ally dead within 1 minute at 1 HP.

### FONT OF LIFE (T3)
Start of each round: you and allies within 5m recover 3 HP.

### AVATAR OF RESTORATION (T4)
Once/rest, 3 AP: all allies within 10m full HP, remove all conditions.

### PREVENTIVE MEDICINE (T2)
Once/ally/day, grant 15 temp HP.

### HEALING OVERDRIVE (T3)
When healing, excess becomes temp HP.

### REGENERATION FIELD (T3)
Create 10m zone. Allies inside: 5 HP/round.

### MIRACLE WORKER (T4)
Once/week, cure any condition, disease, or injury.

### LIFE BOND (T2)
Link with ally. Share damage taken.

### SHARED VITALITY (T3)
Life Bond: also share healing received.

### PERFECT HARMONY (T4)
Life Bond: both gain +2 all rolls, can't die while other has HP.

### PHOENIX TOUCH (T4)
Healing you do can't be reduced or prevented.

---

## WARDEN POOL (20 talents)

### HINDERING PRESENCE (T1)
Enemies within 3m: -1m speed.

### DEBILITATING STRIKES (T1)
Hits: target -1 next attack.

### AREA DENIAL (T1)
Once/combat, 3m zone: enemies -2 all rolls, 3 rounds.

### SLOWING AURA (T1)
Enemies in 5m: difficult terrain.

### CRIPPLING BLOWS (T2)
Hits: -2 attack, -2 DEF on crit.

### LOCKDOWN (T2)
Once/combat, 2 AP: root all in 5m (WIL save).

### EXPANDING CONTROL (T2)
Area Denial: 5m, 5 rounds.

### MASS SLOW (T2)
Hindering Presence: 5m radius.

### DOMINATING PRESENCE (T3)
Hits: Slowed until end of their turn.

### ABSOLUTE CONTROL (T3)
Lockdown: 10m, -4 all rolls while rooted.

### ZONE MASTER (T3)
2 Area Denial zones. Allies in zones: +2 all rolls.

### MASTER OF THE FIELD (T4)
Once/rest, 3 AP: all enemies in 15m Stunned.

### GRAVITY WELL (T2)
Enemies can't jump/fly in your area.

### TERRAIN SHAPER (T2)
Create difficult terrain in 5m radius at will.

### INESCAPABLE (T3)
Enemies you've hit can't teleport/phase.

### PRISON OF CONTROL (T3)
Once/combat, trap one enemy: can't act, can't be helped.

### DOMAIN LORD (T4)
20m zone: you control all movement.

### ENTANGLE (T2)
Once/combat, target Restrained (MIG save).

### MASS ENTANGLE (T3)
Entangle all enemies in 10m.

### WORLD PRISON (T4)
Once/rest, area frozen in time for 1 round (only you act).

---

## ANALYST POOL (20 talents)

### TACTICAL ASSESSMENT (T1)
Once/combat free: learn enemy HP/DEF/ATK.

### COORDINATE ALLY (T1)
Once/round, ally within 10m: +2 next roll.

### IDENTIFY PATTERN (T1)
After enemy acts twice, know their next action.

### KNOW WEAKNESS (T1)
After studying enemy 1 round: +2 damage vs them.

### EXPLOIT ANALYSIS (T2)
Assessed enemy: you and allies +3 damage vs them.

### TACTICAL GENIUS (T2)
Coordinate: +3, twice/round.

### PREDICTIVE ANALYSIS (T2)
Identified pattern: allies +2 DEF vs that enemy.

### PERFECT INFORMATION (T2)
Assessment reveals ALL stats and abilities.

### MASTER TACTICIAN (T3)
Once/combat, all allies in 10m: +2 all rolls, 1 round.

### CRITICAL INTELLIGENCE (T3)
Assessed enemies: +50% crit damage from you and allies.

### BATTLE ORCHESTRATOR (T3)
Once/combat, reorganize initiative order.

### SUPREME STRATEGIST (T4)
Combat start: declare Strategy (+2 attack, +3 DEF, or trap).

### ENEMY SPECIALIST (T2)
Know creature: advantage on all checks vs them.

### ENCYCLOPEDIC KNOWLEDGE (T2)
Once/scene, ask GM one fact about any creature.

### BATTLE ORACLE (T3)
Once/combat, know exact outcome of one action before taking it.

### PERFECT PREDICTION (T3)
Know enemy actions 2 rounds ahead.

### GRANDMASTER STRATEGIST (T4)
Once/rest, rewind combat 1 round.

### ANALYTICAL MIND (T1)
+2 INT checks.

### PATTERN RECOGNITION (T2)
Advantage on INT checks vs puzzles/codes.

### OMNISCIENCE (T4)
Once/day, know the answer to any question.

---

## SPEAKER POOL (20 talents)

### RALLYING CRY (T1)
Once/combat, 1 AP: remove fear from allies in 10m, +2 next roll.

### CUTTING WORDS (T1)
Once/round, enemy in 10m: -2 to attack.

### INSPIRING PRESENCE (T1)
Allies within 5m: +1 saves.

### COMMANDING VOICE (T1)
+2 Intimidation and Persuasion.

### BOLSTERING SPEECH (T2)
Rally Cry: also +5 temp HP.

### DEMORALIZE (T2)
Once/combat, 2 AP: target Frightened 3 rounds (WIL save).

### AURA OF CONFIDENCE (T2)
Allies 5m: +2 saves, +1 attack.

### WORDS OF POWER (T2)
Voice carries perfectly in any conditions.

### BATTLE CRY (T3)
Once/combat, 2 AP: all allies 15m: +3 attack, +3 damage, immune fear, 3 rounds.

### WORDS OF DOOM (T3)
Once/rest, target flees (WIL save). Bosses: -4 all rolls.

### LEGENDARY PRESENCE (T3)
Aura 10m. Enemies: -1 all rolls.

### VOICE OF LEGEND (T4)
Once/rest, Pronouncement: Victory/Surrender/Defiance.

### SILVER TONGUE (T2)
Advantage on all Persuasion.

### MASTER ORATOR (T3)
Once/day, speech affects up to 100 listeners profoundly.

### WORDS OF CREATION (T3)
Speak: create minor objects from nothing.

### LEGENDARY DIPLOMAT (T4)
Once/week, negotiate anything (even with mindless/hostile).

### INTIMIDATING PRESENCE (T2)
Enemies meeting you: WIL save or one step more afraid.

### TERRIFYING SHOUT (T3)
Once/combat, all enemies 10m: WIL save or Frightened.

### VOICE OF THE GODS (T4)
Once/day, command: target must obey one order (WIL save).

### INSPIRING HERO (T4)
Your presence prevents allies from fleeing. Morale unbreakable.

---

# ASPECT POOLS (18 talents each)

[Similar structure for Ore, Tide, Pyre, Gale, Radiance, Shroud, Anima, Aether - each with 18 talents across T1-T4 reflecting elemental/thematic identity]

---

## TALENT SUMMARY

| Pool | Count |
|------|-------|
| General | 100 |
| Striker | 20 |
| Guardian | 20 |
| Hunter | 20 |
| Skirmisher | 20 |
| Mender | 20 |
| Warden | 20 |
| Analyst | 20 |
| Speaker | 20 |
| Ore | 18 |
| Tide | 18 |
| Pyre | 18 |
| Gale | 18 |
| Radiance | 18 |
| Shroud | 18 |
| Anima | 18 |
| Aether | 18 |
| **Total** | **404** |
