# Character Creation

## Quick Reference

1. **Background:** GM assigns +2/+1 stats based on pre-Transit profession
2. **Awakening:** Narrative triggers Aspect and Archetype
3. **Class:** Aspect × Archetype determines Class (64 total)
4. **Form:** Choose 1 from derived pool
5. **Stats:** Run script to calculate
6. **Equipment:** Per background and starting resources

**Use the script for stat calculation:**

```bash
cd /mnt/skills/user/emergence-rpg/scripts
python emergence_cli.py character --aspect [aspect] --archetype [archetype] --level 1
```

---

## Step 1: Background

GM assigns +2/+1 to attributes based on the character's pre-Transit profession.

| Background Type | +2 | +1 |
|-----------------|----|----|
| Physical labor | FOR or MIG | The other |
| Combat/Security | MIG or AGI | FOR or PRC |
| Medical/Science | INT or WIS | The other |
| Technical/Craft | INT or PRC | The other |
| Social/Leadership | PRE | WIS or INT |
| Survival/Outdoor | FOR or WIS | AGI |

**Example backgrounds by category:**

- **Physical:** Construction, warehouse, dockworker, athlete
- **Combat:** Police, military, security, martial artist
- **Medical:** Doctor, nurse, EMT, veterinarian, pharmacist
- **Technical:** Engineer, programmer, mechanic, electrician
- **Social:** Lawyer, politician, salesperson, teacher, HR
- **Survival:** Park ranger, hunter, farmer, fisherman

---

## Step 2: Awakening

A narrative event reveals the character's Aspect and Archetype. This should emerge from roleplay.

### Aspect (Elemental Affinity)

Determined by **background, personality, and values**. See `aspects-archetypes.md` for full descriptions.

| Aspect | Core Theme | Typical Triggers |
|--------|------------|------------------|
| Ore | Endurance, stability | Engineer, banker, patient personality |
| Tide | Adaptation, precision | Doctor, analyst, methodical personality |
| Pyre | Transformation, passion | Firefighter, athlete, confrontational |
| Gale | Freedom, speed | Courier, dancer, impulsive personality |
| Radiance | Hope, truth | Teacher, nurse, inspiring personality |
| Shroud | Mortality, sacrifice | Mortician, soldier, pragmatic about death |
| Anima | Instinct, nature | Veterinarian, ranger, intuitive personality |
| Aether | Knowledge, reality | Physicist, programmer, analytical personality |

### Archetype (Combat Role)

Determined by **how they respond to crisis**. What did they do when Transit happened?

| Archetype | Crisis Response | Role |
|-----------|-----------------|------|
| Striker | Attacked the threat directly | Melee DPS |
| Guardian | Protected others | Tank |
| Hunter | Found a vantage point, assessed | Ranged DPS |
| Skirmisher | Kept moving, hit and ran | Mobile DPS |
| Mender | Tended to the wounded | Healer |
| Warden | Controlled the situation | Controller |
| Analyst | Figured out what was happening | Support |
| Speaker | Rallied and organized people | Face/Leader |

---

## Step 3: Class Determination

Cross-reference Aspect × Archetype on this grid:

```
              STRIKER    GUARDIAN   HUNTER     SKIRMISHER MENDER     WARDEN     ANALYST    SPEAKER
  ORE         Warlord    Knight     Arbalist   Saboteur   Apothecary Sentinel   Artificer  Marshal
  TIDE        Marauder   Bulwark    Deadeye    Corsair    Wellspring Maelstrom  Diviner    Siren
  PYRE        Berserker  Immolator  Bombardier Hellion    Firekeeper Pyromancer Alchemist  Firebrand
  GALE        Tempest    Vanguard   Windrunner Dervish    Monk       Stormcaller Tactician Herald
  RADIANCE    Paladin    Templar    Inquisitor Crusader   Cleric     Beacon     Oracle     Prophet
  SHROUD      Reaper     Revenant   Wraith     Assassin   Witch      Hexer      Necromancer Harbinger
  ANIMA       Savage     Beastmaster Ranger    Prowler    Druid      Shaman     Sage       Chieftain
  AETHER      Battlemage Aegis      Warlock    Magus      Mystic     Spellbreaker Arcanist Enchanter
```

See `classes.md` for each class's Awakening ability.

---

## Step 4: Form Selection

### Starting Form Slots

Level 1 characters have **2 Form Slots**:
- **Slot 1:** Choose one form from your derived pool
- **Slot 2:** Empty — must be discovered through play

### Deriving Your Form Pool

Your pool contains **6 forms** chosen from three sources:

**1. Archetype Forms (choose 2):**

| Archetype | Available Forms |
|-----------|-----------------|
| Striker | Heavy Blade, Heavy Crush, Axe, Unarmed Strike, Aggressive Arts, Fire |
| Guardian | Shield, Defensive Arts, Medium Crush, Polearm, Warding, Earth |
| Hunter | Longbow, Crossbow, Thrown, Light Blade, Stealth, Wind |
| Skirmisher | Dual Wield, Light Blade, Finesse Blade, Acrobatics, Thrown, Shadow |
| Mender | Healing, Medicine, Light, Warding, Medium Blade, Spirit |
| Warden | Polearm, Shield, Earth, Water/Ice, Plant, Perception |
| Analyst | Crossbow, Finesse Blade, Illusion, Mind, Investigation, Knowledge |
| Speaker | Medium Blade, Finesse Blade, Diplomacy, Performance, Intimidation, Mind |

**2. Aspect Forms (choose 2):**

| Aspect | Available Forms |
|--------|-----------------|
| Ore | Heavy Crush, Shield, Defensive Arts, Earth, Metal, Smithing |
| Tide | Finesse Blade, Grappling, Thrown, Water/Ice, Healing, Navigation |
| Pyre | Heavy Blade, Axe, Aggressive Arts, Fire, Light, Survival |
| Gale | Light Blade, Shortbow, Acrobatics, Lightning, Wind, Stealth |
| Radiance | Medium Blade, Shield, Defensive Arts, Light, Healing, Leadership |
| Shroud | Light Blade, Finesse Blade, Unarmed Strike, Shadow, Blood, Death |
| Anima | Unarmed Strike, Grappling, Environmental, Beast/Nature, Plant, Spirit |
| Aether | Crossbow, Defensive Arts, Force, Illusion, Time, Void |

**3. Background Forms (GM assigns 2):**

Based on pre-Transit profession:

| Background Type | Typical Forms |
|-----------------|---------------|
| Physical Labor | Athletics, Heavy Crush, Smithing, Environmental |
| Combat/Security | Medium Blade, Shield, Ranged (any), Intimidation |
| Medical/Science | Medicine, Surgery, Knowledge, Investigation |
| Technical/Craft | Crafting, Smithing, Investigation, Perception |
| Social/Leadership | Diplomacy, Performance, Leadership, Deception |
| Survival/Outdoor | Survival, Stealth, Perception, Beast/Nature |
| Criminal | Stealth, Deception, Light Blade, Urban Survival |
| Academic | Knowledge, Investigation, any Magic form, Perception |
| Religious | Healing, Light, Spirit, Performance |
| Artistic | Performance, Crafting, Illusion, Acrobatics |

### Form Pool Resolution

1. Select 2 from Archetype list
2. Select 2 from Aspect list
3. GM assigns 2 from Background
4. Remove duplicates (keep unique forms only)
5. **Final pool: 4-6 forms**
6. **Choose 1** for your starting form

### Example Pool Derivation

**Elena Vasquez** — Crusader (Radiance × Skirmisher)
- Pre-Transit: EMT (Medical background)

**Archetype (Skirmisher):** Dual Wield, Acrobatics
**Aspect (Radiance):** Light, Healing
**Background (Medical):** Medicine, Perception

**Pool:** Dual Wield, Acrobatics, Light, Healing, Medicine, Perception (6 forms)
**Chooses:** Light (offensive magic to complement her mobile archetype)

### Form Slot 2: Discovery

The second slot starts **EMPTY**. It represents latent potential awaiting awakening.

**Discovery Methods:**

| Method | Time | Availability |
|--------|------|--------------|
| Form Scroll (loot) | Instant | Rare drop from enemies |
| Form Teacher (NPC) | 1 week | Must find, may require payment/quest |
| Survival Unlock | Instant | Specific crisis triggers awakening |
| Form Manual (item) | 3 days study | Quest reward or purchase |
| Witnessed Mastery | 2 weeks | Watch master use form, pass INT/WIS check |

**Session Pacing:** Most characters should discover their second form between sessions 2-5. GMs should actively seed opportunities.

See `forms-combat-expanded.md`, `forms-magic-expanded.md`, or `forms-utility-expanded.md` for technique examples.

---

## Step 5: Stat Calculation

**ALWAYS use the script:**

```bash
python emergence_cli.py character --aspect [aspect] --archetype [archetype] --level 1
```

The script applies:
- Base 10 to all stats
- Aspect bonuses (+2 primary, +1 secondary)
- Archetype bonuses (+2 primary, +1 secondary)
- Background bonuses (+2/+1)
- All derived stats

### Manual Verification (if needed)

**Stat Bonuses Applied:**
- Aspect: +2 to primary stat, +1 to secondary
- Archetype: +2 to primary stat, +1 to secondary
- Background: +2/+1 per GM assignment
- **No level-based caps.** Bonuses stack freely.

**Derived Resources (use SCORES, not modifiers):**

| Stat | Formula | Purpose |
|------|---------|---------|
| **HP** | 20 + (MIG × 2) + (FOR × 2) + (Level × 3) | Physical durability |
| **Stamina** | 10 + (FOR × 2) + AGI + Level | Physical exertion |
| **Mana** | 10 + (INT × 2) + (WIL × 2) + Level | Magical energy |
| **Composure** | 10 + (PRE × 2) + WIL + Level | Social/morale resource |

**Composure Usage:**
- Spend to resist Intimidation, fear effects, and social pressure
- Spend to Rally allies (cost = ally count)
- Spend to Inspire (grant bonus = Composure spent, max PRE mod)
- Recovered: Short rest (PRE mod), Long rest (full)
- At 0 Composure: Disadvantage on social rolls, cannot use PRE-based abilities

**Defenses (use modifiers):**

| Stat | Formula |
|------|---------|
| **Physical DC** | 10 + AGI mod + Armor |
| **Mental DC** | 10 + WIL mod |
| **Resistance DC** | 10 + WIS mod + WIL mod |

**Combat Stats:**

| Stat | Formula |
|------|---------|
| **Initiative** | AGI mod + PRC mod |
| **Movement** | 6 + AGI mod meters (min 1) |
| **Crit Threshold** | 12 (drops to 11 at PRC +3, 10 at +5, 9 at +7) |

---

## Step 6: Equipment

Starting equipment based on background. GM discretion.

**Typical starting gear:**
- One weapon appropriate to class
- Clothing or light armor (if proficient)
- Basic supplies (1-3 days food, water container, light source)
- One item from background (tools, book, keepsake)

**No starting gold.** Currency collapsed post-Transit. Trade is barter-based early game.

---

## Character Display Format

```markdown
## [Name] — Level X [Class]
*[Aspect] × [Archetype]*

| MIG | FOR | AGI | PRC | INT | WIS | WIL | PRE |
|-----|-----|-----|-----|-----|-----|-----|-----|
| X (+X) | X (+X) | X (+X) | X (+X) | X (+X) | X (+X) | X (+X) | X (+X) |

**HP:** X/X | **Stamina:** X/X | **Mana:** X/X | **Composure:** X/X
**Phys DC:** X | **Mental DC:** X | **Resist DC:** X
**Init:** +X | **Move:** Xm | **Crit:** X+

**Awakening:** [Name] — [Category: Consistent/Conditional]
*[L1 effect]*
*Scaling: L10 → L20 → L30*

**Form 1:** [Name] — [Techniques unlocked]
**Form 2:** Empty

**Equipment:** [Weapon], [Armor], [Items]
```

---

## Death Rules

**At 0 HP:** 
- Fall unconscious
- Stabilize within 3 rounds or die
- Any threat reaching you = instant death

**At negative HP:** 
- Death occurs at -FOR or -10 (whichever is more negative)

**When character dies:**
1. Narrate death clearly
2. State: "[Name] is dead."
3. Offer: "You can create a new character."

No resurrection exists at low levels. Death is permanent.

---

## Example Character

**Marcus Chen** — Level 1 Knight  
*Ore × Guardian*

Pre-Transit: Construction foreman (Physical labor: FOR +2, MIG +1)

Awakening: When the sky cracked and Manhattan tilted, Marcus threw himself over two of his crew, shielding them from falling debris. The System saw his instinct to protect and his unshakeable foundation.

**Stat Bonuses Applied:**
- Background: FOR +2, MIG +1
- Ore Aspect: FOR +2, MIG +1
- Guardian Archetype: FOR +2, WIL +1
- **No caps — bonuses stack freely**

| MIG | FOR | AGI | PRC | INT | WIS | WIL | PRE |
|-----|-----|-----|-----|-----|-----|-----|-----|
| 12 (+1) | 16 (+3) | 10 (+0) | 10 (+0) | 10 (+0) | 10 (+0) | 11 (+0) | 10 (+0) |

**HP:** 20 + (12×2) + (16×2) + (1×3) = **79**
**Stamina:** 10 + (16×2) + 10 + 1 = **53**
**Mana:** 10 + (10×2) + (11×2) + 1 = **53**
**Composure:** 10 + (10×2) + 11 + 1 = **42**

**Phys DC:** 10 | **Mental DC:** 10 | **Resist DC:** 10  
**Init:** +0 | **Move:** 6m | **Crit:** 12+

**Awakening:** Iron Resolve — *Consistent*
*Passive: DR 3 on first hit each round. Active: Redirect attack targeting ally within 5m to self.*

**Form 1:** Shield (chosen from pool)  
**Form 2:** Empty

**Equipment:** Hardhat (improvised helmet), work boots, high-vis vest, thermos, crowbar (medium weapon, 1d8+1 damage)
