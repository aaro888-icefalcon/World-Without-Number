"""
EMERGENCE: THE EXILE — Faction Dynamics Tables
===============================================
Internal crises, sources of legitimacy, diseases of rule.
Makes factions feel like living organizations with internal friction.

Every faction gets one internal_crisis and one legitimacy_source at generation.
"""

import random
from typing import Optional


# ═══════════════════════════════════════════════════════════════════════════════
# INTERNAL CRISES — What's broken INSIDE the faction right now?
# ═══════════════════════════════════════════════════════════════════════════════

INTERNAL_CRISES = {
    "base": [
        "Leader's authority openly challenged by ambitious lieutenant who has real support",
        "Critical resource supply is failing — leadership is hiding how bad it really is",
        "Mole from a rival faction has infiltrated the inner circle, leaking operations",
        "Primary method is backfiring — unintended consequences nobody predicted",
        "Two sub-factions disagree violently on strategic direction, threatening split",
        "Key territory is becoming untenable, but leadership refuses relocation",
        "Key NPC has been compromised or turned by an outside force",
        "Clock completion will hurt them almost as much as it helps — nobody's said it aloud",
        "Former members organizing an opposition movement from outside",
        "Dependent on an external ally they can't control and increasingly don't trust",
        "Succession crisis brewing — leader incapacitated, no clear second in command",
        "Rank and file losing faith in leadership's basic competence",
        "Internal corruption scandal about to become public knowledge",
        "Morale collapse — recent failures draining will to continue",
        "Critical skill holder threatening to leave unless demands are met",
        "Faction's founding ideology clashing with survival pragmatism",
    ],
    "authority": [
        "Legitimacy crumbling — people openly questioning right to rule post-Transit",
        "Marginalized group demanding share of governance they've been excluded from",
        "Grand public infrastructure project gone disastrously over budget and behind schedule",
        "Judicial arm making decisions that contradict executive leadership",
        "Census reveals they govern far fewer people than they've been claiming",
    ],
    "military": [
        "Discipline breaking down as casualties mount with no visible strategic progress",
        "Officers running private operations using faction resources on the side",
        "Soldiers refusing orders they consider suicidal or morally indefensible",
        "Supply chain is being pilfered — someone's selling weapons and rations",
        "PTSD epidemic — too many combat rotations, not enough recovery time",
    ],
    "trade": [
        "Accounting audit reveals massive embezzlement by trusted quartermaster",
        "Trade route essential to operations just became far more dangerous",
        "Rival undercut their monopoly with a cheaper or better alternative",
        "Major client defaulted on a huge outstanding debt — cash crisis",
        "Key product discovered to be defective or dangerous — reputation at stake",
    ],
    "knowledge": [
        "Key research was fabricated — published findings are wrong and decisions were made on them",
        "Experiment escaped containment — something is loose in the facility",
        "Funding faction demanding military applications of pure research",
        "Senior researcher defected to rival with critical proprietary knowledge",
        "Discovery has implications that would terrify the public — suppress or publish?",
    ],
    "faith": [
        "Prophet had a vision that contradicts core doctrine — schism brewing",
        "Charismatic splinter leader drawing away the most devout members",
        "Evidence emerging that the miracles were staged — faith crisis",
        "Younger members questioning traditions that feel irrelevant post-Transit",
        "Sacred site threatened by external force — defend at any cost or relocate?",
    ],
    "criminal": [
        "Boss is becoming paranoid and erratic — purging loyal members on suspicion",
        "Turf war with another criminal group draining resources and personnel",
        "Key money-laundering or fencing operation was just compromised",
        "Someone inside is cooperating with an authority faction — unknown who",
        "Next generation doesn't want to follow in this life — loyalty gap",
    ],
    "commune": [
        "Founding members disagree about whether to remain isolationist or engage",
        "Food production failing due to soil depletion or crop disease",
        "Free-rider problem — some members contributing far less than others",
        "Charismatic visitor is trying to convert commune to a different model",
        "Children are growing up and want things the commune ideology doesn't provide",
    ],
    "scavenger": [
        "Best crew lost on a run — leadership blamed for sending them somewhere too dangerous",
        "Haul disputes — who gets credit and shares for what was found",
        "Safe zones they depend on are being claimed by other factions",
        "Team discovered something that could be worth a fortune or could be a trap",
        "Rivalry between veteran and rookie crews becoming dangerous",
    ],
    "tech": [
        "Critical system they maintain is reaching end of life — no replacement possible",
        "Power grid drawing creature attacks — engineering problem causing security crisis",
        "Key engineer had a mental break and is the only one who understands a critical system",
        "Innovation discovered to have been stolen from another faction's research",
        "Younger engineers pushing risky System-integration approaches that elders oppose",
    ],
    "hunters": [
        "Star hunter killed on a routine job — morale and recruitment devastated",
        "Quarry they've been tracking turns out to be protected by another faction",
        "Monster trophies they sell discovered to be causing mana sickness in buyers",
        "Internal debate between extermination faction and coexistence faction",
        "New creature type appearing that their techniques don't work against",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# SOURCES OF LEGITIMACY — Why do people follow this faction?
# ═══════════════════════════════════════════════════════════════════════════════

SOURCES_OF_LEGITIMACY = [
    "Historical precedent — 'We were here first and organized when nobody else did'",
    "Military strength — 'We can protect you when nothing else can'",
    "Resource control — 'We have what you need to survive'",
    "Democratic mandate — 'The people chose us in a fair process'",
    "Technical expertise — 'Only we can keep critical systems running'",
    "Spiritual authority — 'We understand what happened and why, and what comes next'",
    "Emergency necessity — 'Someone had to step up and we did'",
    "Charismatic leader — 'Follow this person, not the institution'",
    "Track record — 'We delivered results when it mattered most'",
    "Moral authority — 'We held to principles when everyone else compromised'",
    "Information control — 'We know things you need to know'",
    "Cultural identity — 'We represent who we are as a people'",
    "Economic prosperity — 'Life is better inside our territory than outside'",
    "Fear of alternative — 'Whatever replaces us will be worse'",
]


# ═══════════════════════════════════════════════════════════════════════════════
# FACTION RELATIONSHIP COMPLICATIONS — What complicates inter-faction relations?
# ═══════════════════════════════════════════════════════════════════════════════

RELATIONSHIP_COMPLICATIONS = {
    "base": [
        "Trade dependency — one faction needs the other's goods but resents the leverage",
        "Border dispute — contested territory neither will concede",
        "Personal grudge between leaders poisoning institutional relations",
        "One faction sheltering someone the other wants handed over",
        "Alliance of convenience fraying as the original threat recedes",
        "Shared resource both factions need and neither can secure alone",
        "Marriage or relationship connecting members across faction lines",
        "Debt owed from when one faction helped the other survive early days",
        "Intelligence sharing agreement one side is cheating on",
        "Proxy conflict through third parties that both deny",
        "Cultural clash making cooperation difficult despite mutual interest",
        "One faction growing faster than the other, shifting the power balance",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# FACTION DYNAMICS GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

def get_internal_crisis(archetype: str = None) -> str:
    """Roll an internal crisis appropriate for the faction archetype."""
    from tables import roll_on
    ctx = [archetype] if archetype else []
    return roll_on(INTERNAL_CRISES, *ctx)


def get_legitimacy_source() -> str:
    """Roll a source of legitimacy."""
    return random.choice(SOURCES_OF_LEGITIMACY)


def get_relationship_complication() -> str:
    """Roll a relationship complication between two factions."""
    from tables import roll_on
    return roll_on(RELATIONSHIP_COMPLICATIONS)


def get_faction_dynamics(archetype: str = None) -> dict:
    """
    Generate complete faction dynamics package.
    """
    return {
        "internal_crisis": get_internal_crisis(archetype),
        "legitimacy_source": get_legitimacy_source(),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== FACTION DYNAMICS TEST ===\n")
    
    for arch in ["authority", "military", "trade", "criminal", "commune", "tech", None]:
        dyn = get_faction_dynamics(arch)
        print(f"--- {arch or 'generic'} ---")
        print(f"  Crisis: {dyn['internal_crisis']}")
        print(f"  Legitimacy: {dyn['legitimacy_source']}")
        print()
    
    print("--- Relationship Complications ---")
    for _ in range(4):
        print(f"  {get_relationship_complication()}")
