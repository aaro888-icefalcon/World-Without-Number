"""
EMERGENCE: THE EXILE — Context-Layered Tables Package
=====================================================
Provides deep, context-sensitive random content for all generators.

Architecture:
  Every table is a dict with a "base" key (universal entries) and optional
  context-overlay keys (entries added when that context applies).

  get_pool(table, *contexts) merges base + all matching overlays.
  roll_on(table, *contexts) picks one entry from the merged pool.
  roll_n(table, n, *contexts) picks n unique entries.

Usage:
  from tables import roll_on, roll_n, get_pool
  from tables.encounter_context import ENCOUNTER_ACTIVITIES, ENCOUNTER_MOODS
  
  activity = roll_on(ENCOUNTER_ACTIVITIES, "forest", "pack")
  mood = roll_on(ENCOUNTER_MOODS, "high_threat")
"""

import random
from typing import List, Any, Dict, Optional, Tuple


def get_pool(table: dict, *contexts: str) -> list:
    """
    Build a merged pool from a context-layered table.
    
    Args:
        table: Dict with "base" key and optional context keys.
        *contexts: Context strings to include overlays for.
    
    Returns:
        Merged list of entries from base + all matching context overlays.
    """
    pool = list(table.get("base", []))
    for ctx in contexts:
        if ctx and ctx in table:
            pool.extend(table[ctx])
    return pool


def roll_on(table: dict, *contexts: str) -> Any:
    """Pick one random entry from a context-layered table."""
    pool = get_pool(table, *contexts)
    if not pool:
        return None
    return random.choice(pool)


def roll_n(table: dict, n: int, *contexts: str, allow_duplicates: bool = False) -> list:
    """
    Pick n entries from a context-layered table.
    
    By default, entries are unique. If the pool is smaller than n,
    returns the entire pool shuffled.
    """
    pool = get_pool(table, *contexts)
    if not pool:
        return []
    if allow_duplicates:
        return [random.choice(pool) for _ in range(n)]
    random.shuffle(pool)
    return pool[:n]


def roll_weighted(table: dict, *contexts: str) -> Any:
    """
    Pick from a context-layered table where entries are (item, weight) tuples.
    """
    pool = get_pool(table, *contexts)
    if not pool:
        return None
    total = sum(w for _, w in pool)
    roll = random.randint(1, total)
    cumulative = 0
    for item, weight in pool:
        cumulative += weight
        if roll <= cumulative:
            return item
    return pool[-1][0]


def maybe_roll(table: dict, chance: float, *contexts: str) -> Optional[Any]:
    """Roll on table only if random check passes. Returns None on fail."""
    if random.random() < chance:
        return roll_on(table, *contexts)
    return None


def combine_tags(tag_table: dict, n: int = 2) -> list:
    """
    Roll n tags from a tag dict (situation_tags, character_tags, etc).
    Returns list of (key, tag_data) tuples.
    """
    keys = list(tag_table.keys())
    if len(keys) < n:
        n = len(keys)
    selected_keys = random.sample(keys, n)
    return [(k, tag_table[k]) for k in selected_keys]
