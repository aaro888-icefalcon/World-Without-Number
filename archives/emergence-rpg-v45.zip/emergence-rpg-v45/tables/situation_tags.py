"""
EMERGENCE: THE EXILE — Situation Tags
======================================
Each tag is a complete dramatic situation with:
  E (Enemies)      — Who opposes you
  F (Friends)      — Who might help
  C (Complications) — What makes it non-obvious
  T (Things)       — Objects of value/interest
  P (Places)       — Specific locations tied to the situation

Locations and factions get TWO tags rolled at generation.
The combination creates emergent complexity.
"""

import random
from typing import List, Tuple, Dict


# ═══════════════════════════════════════════════════════════════════════════════
# COMMUNITY / LOCATION SITUATION TAGS
# ═══════════════════════════════════════════════════════════════════════════════

SITUATION_TAGS = {
    "ancient_infrastructure": {
        "desc": "Pre-Transit system still functioning — power grid, subway, water treatment",
        "enemies": [
            "Scavenger boss who wants to strip it for parts and profit",
            "Faction leader claiming ownership through territorial proximity",
            "Creature drawn to the electromagnetic signature or heat output",
        ],
        "friends": [
            "Engineer keeping it running through ingenuity and duct tape",
            "Community dependent on the service who'll fight to protect it",
            "Former utility worker who understands the original design",
        ],
        "complications": [
            "System is degrading and nobody has the parts to properly fix it",
            "Operating it draws mana-corrupted creatures to the area",
            "Multiple factions have legitimate claims to access or control",
            "The system is connected to something deeper that nobody understands",
        ],
        "things": [
            "Technical manual that would let someone else replicate maintenance",
            "Stockpile of irreplaceable spare parts hidden somewhere",
            "Override codes the current operator is hoarding for leverage",
        ],
        "places": [
            "Control room — cramped, fortified, papered in handwritten maintenance notes",
            "The conduit/pipe/cable run where something keeps going wrong",
            "Access tunnel only the engineer knows about",
        ],
    },
    "bad_neighbors": {
        "desc": "Two adjacent groups in escalating territorial conflict",
        "enemies": [
            "Provocateur on one side who profits from continued conflict",
            "Hothead whose personal grudge is driving the whole confrontation",
            "Arms dealer supplying both sides and stoking the fire",
        ],
        "friends": [
            "Elder who remembers when both sides cooperated and mourns it",
            "Merchant who trades with both and needs peace for business",
            "Child or young person with connections on both sides",
        ],
        "complications": [
            "Both sides have legitimate grievances that aren't easily dismissed",
            "A third faction is secretly inflaming the conflict for strategic gain",
            "The boundary between them shifts with a mana hazard or creature migration",
            "One side recently took a casualty and won't negotiate while grieving",
        ],
        "things": [
            "The original agreement that defined the boundary between them",
            "Evidence of who actually started the latest violent incident",
            "A shared resource both sides need but neither will admit it",
        ],
        "places": [
            "The disputed boundary — no-man's-land of barricades and warning signs",
            "Neutral meeting ground that's becoming less neutral by the day",
            "The building where the last negotiation broke down violently",
        ],
    },
    "blood_feud": {
        "desc": "Personal vendetta consuming faction resources and poisoning everything",
        "enemies": [
            "The other party in the feud, who considers themselves equally wronged",
            "Opportunist using the feud as cover for their own agenda",
            "Enforcer carrying out feud violence who's starting to enjoy it",
        ],
        "friends": [
            "Family member of one side who wants it to end before more die",
            "Neutral faction leader trying to mediate before it spreads",
            "Someone who knows the original cause and that both sides have it wrong",
        ],
        "complications": [
            "The original wrong is ambiguous — neither side is clearly the villain",
            "The feud has generated genuine secondary grievances on both sides",
            "Ending the feud would require admitting fault, which means losing face and position",
            "Someone uninvolved was recently caught in the crossfire and their people want justice",
        ],
        "things": [
            "A stolen object whose return might end the feud — if both agree on terms",
            "Written record of the original agreement that was broken",
            "Body or remains that one side wants returned for proper burial",
        ],
        "places": [
            "Site of the original offense — still emotionally charged",
            "Graveyard or memorial where feud casualties are remembered",
            "Secret meeting spot where moderate members of both sides talk",
        ],
    },
    "brilliant_innovation": {
        "desc": "Someone cracked a System/magic/tech breakthrough — and everyone wants it",
        "enemies": [
            "Faction that wants to weaponize the innovation",
            "Rival who claims they invented it first and want credit",
            "Entity that considers the innovation a threat to the natural order",
        ],
        "friends": [
            "The inventor, who's in over their head dealing with attention",
            "Pragmatist who sees the innovation's potential to help many",
            "Security-minded ally trying to protect the inventor from exploitation",
        ],
        "complications": [
            "The innovation has a dangerous side effect nobody's noticed yet",
            "It only works in specific conditions that are hard to replicate",
            "The inventor doesn't fully understand why it works",
            "Making it widely available would destabilize existing power structures",
        ],
        "things": [
            "Prototype device or formula that embodies the breakthrough",
            "Notes and research that would let others replicate the work",
            "Rare ingredient or component required for the innovation to function",
        ],
        "places": [
            "Workshop or lab where the breakthrough happened — cluttered, guarded",
            "Testing site where the innovation was first demonstrated publicly",
            "Supplier location for the critical component",
        ],
    },
    "broken_spirits": {
        "desc": "Community apathy — people have given up and exploitation fills the vacuum",
        "enemies": [
            "Petty tyrant exploiting the despair to maintain cheap control",
            "Predator who targets the vulnerable — loan shark, dealer, cult recruiter",
            "Former leader who destroyed morale through incompetence and now deflects blame",
        ],
        "friends": [
            "Stubborn optimist trying to organize resistance or renewal",
            "Outsider who sees the community's potential that residents can't",
            "Youth who hasn't fully surrendered to despair yet",
        ],
        "complications": [
            "The despair has legitimate cause — a series of real disasters, not just attitude",
            "Previous attempt at revival was betrayed, making people cynical about trying again",
            "The exploiter is also providing something essential nobody else offers",
            "Some residents prefer the numbness to the pain of hoping",
        ],
        "things": [
            "A symbol of better days that could rally people if restored",
            "Resources that were promised and never delivered — finding them changes the story",
            "Evidence that the current situation was engineered, not natural",
        ],
        "places": [
            "The abandoned community center where people used to gather",
            "The exploiter's seat of power — comfortable while everyone else suffers",
            "Hidden spot where a small group of holdouts still meets in secret",
        ],
    },
    "corrupt_laws": {
        "desc": "Rules exist to serve leadership, not the community they claim to protect",
        "enemies": [
            "The lawmaker who wrote the rules to benefit themselves",
            "Enforcer who knows the laws are unjust but enjoys the authority",
            "Beneficiary of the corrupt system who will fight any reform",
        ],
        "friends": [
            "Vocal critic who's been punished for speaking out",
            "Sympathetic enforcer who selectively ignores the worst rules",
            "Outsider with standing to challenge the system without facing retaliation",
        ],
        "complications": [
            "Some of the corrupt laws also do genuine good — reform risks the baby with bathwater",
            "The corrupt leader is also competent — removing them creates a power vacuum",
            "People have adapted to the corrupt system and fear the chaos of change",
            "The laws are technically democratic — they were voted on by a manipulated populace",
        ],
        "things": [
            "The charter or founding document that contradicts current practice",
            "Financial records showing where resources actually flow",
            "Sealed testimony from someone the leadership silenced",
        ],
        "places": [
            "The courthouse or council chamber where laws are pronounced",
            "The prison or punishment area where dissenters end up",
            "Back room where the real decisions happen before public votes",
        ],
    },
    "criminal_control": {
        "desc": "Criminal element has de facto control — the official leadership is a front",
        "enemies": [
            "Crime boss who actually runs things behind the figurehead",
            "Gang lieutenant enforcing the real rules on the street",
            "Corrupted official who enables everything for a cut",
        ],
        "friends": [
            "Honest official who suspects but can't prove the connection",
            "Shopkeeper paying protection who'd talk if they felt safe",
            "Former gang member trying to go straight but still knows the operation",
        ],
        "complications": [
            "The criminal element is actually maintaining better order than officials could",
            "Exposing the control would collapse services that depend on the crime network",
            "The figurehead leader doesn't know they're a puppet — they believe they're in charge",
            "Multiple criminal factions, and the current one isn't the worst option",
        ],
        "things": [
            "Ledger of payments from businesses to the real power structure",
            "Key to the tunnels or back routes the criminals use to move unseen",
            "Blackmail material the boss uses to control the figurehead",
        ],
        "places": [
            "The front business that serves as the criminal headquarters",
            "Underground meeting room where actual policy is decided",
            "Warehouse where stolen goods and weapons are stockpiled",
        ],
    },
    "cursed_ground": {
        "desc": "Mana corruption visibly affecting an area — warping life and landscape",
        "enemies": [
            "Creature mutated by the corruption into something new and hungry",
            "Cultist who considers the corruption sacred and opposes cleansing",
            "Profiteer harvesting corrupted material regardless of the risk to others",
        ],
        "friends": [
            "Researcher studying the corruption who needs samples from deep inside",
            "Healer treating corruption sickness in nearby communities",
            "Former resident who wants to reclaim their home from the blight",
        ],
        "complications": [
            "The corruption is spreading slowly but accelerating",
            "Something valuable exists at the center of the corrupted zone",
            "The corruption occasionally produces beneficial mutations alongside harmful ones",
            "Cleansing the corruption might release something contained within it",
        ],
        "things": [
            "Pure water source that the corruption is approaching",
            "Corrupted crystal that might be the source or might be a symptom",
            "Pre-Transit containment equipment that might work if repaired",
        ],
        "places": [
            "The epicenter — beautiful and terrible, visibly wrong in a way that fascinates",
            "Border zone where normal and corrupted land meet — unstable, shifting",
            "Shelter built by someone who's learned to live within the corruption",
        ],
    },
    "enemy_within": {
        "desc": "Infiltrator actively undermining the community from inside",
        "enemies": [
            "The infiltrator — competent, liked, and well-positioned",
            "Their handler from the outside faction giving them orders",
            "Unwitting accomplice who's been manipulated into helping",
        ],
        "friends": [
            "Security chief who suspects something but can't identify who",
            "Person the infiltrator accidentally genuinely bonded with",
            "Outside contact who's noticed the pattern from the other side",
        ],
        "complications": [
            "The infiltrator has genuinely started caring about the community",
            "Multiple people are under suspicion and paranoia is spreading",
            "The information being leaked isn't critical yet — but the next piece will be",
            "The infiltrator's cause is not entirely wrong — they believe they're helping",
        ],
        "things": [
            "Coded messages that would prove the connection if decoded",
            "Dead drop location where information is exchanged",
            "Item the infiltrator smuggled in that hasn't been activated yet",
        ],
        "places": [
            "The infiltrator's quarters — sanitized, nothing personal visible",
            "Communication spot used for covert exchanges",
            "The section of the community the infiltrator has been subtly weakening",
        ],
    },
    "fallen_prosperity": {
        "desc": "Community that had resources and lost them — bitter, desperate, still proud",
        "enemies": [
            "Whoever took or destroyed the resources — if they can be identified",
            "Internal voice blaming leadership and demanding change through anger",
            "Neighboring community that's thriving and ignoring calls for help",
        ],
        "friends": [
            "Former leader trying to rebuild with almost nothing",
            "Scavenger who knows where replacement resources might be found",
            "Diplomatic envoy from another community offering conditional aid",
        ],
        "complications": [
            "The prosperity was built on something unsustainable — this was inevitable",
            "Pride prevents accepting help that comes with conditions",
            "Some members hoarded before the collapse and are hiding reserves",
            "The resources aren't destroyed — they're controlled by someone who won't share",
        ],
        "things": [
            "Remaining stockpile that's being rationed and fought over",
            "Map or record of where the original resource source was",
            "Trade agreement from better days that might still be honored",
        ],
        "places": [
            "The empty warehouse that used to be full — a monument to loss",
            "The leader's office — maps, plans, and desperation on every surface",
            "The wall where supplies are distributed — long lines, tense faces",
        ],
    },
    "foreign_enclave": {
        "desc": "Vaelithar natives living among human survivors — uneasy coexistence",
        "enemies": [
            "Xenophobe organizing against the non-human presence",
            "Enclave hardliner who rejects integration and pushes separatism",
            "Provocateur staging incidents to justify violence from either side",
        ],
        "friends": [
            "Translator or cultural bridge who maintains communication",
            "Mixed household where human and Vaelithar native coexist",
            "Pragmatic leader who values the enclave's unique knowledge",
        ],
        "complications": [
            "Cultural misunderstanding is escalating what started as minor friction",
            "The enclave has knowledge the humans desperately need but won't share freely",
            "Some Vaelithar natives are refugees themselves — fleeing something worse",
            "Interspecies relationships forming and both communities reacting poorly",
        ],
        "things": [
            "Cultural artifact the enclave considers sacred that was accidentally damaged",
            "Trade goods unique to Vaelithar that the enclave controls",
            "Map or knowledge of the surrounding region that humans lack",
        ],
        "places": [
            "The enclave quarter — distinctly different architecture and customs",
            "Market boundary where both communities trade cautiously",
            "Sacred site the enclave maintains that humans built too close to",
        ],
    },
    "new_industry": {
        "desc": "Valuable production method discovered — creating wealth and attracting predators",
        "enemies": [
            "Competitor trying to steal or replicate the process",
            "Protection racketeer offering 'security' at extortionate rates",
            "Larger faction that wants to absorb the operation wholesale",
        ],
        "friends": [
            "Workers who built the industry from scratch and don't want to lose it",
            "Investor who funded the early stages and has a stake in success",
            "Customer community dependent on the product who'll defend the supply",
        ],
        "complications": [
            "Production has environmental or health costs nobody's measuring yet",
            "Success is attracting population the community can't support",
            "The key ingredient or technique depends on one person who could leave or die",
            "Scaling up requires deal with a faction the community doesn't trust",
        ],
        "things": [
            "The production method or formula itself — closely guarded",
            "First large shipment ready for delivery — everyone knows about it",
            "Equipment that took months to build and can't be easily replaced",
        ],
        "places": [
            "The workshop or factory floor — busy, guarded, pride of the community",
            "Storage area where finished product accumulates before distribution",
            "Source location for the critical raw material",
        ],
    },
    "population_boom": {
        "desc": "Refugees flooding in — infrastructure buckling, tensions rising",
        "enemies": [
            "Nativist organizer whipping up resentment against newcomers",
            "Criminal element recruiting from the desperate new arrivals",
            "Refugee leader making aggressive demands that alienate potential allies",
        ],
        "friends": [
            "Aid organizer stretched to breaking trying to feed and shelter everyone",
            "Refugee with critical skills the community desperately needs",
            "Old resident who sees the newcomers as the community's salvation, not burden",
        ],
        "complications": [
            "Resources genuinely can't support current numbers — this isn't just xenophobia",
            "The refugees fled something that might follow them here",
            "Cultural friction between original residents and multiple refugee groups",
            "Refugee children integrating faster than adults, creating generational tension",
        ],
        "things": [
            "Census records showing how dire the resource math actually is",
            "Supplies the refugees brought that they're bartering carefully",
            "Information about what drove the refugees out — useful intelligence",
        ],
        "places": [
            "Refugee camp on community outskirts — crowded, unsanitary, tense",
            "Processing point where arrivals are registered and assessed",
            "Community meeting hall where debates about the newcomers happen nightly",
        ],
    },
    "raider_scourge": {
        "desc": "Regular external raids making life unsustainable",
        "enemies": [
            "Raider war chief who considers this community their personal supply depot",
            "Raider scout embedded in the community reporting on defenses",
            "Collaborator selling information about guard schedules and supply stores",
        ],
        "friends": [
            "Militia captain doing their best with inadequate resources",
            "Survivor of the last raid who has tactical knowledge of raider methods",
            "Neighboring community willing to help if asked — pride prevents asking",
        ],
        "complications": [
            "Raiders are former community members exiled in a previous dispute",
            "Paying tribute might be cheaper than fighting but destroys morale",
            "Defensive improvements require resources allocated to food production",
            "The raiders serve a larger power that would retaliate against full resistance",
        ],
        "things": [
            "Weapons cache that would equalize the fight if found",
            "Detailed map of raider camp layout and schedules",
            "Raider communication methods — flags, signals, or messenger routes",
        ],
        "places": [
            "Breach point where raiders consistently enter — needs fortification",
            "Watchtower or observation post that provides early warning",
            "The ruins of a building destroyed in the last raid — motivation",
        ],
    },
    "scars_of_war": {
        "desc": "Recent battle damage — physical and psychological wounds unhealed",
        "enemies": [
            "Whoever caused the damage — if they might return",
            "Opportunist looting from damaged areas while residents suffer",
            "Demagogue using the trauma to push aggressive policy",
        ],
        "friends": [
            "Medical team treating physical and psychological casualties",
            "Construction crew trying to rebuild essential structures first",
            "Grief counselor or community healer addressing the invisible wounds",
        ],
        "complications": [
            "Rebuilding requires materials that are also needed for defense",
            "Some survivors have PTSD and react violently to triggers",
            "The war solved a problem — the pre-war situation was also terrible",
            "Bodies haven't all been recovered — missing persons uncertainty",
        ],
        "things": [
            "Salvageable materials from destroyed structures",
            "Records lost in the damage that need reconstruction from memory",
            "Weapons or artifacts left behind by the attacking force",
        ],
        "places": [
            "Crater or blast zone — community wound that's also a memorial",
            "Field hospital still operating long after it should have been temporary",
            "The wall or barrier built in panic that's now considered permanent defense",
        ],
    },
    "awakening_surge": {
        "desc": "Mass awakenings happening — new System users everywhere, chaos and opportunity",
        "enemies": [
            "Faction conscripting newly awakened by force",
            "Newly awakened individual whose power outstrips their judgment",
            "Anti-awakened purist demanding registration, restriction, or exile",
        ],
        "friends": [
            "Mentor figure trying to train new awakened safely and quickly",
            "Researcher documenting patterns in who awakens and why",
            "Newly awakened person who just wants to understand and means no harm",
        ],
        "complications": [
            "Awakenings are happening faster than mentors can handle",
            "Some awakenings are going wrong — mutations, instability, madness",
            "Community split between those who see awakenings as gift vs. threat",
            "The surge correlates with something else — approaching threat? Mana event?",
        ],
        "things": [
            "System notification logs showing the pattern of recent awakenings",
            "Containment equipment for when an awakening goes wrong",
            "Training materials adapted from early awakened experiences",
        ],
        "places": [
            "Awakening site — location where an uncontrolled awakening damaged surroundings",
            "Training ground where new awakened practice under supervision",
            "Quarantine zone for unstable awakenings",
        ],
    },
    "system_anomaly": {
        "desc": "The System is behaving unexpectedly — notifications, glitches, new features appearing",
        "enemies": [
            "Faction trying to weaponize the anomaly before understanding it",
            "Individual whose interaction with the anomaly made them dangerous",
            "Entity that seems to be the source or beneficiary of the anomaly",
        ],
        "friends": [
            "Analyst tracking the anomaly's pattern and trying to predict its behavior",
            "System-sensitive individual who can feel when anomalies intensify",
            "Practical leader who wants the anomaly understood, not exploited",
        ],
        "complications": [
            "The anomaly is giving different people different information — contradictory",
            "It might be a feature, not a bug — part of the System's intended function",
            "Studying it attracts attention from something that monitors the System",
            "The anomaly is expanding in scope and nobody knows when it stops",
        ],
        "things": [
            "Record of anomalous System notifications — timestamps and content",
            "Artifact created or modified by the anomaly — properties unknown",
            "Mathematical model that partially predicts anomaly behavior",
        ],
        "places": [
            "Epicenter of the anomaly — reality feels slightly off, System panels flicker",
            "Lab where captured anomaly effects are being studied",
            "Location the anomaly seems to be pointing toward or drawing people to",
        ],
    },
    "transit_refugees": {
        "desc": "Newly arrived group displaced by the Transit — different origin, different trauma",
        "enemies": [
            "Xenophobic locals who see new arrivals as threat to limited resources",
            "Strongman within refugees exploiting their vulnerability for control",
            "External predator targeting the displaced because they're easy victims",
        ],
        "friends": [
            "Refugee spokesperson trying to negotiate fairly from a position of weakness",
            "Local charity organizer overextended but determined",
            "Refugee scout who found this location and vouched for it being safe",
        ],
        "complications": [
            "Refugees come from a different part of NYC with different survival strategies",
            "They brought skills the community needs but also problems it doesn't",
            "Refugee group has internal conflicts that are spilling into the host community",
            "What they fled may follow them — giving the locals ammunition",
        ],
        "things": [
            "Supplies and tools the refugees carried on their journey",
            "Intelligence about areas between here and where they came from",
            "Cultural items they consider essential and locals consider wasteful luxury",
        ],
        "places": [
            "Temporary camp where refugees are clustered — visible poverty",
            "Integration point where refugees interact with existing community",
            "Route they used to get here — potentially useful, potentially dangerous",
        ],
    },
    "mana_corruption": {
        "desc": "Ambient mana intensifying — beneficial for some, lethal for others",
        "enemies": [
            "Creature evolved to thrive in high-mana environment hunting normal life",
            "Sorcerer deliberately intensifying the mana for personal power gain",
            "Corrupted awakened whose abilities have been warped by exposure",
        ],
        "friends": [
            "Healer treating mana sickness cases that keep increasing",
            "Engineer trying to build shielding using pre-Transit materials",
            "Awakened who can navigate the corrupted zone safely and guide others",
        ],
        "complications": [
            "The corruption makes awakened powers stronger — some don't want it fixed",
            "The source might be natural to Vaelithar, not a malfunction",
            "Containment requires resources that would leave defenses weakened",
            "Mana-rich zones produce valuable crystals alongside the corruption",
        ],
        "things": [
            "Mana meter or detection device showing concentration levels",
            "Purification method that works temporarily in small areas",
            "Corrupted crystal sample needed for research",
        ],
        "places": [
            "Hot zone where mana concentration is visibly distorting light and matter",
            "Filtration barrier at community edge — crude but functional",
            "Underground area where mana pools like water in low ground",
        ],
    },
    "hidden_cult": {
        "desc": "Secret worship group growing in the shadows — unclear what they serve",
        "enemies": [
            "Cult leader — charismatic, intelligent, genuinely believes",
            "Recruiter targeting the desperate and disillusioned",
            "Convert in a position of authority being directed from the shadows",
        ],
        "friends": [
            "Family member of a recruit who's watching their loved one change",
            "Former member who escaped and knows some of the inner workings",
            "Investigator who's noticed the pattern but doesn't have proof yet",
        ],
        "complications": [
            "The cult is providing genuine community and support to members",
            "Their beliefs about the System or the Transit might not be entirely wrong",
            "Cracking down would make martyrs and drive recruitment underground",
            "The cult has infiltrated multiple factions — scope unknown",
        ],
        "things": [
            "Cult text or scripture explaining their beliefs and goals",
            "Ritual components that reveal what they're actually trying to do",
            "Membership list — partial, encoded, but names would be explosive",
        ],
        "places": [
            "Hidden meeting place disguised as something mundane",
            "Ritual site showing evidence of repeated ceremonial use",
            "Recruitment ground — public area where targets are identified and approached",
        ],
    },
    "resource_monopoly": {
        "desc": "One group controls something everyone needs — water, medicine, ammunition",
        "enemies": [
            "Monopolist who sets prices to maximize power, not survival",
            "Enforcer who punishes anyone trying to find alternative sources",
            "Merchant collaborating with the monopoly for exclusive distribution rights",
        ],
        "friends": [
            "Black market operator providing access outside monopoly control",
            "Scientist or engineer working on an alternative source",
            "Community organizer building coalition to challenge the monopoly",
        ],
        "complications": [
            "The monopolist is also the only one with expertise to maintain the supply",
            "Breaking the monopoly might lead to wasteful consumption and collapse",
            "Alternative sources exist but are in dangerous territory",
            "The monopoly funds community defense — removing it removes protection",
        ],
        "things": [
            "The resource itself — stockpile, production facility, or source",
            "Alternative source location — map, directions, or access key",
            "Contract documents showing the monopoly's legal or social justification",
        ],
        "places": [
            "Distribution point where people line up and pay the monopoly price",
            "The guarded production or storage facility",
            "Potential alternative source that hasn't been developed yet",
        ],
    },
}


# ═══════════════════════════════════════════════════════════════════════════════
# SITUATION TAG GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

def roll_situation_tags(n: int = 2, context: str = None) -> list:
    """
    Roll n situation tags. Returns list of dicts with full E/F/C/T/P.
    
    Args:
        n: Number of tags to roll (default 2)
        context: Optional context string (unused for now, reserved for
                 future filtering by faction archetype or terrain)
    """
    keys = list(SITUATION_TAGS.keys())
    selected = random.sample(keys, min(n, len(keys)))
    
    result = []
    for key in selected:
        tag = SITUATION_TAGS[key]
        result.append({
            "key": key,
            "desc": tag["desc"],
            "enemy": random.choice(tag["enemies"]),
            "friend": random.choice(tag["friends"]),
            "complication": random.choice(tag["complications"]),
            "thing": random.choice(tag["things"]),
            "place": random.choice(tag["places"]),
        })
    return result


def get_situation_components(tag_key: str) -> dict:
    """Get the full tag data for a specific situation tag by key."""
    return SITUATION_TAGS.get(tag_key)


# ═══════════════════════════════════════════════════════════════════════════════
# TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== SITUATION TAGS TEST ===\n")
    print(f"Total situation tags available: {len(SITUATION_TAGS)}\n")
    
    for _ in range(3):
        tags = roll_situation_tags(2)
        print(f"--- Combination: {tags[0]['key']} + {tags[1]['key']} ---")
        for tag in tags:
            print(f"  [{tag['key']}] {tag['desc']}")
            print(f"    Enemy: {tag['enemy']}")
            print(f"    Friend: {tag['friend']}")
            print(f"    Complication: {tag['complication']}")
            print(f"    Thing: {tag['thing']}")
            print(f"    Place: {tag['place']}")
        print()
