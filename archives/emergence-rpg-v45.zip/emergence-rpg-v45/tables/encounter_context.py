"""
EMERGENCE: THE EXILE — Encounter Context Tables
================================================
What creatures/NPCs are DOING, how they FEEL, what PROBLEMS they have,
and what COMPLICATIONS arise during encounters.

These tables transform static stat blocks into dramatic situations.
Every combat encounter should roll activity + mood, with chances for
problem and complication.
"""

# ═══════════════════════════════════════════════════════════════════════════════
# ENCOUNTER ACTIVITIES — What are they doing when the player arrives?
# ═══════════════════════════════════════════════════════════════════════════════

ENCOUNTER_ACTIVITIES = {
    "base": [
        "Hunting — tracking prey, focused and methodical",
        "Foraging — gathering food from the environment",
        "Patrolling — circling claimed territory in established pattern",
        "Investigating — something unfamiliar caught their attention",
        "Dragging kill — hauling prey or loot back to lair/camp",
        "Guarding cache — posted at food store or valuable resource",
        "Resting — alert but stationary, conserving energy",
        "Tending wounded — caring for injured group member",
        "Marking territory — scent marks, scratches, crude warnings",
        "Migrating — passing through, not settled, moving with purpose",
        "Building — constructing or reinforcing den, nest, or shelter",
        "Drinking — at water source, vulnerable and aware of it",
        "Dominance contest — two members fighting for rank",
        "Feeding — actively eating, reluctant to abandon meal",
        "Hiding — concealed, waiting for something to pass",
        "Fleeing — running from something worse, desperate for cover",
    ],
    "pack": [
        "Surrounding weakened prey — patient, waiting for collapse",
        "Alpha disciplining subordinate — violent, others watching",
        "Split group — hunters out, guards with young at nest",
        "Teaching young — juveniles practicing, adults fiercely protective",
        "Rallying after failed hunt — hungry, frustrated, regrouping",
        "Pack howl/call — signaling location to distant members",
        "Harrying larger prey — taking turns darting in and retreating",
        "Escort formation — protecting something in the center of group",
    ],
    "intelligent": [
        "Setting ambush — positioned in kill zone, waiting",
        "Negotiating with another group — tense meeting in progress",
        "Interrogating captive — extracting information or ransom terms",
        "Performing ritual — magical or religious activity, interruptible",
        "Fortifying position — building barriers, setting traps",
        "Sending scouts — advance party while main group waits",
        "Looting — stripping a location of anything valuable",
        "Debating — argument about next move, leadership contested",
        "Training — practicing combat, testing abilities",
        "Trading — exchanging goods with an unlikely partner",
    ],
    "solitary": [
        "Sleeping in concealed position — dangerous if woken",
        "Grooming or tending wounds alone",
        "Obsessively pacing a boundary line",
        "Consuming something unusual — mana crystal, strange plant",
        "Staring at something in the distance, motionless",
    ],
    "urban": [
        "Scavenging collapsed building — partially inside, partially out",
        "Nesting in abandoned vehicle or subway car",
        "Stalking survivors from rooftops or fire escapes",
        "Fighting rival group at block boundary",
        "Drinking from burst water main or fire hydrant pool",
        "Cornered in dead-end alley — got in, can't get out",
        "Using rubble as vantage point, surveying streets below",
        "Denning in basement or subway entrance",
    ],
    "forest": [
        "Bedded down in thicket — nearly invisible until disturbed",
        "Climbing — moving through canopy, dropping ambush potential",
        "Digging at base of ancient tree — after buried prey or root",
        "Rolling in something foul — masking scent",
        "Stripping bark or vegetation — seasonal feeding behavior",
        "Watching a game trail — hunting from concealment",
    ],
    "ruins": [
        "Drawn to mana emanation — circling a glowing source",
        "Nesting in collapsed structure — aggressive about entrance",
        "Feeding on something recently alive — fresh kill nearby",
        "Trapped by its own weight — floor partially collapsed",
        "Worshipping or fixated on a pre-Transit artifact",
        "Picking through rubble methodically, searching",
    ],
    "swamp": [
        "Submerged — only eyes/nostrils above water surface",
        "Basking on solid ground — sluggish but territorial",
        "Mucking through shallows, churning up bottom",
        "Egg-tending — guarding nest in concealed mound",
        "Parasitized — something attached, creature erratic",
        "Stuck in deep mire — struggling, panicked",
    ],
    "mountain": [
        "Sunning on exposed rock face — visible from distance",
        "Navigating narrow ledge — single-file, can't turn around",
        "Denning in cave — positioned just inside entrance",
        "Calling from peak — territorial display echoing through valleys",
        "Moving through scree field — dislodging stones loudly",
        "Sheltering from wind behind outcrop",
    ],
    "plains": [
        "Grazing or browsing — head down, periodic vigilance checks",
        "Running in formation — moving as herd/pack at speed",
        "Dust bathing — rolling, exposed",
        "Standing watch on hilltop — sentinel duty",
        "Chasing smaller prey through open ground",
    ],
    "crystal": [
        "Absorbing mana from crystal formation — glowing faintly",
        "Gnawing or scraping at crystal deposit",
        "Resonating — vibrating in sync with ambient mana, trancelike",
        "Fragments embedded in hide — partially crystallized",
    ],
    "shadow": [
        "Phasing in and out of visibility — flickering",
        "Feeding on light sources — candles, torches dimming nearby",
        "Hovering motionless in mid-air — watching",
        "Emerging from a shadow cast by a large object",
        "Whispering — producing sounds that almost form words",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# ENCOUNTER MOODS — What emotional state are they in?
# ═══════════════════════════════════════════════════════════════════════════════

ENCOUNTER_MOODS = {
    "base": [
        "Aggressive — looking for a fight or outlet for frustration",
        "Hungry — desperate, willing to take risks for food",
        "Territorial — warning posture, escalates if boundary crossed",
        "Suspicious — watching, assessing, not committing",
        "Wary — skittish, prone to flight or panic attack",
        "Fixated — focused on current task, slow to notice intrusion",
        "Curious — investigating, might not be hostile immediately",
        "Fearful — recently hurt or displaced, reactive and unpredictable",
        "Confident — well-fed, on home turf, relaxed but dominant",
        "Frantic — something scared it badly, erratic behavior",
        "Indifferent — not threatened, will ignore unless provoked",
        "Cornered — trapped or can't flee, fights with desperation",
        "Exhausted — depleted, slower reactions, lower morale",
        "Agitated — something is irritating it, short fuse",
        "Protective — guarding young or wounded, extremely dangerous",
        "Playful — testing, not serious yet, can shift instantly",
    ],
    "pack": [
        "Cohesive — acting as tight unit, high coordination",
        "Fractured — members pulling in different directions",
        "Emboldened — recent victory, feeling invincible",
        "Mourning — lost a member recently, aggressive grief",
    ],
    "intelligent": [
        "Calculating — evaluating threat, waiting for optimal moment",
        "Bored — routine assignment, attention wandering",
        "Zealous — driven by ideology or orders, won't negotiate",
        "Mercenary — everything has a price, open to deals",
        "Paranoid — expecting betrayal, trust no one",
        "Professional — doing a job, nothing personal",
    ],
    "wounded": [
        "Vengeful — lost packmate recently, attacking on sight",
        "Desperate — injured, seeking safe ground, lethal if blocked",
        "Delirious — pain or infection affecting behavior",
    ],
    "high_threat": [
        "Dominant — apex behavior, expects everything to flee from it",
        "Battle-hardened — scarred, unafraid, tests prey with feints",
        "Predatory — already decided you're food, stalking",
        "Contemptuous — doesn't consider you a threat, which is dangerous",
    ],
    "low_threat": [
        "Timid — aware of bigger predators, jumpy",
        "Scavenging mentality — looking for scraps, avoids confrontation",
        "Lost — separated from group, confused",
    ],
    "night": [
        "Nocturnal confidence — this is their time, bold",
        "Light-averse — flinching from torches, prefers darkness",
        "Hunting frenzy — night triggers predatory instincts",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# ENCOUNTER PROBLEMS — What internal issue complicates the encounter?
# Rolled at ~40% chance per encounter
# ═══════════════════════════════════════════════════════════════════════════════

ENCOUNTER_PROBLEMS = {
    "base": [
        "Ambitious subordinate undermining leader's decisions openly",
        "Arguing over food or loot division — cohesion breaking",
        "Several members visibly injured or sick",
        "Leader making irrational choices — group confused, hesitant",
        "Overconfident from recent easy victory — sloppy and careless",
        "Lost something important — cached food, den location, a member",
        "Subordinates ignoring leader's signals — discipline collapse",
        "Just suffered a painful defeat — disorganized, low morale",
        "Running critically low on food — range expanding dangerously",
        "Internal split — half want to stay, half want to move on",
        "Expecting reinforcements that haven't arrived — anxious",
        "About to make a terrible mistake — bad position, weak defenses",
        "One member is behaving erratically — infected, corrupted, or mad",
        "Group is lost — navigating unfamiliar territory poorly",
        "Carrying dead weight — member too injured to fight but won't be left",
        "Just discovered their lair/cache has been raided by something else",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# COMBAT COMPLICATIONS — What twist hits during the fight?
# Rolled at ~30% chance per combat encounter
# ═══════════════════════════════════════════════════════════════════════════════

COMBAT_COMPLICATIONS = {
    "base": [
        "Third party arrives mid-fight — rival predator, scavenger group, or patrol",
        "Terrain shifts — collapse, flooding, fire spreading, ice cracking",
        "One enemy has unusual ability that doesn't match group type",
        "Environmental hazard activates on round 3 — gas vent, unstable floor, falling debris",
        "Enemies have hostage or valuable that limits player area attacks",
        "Reinforcements arrive after 4 rounds if any enemy escapes or signals",
        "Leader has escape route — will flee with critical item if fight turns",
        "Nest discovered — eggs or young present, killing parents changes dynamic",
        "Creature is guarding something players need — not inherently hostile about anything else",
        "Weather changes mid-fight — fog rolls in, sudden downpour, wind picks up",
        "One enemy attempts surrender or parley when bloodied",
        "Dead enemies attract scavengers within minutes — clock starts",
        "Something the enemies were containing is now loose",
        "Fighting damages the environment — structural collapse, dam break, fire",
        "An enemy is already fighting something else when players arrive — three-way",
        "Enemies have a primitive alarm system — gong, horn, tripwire bells",
    ],
    "urban": [
        "Building is structurally compromised — combat vibrations risk collapse",
        "Civilians hiding nearby — collateral damage risk",
        "Gas line rupture — fire/explosion hazard from area attacks",
        "Fight blocks the only known safe route through the area",
    ],
    "forest": [
        "Fire catches in dry underbrush from any flame attack",
        "Trees falling from heavy impacts — zone hazards shift",
        "Fight disturbs a hornet nest, bee swarm, or bat colony",
        "Dense canopy makes retreat paths unclear — navigation check to flee",
    ],
    "ruins": [
        "Floor gives way under heavy combatant — fall to lower level",
        "Combat noise echoes — draws attention from deeper in the ruins",
        "Ancient trap activates from vibrations — mechanical, still functional",
        "Dust cloud from debris reduces visibility to near-zero",
    ],
    "swamp": [
        "Combatants risk sinking in soft ground — movement penalties escalate",
        "Blood in water attracts something large from below",
        "Fog thickens each round — visibility shrinks progressively",
        "Solid ground island is smaller than it looked — cramped battlefield",
    ],
    "mountain": [
        "Rockslide triggered by loud impact — area damage plus terrain change",
        "Altitude: exertion causes fatigue faster, limited recovery",
        "Ledge gives way under weight — fall risk for heavy combatants",
        "Echo carries combat sounds — everything in the valley now knows",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# ENCOUNTER CONTEXT GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

def get_encounter_context(
    terrain: str = None,
    is_pack: bool = False,
    intelligence: int = 4,
    is_wounded: bool = False,
    threat_level: int = 2,
    time_of_day: str = "day",
    problem_chance: float = 0.4,
    complication_chance: float = 0.3,
) -> dict:
    """
    Generate complete behavioral context for an encounter.
    
    Returns dict with activity, mood, and optional problem/complication.
    """
    from tables import roll_on, maybe_roll
    
    # Build context keys
    ctx = []
    if terrain:
        ctx.append(terrain)
    if is_pack:
        ctx.append("pack")
    elif not is_pack:
        ctx.append("solitary")
    if intelligence >= 8:
        ctx.append("intelligent")
    if is_wounded:
        ctx.append("wounded")
    if threat_level >= 4:
        ctx.append("high_threat")
    elif threat_level <= 1:
        ctx.append("low_threat")
    if time_of_day == "night":
        ctx.append("night")
    
    activity = roll_on(ENCOUNTER_ACTIVITIES, *ctx)
    mood = roll_on(ENCOUNTER_MOODS, *ctx)
    problem = maybe_roll(ENCOUNTER_PROBLEMS, problem_chance)
    
    complication_ctx = [terrain] if terrain else []
    complication = maybe_roll(COMBAT_COMPLICATIONS, complication_chance, *complication_ctx)
    
    return {
        "activity": activity,
        "mood": mood,
        "problem": problem,
        "complication": complication,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== ENCOUNTER CONTEXT TEST ===\n")
    
    scenarios = [
        {"terrain": "forest", "is_pack": True, "intelligence": 4, "threat_level": 3},
        {"terrain": "urban", "is_pack": False, "intelligence": 10, "threat_level": 4},
        {"terrain": "swamp", "is_pack": True, "intelligence": 2, "threat_level": 2, "time_of_day": "night"},
        {"terrain": "ruins", "is_pack": False, "intelligence": 12, "threat_level": 5},
        {"terrain": "mountain", "is_pack": False, "intelligence": 3, "threat_level": 1},
    ]
    
    for s in scenarios:
        ctx = get_encounter_context(**s)
        print(f"--- {s['terrain'].upper()} (pack={s['is_pack']}, INT={s['intelligence']}, threat={s['threat_level']}) ---")
        print(f"  Activity: {ctx['activity']}")
        print(f"  Mood: {ctx['mood']}")
        if ctx['problem']:
            print(f"  Problem: {ctx['problem']}")
        if ctx['complication']:
            print(f"  Complication: {ctx['complication']}")
        print()
