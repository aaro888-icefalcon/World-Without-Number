"""
EMERGENCE: THE EXILE — NPC Depth Tables
========================================
Character tags (Ambitions/Powers/Dreads), context-layered motivations,
and context-layered secrets that replace flat personality lists.

Every NPC gets TWO character tags. The combination creates emergent drama.
active_ambition comes from tag 1, active_dread from tag 2, leverage from tag 1.
"""

import random
from typing import List, Tuple, Dict, Optional


# ═══════════════════════════════════════════════════════════════════════════════
# CHARACTER TAGS — Each NPC gets 2, creating combinatorial drama
# Every tag has: desc, ambitions (3+), powers (3+), dreads (3+)
# ═══════════════════════════════════════════════════════════════════════════════

CHARACTER_TAGS = {
    "baneful_success": {
        "desc": "Succeeded too well — success itself is now dangerous",
        "ambitions": [
            "Curb an ally whose enthusiasm has become a liability",
            "Exploit unexpected windfall before others notice the opportunity",
            "Redirect attention away from how much they've actually gained",
        ],
        "powers": [
            "Has resources far beyond what their visible position suggests",
            "Unexpected ally in a powerful position owes them a significant debt",
            "Controls access to something multiple factions badly want",
        ],
        "dreads": [
            "Success drawing predatory attention from someone they can't fight",
            "Being swept to disaster by momentum they started but can't stop",
            "Someone discovering the real cost others paid for this achievement",
        ],
    },
    "betting_it_all": {
        "desc": "Enormous gamble in progress — every bridge burned behind them",
        "ambitions": [
            "Overcome an impossible obstacle through sheer total commitment",
            "Force a decisive confrontation before the window closes",
            "Secure the one critical resource that makes everything else work",
        ],
        "powers": [
            "Can mobilize far more than anyone expects — nothing held in reserve",
            "Desperation has made them fearless, which is its own kind of leverage",
            "Willing to sacrifice things others won't — and people know it",
        ],
        "dreads": [
            "The old debt comes due before the gamble pays off",
            "Key ally realizes how far they've gone and withdraws support",
            "No fallback position if this fails — total personal ruin",
        ],
    },
    "cultural_outsider": {
        "desc": "Doesn't belong — pre-Transit identity clashes with post-Transit reality",
        "ambitions": [
            "Prove value to a group that sees them as fundamentally other",
            "Find or build a community where background isn't a liability",
            "Use unique perspective as advantage others can't replicate",
        ],
        "powers": [
            "Sees patterns insiders miss — not blinded by shared assumptions",
            "Has connections or knowledge from a world others don't access",
            "Nobody considers them a political threat, so they move freely",
        ],
        "dreads": [
            "Being made scapegoat when the group needs someone to blame",
            "The community deciding outsiders are the root problem",
            "Having to choose sides and permanently losing the other",
        ],
    },
    "dangerous_debt": {
        "desc": "Owes something terrible to someone who will absolutely collect",
        "ambitions": [
            "Find a way to pay the debt without destroying themselves",
            "Acquire leverage over the creditor to renegotiate terms",
            "Find someone else to transfer the debt onto — ethically or not",
        ],
        "powers": [
            "The creditor keeps them alive and functional — they're an investment",
            "Has intimate knowledge of the creditor's operations and vulnerabilities",
            "Desperation makes them useful to anyone willing to help",
        ],
        "dreads": [
            "The creditor calling in the debt at the worst possible moment",
            "Someone they care about being used as collection leverage",
            "The debt being revealed publicly, destroying their reputation",
        ],
    },
    "dark_past": {
        "desc": "Hiding something from before the Transit that would destroy them now",
        "ambitions": [
            "Ensure the one person who knows stays silent — permanently if needed",
            "Build enough goodwill that revelation wouldn't matter",
            "Destroy the evidence before anyone thinks to look for it",
        ],
        "powers": [
            "Whatever they did gave them skills or knowledge others lack",
            "The secret gives them common ground with other compromised people",
            "They've had years of practice at deception — they're very good at it",
        ],
        "dreads": [
            "A survivor from that time recognizing them in the new world",
            "Being forced into a situation where the truth comes out naturally",
            "Someone using the same methods they used — forcing them to react",
        ],
    },
    "dying_cause": {
        "desc": "The institution or ideal they've built their life around is failing",
        "ambitions": [
            "Find new blood or resources to revive what's dying",
            "Preserve the core of the cause even if the form changes completely",
            "Make one last grand gesture that justifies everything they sacrificed",
        ],
        "powers": [
            "Deep institutional knowledge that nobody else possesses",
            "Loyalty of the few remaining true believers — small but fierce",
            "Nothing left to lose, which makes them unpredictable and bold",
        ],
        "dreads": [
            "Admitting it's truly over and everything was for nothing",
            "Being the one who has to formally end it",
            "Watching an enemy co-opt the cause's legacy for their own ends",
        ],
    },
    "forbidden_bond": {
        "desc": "Relationship that crosses faction, species, or status lines",
        "ambitions": [
            "Find a way to make the relationship safe and public",
            "Protect the other person from consequences of discovery",
            "Build enough power that no one can punish them for it",
        ],
        "powers": [
            "Access to information and resources from the other side",
            "Genuine loyalty from someone in an enemy or rival camp",
            "Understanding of another faction's internal politics",
        ],
        "dreads": [
            "Being forced to choose between loyalty and love publicly",
            "The other person being used as leverage against them",
            "Both sides discovering and neither forgiving",
        ],
    },
    "guilty_knowledge": {
        "desc": "Knows something they wish they didn't — and can't unknow it",
        "ambitions": [
            "Find someone trustworthy enough to share the burden with",
            "Use the knowledge for good without revealing how they got it",
            "Discover the knowledge is wrong — that they misunderstood",
        ],
        "powers": [
            "The knowledge itself is leverage if they dare to use it",
            "Being the only one who knows gives them unique strategic value",
            "People in power will do favors to keep them quiet and happy",
        ],
        "dreads": [
            "The subject of the knowledge discovering they know",
            "Being tortured or coerced into revealing it",
            "The moral weight of keeping silent becoming unbearable",
        ],
    },
    "reluctant_authority": {
        "desc": "Given power they never wanted and can't safely refuse",
        "ambitions": [
            "Find a worthy successor and step down without chaos",
            "Use the position for genuine good before it destroys them",
            "Navigate between factions that all want to control them",
        ],
        "powers": [
            "People follow them specifically because they didn't seek power",
            "Can make decisions others can't because they don't fear losing position",
            "Genuine popular support that rivals can't easily undermine",
        ],
        "dreads": [
            "Making a decision that gets people killed and living with it",
            "Becoming the thing they replaced — corrupted by the role",
            "Someone competent and ruthless deciding they'd be a useful puppet",
        ],
    },
    "simmering_vendetta": {
        "desc": "Patient revenge plan, slowly building toward the decisive strike",
        "ambitions": [
            "Maneuver the target into a position where justice is possible",
            "Gather proof that makes public revenge look like righteous action",
            "Recruit allies who share the grievance without revealing the full plan",
        ],
        "powers": [
            "Obsessive research has made them the foremost expert on the target",
            "Patience has let them embed themselves where the target won't expect",
            "Nothing else matters to them — single-minded focus is powerful",
        ],
        "dreads": [
            "The target dying before revenge is complete — robbed of closure",
            "Discovering the target has a sympathetic reason for what they did",
            "An innocent getting caught in the crossfire when the strike comes",
        ],
    },
    "rising_star": {
        "desc": "Ascending fast — talent or luck drawing both supporters and enemies",
        "ambitions": [
            "Secure position before backlash from those they've passed catches up",
            "Prove they deserve the rise and it wasn't just circumstance",
            "Build alliances strong enough to survive the inevitable challenge",
        ],
        "powers": [
            "Genuine competence that even enemies grudgingly respect",
            "Momentum — people want to back a winner",
            "Fresh perspective uncontaminated by old feuds and debts",
        ],
        "dreads": [
            "Mentor or patron withdrawing support at a critical moment",
            "Being exposed as less capable than the reputation suggests",
            "Old guard uniting specifically to destroy them as a threat",
        ],
    },
    "hidden_vice": {
        "desc": "Addiction or compulsion they're barely controlling — and it's getting worse",
        "ambitions": [
            "Maintain appearances while feeding the vice secretly",
            "Find a cure or substitute that lets them function",
            "Accomplish one great thing before it consumes them entirely",
        ],
        "powers": [
            "The vice community has its own intelligence network",
            "Functional addicts are common post-Transit — less stigma, more company",
            "They'll do things sober people won't, which is sometimes what's needed",
        ],
        "dreads": [
            "Supply running out in a crisis and withdrawal becoming visible",
            "Someone they respect discovering the truth",
            "The vice demanding they betray someone who trusts them",
        ],
    },
    "double_life": {
        "desc": "Maintaining two separate identities or loyalties simultaneously",
        "ambitions": [
            "Merge both lives before the contradiction collapses",
            "Extract maximum value from both sides before choosing",
            "Eliminate the need to choose by changing the situation fundamentally",
        ],
        "powers": [
            "Access to two separate information and resource networks",
            "Can play both sides against each other when needed",
            "Practiced liar with backup stories for every inconsistency",
        ],
        "dreads": [
            "Both lives intersecting in an uncontrollable way",
            "Having to sacrifice one identity permanently to save the other",
            "Someone from one life encountering someone from the other",
        ],
    },
    "survivor_guilt": {
        "desc": "Lived when others died — and can't forgive themselves for it",
        "ambitions": [
            "Honor the dead by completing what they started",
            "Save someone in a situation mirroring the one they survived",
            "Find meaning in survival that justifies still being alive",
        ],
        "powers": [
            "Already survived the worst — hard to intimidate or break",
            "Reckless courage that others mistake for bravery",
            "Deep empathy for others who are suffering — builds fierce loyalty",
        ],
        "dreads": [
            "Another situation where they survive and someone else doesn't",
            "Being praised for surviving when they feel they should have died",
            "The dead person's family or friends appearing and asking why",
        ],
    },
    "prophet_or_madman": {
        "desc": "Claims special knowledge or vision — might be right, might be broken",
        "ambitions": [
            "Prove the vision is real by making a prediction come true",
            "Gather followers before the thing they've foreseen arrives",
            "Find someone who has the same vision independently — validation",
        ],
        "powers": [
            "Some of their predictions have been eerily accurate",
            "Absolute conviction is magnetic — people need certainty post-Transit",
            "May actually be connected to the System in ways others aren't",
        ],
        "dreads": [
            "The vision being proven definitively false and losing everything",
            "Followers taking the prophecy further than intended",
            "Being right — and realizing knowing doesn't help prevent it",
        ],
    },
    "borrowed_time": {
        "desc": "Dying — from injury, disease, or corruption — and knows it",
        "ambitions": [
            "Finish the one thing that matters before time runs out",
            "Ensure whoever comes after is prepared and capable",
            "Die well — on their own terms, for something worth it",
        ],
        "powers": [
            "No fear of consequences — timeline is already fixed",
            "People give them what they want out of pity or respect",
            "Crystal clarity about priorities — no wasted time on nonsense",
        ],
        "dreads": [
            "Dying before the work is done — incomplete, meaningless",
            "Others discovering the condition and changing how they're treated",
            "Finding a cure that requires compromising everything they stand for",
        ],
    },
    "kingmaker": {
        "desc": "Power behind someone else's throne — controls more than anyone realizes",
        "ambitions": [
            "Keep the puppet functional and in position",
            "Expand influence without anyone recognizing the pattern",
            "Transition to open power when the moment is right",
        ],
        "powers": [
            "Decisions attributed to someone else can't be traced back",
            "Multiple people owe them favors and don't realize the web connects",
            "Deep understanding of how power actually works in this community",
        ],
        "dreads": [
            "The puppet developing a mind of their own at the worst time",
            "A rival identifying the real power structure",
            "Being forced into the spotlight they've carefully avoided",
        ],
    },
    "awakening_crisis": {
        "desc": "Recently awakened — power is unstable, identity fracturing",
        "ambitions": [
            "Master the new abilities before they master them",
            "Find someone who can explain what's happening reliably",
            "Use the power to protect people they love before losing control",
        ],
        "powers": [
            "Raw power that's impressive even if poorly controlled",
            "The System seems to be paying attention to them — special notifications",
            "Nothing to unlearn — sometimes beginner's approach works where expertise fails",
        ],
        "dreads": [
            "Losing control in a crowd — hurting innocents",
            "Being identified as a resource and conscripted by a faction",
            "The power changing who they are at a fundamental level",
        ],
    },
    "old_world_authority": {
        "desc": "Had real power pre-Transit — title means nothing here, but habits die hard",
        "ambitions": [
            "Reclaim authority using old-world credentials and connections",
            "Adapt old expertise to new-world problems and prove relevance",
            "Build new power base before the last old-world advantages expire",
        ],
        "powers": [
            "Organizational skills that most post-Transit leaders lack",
            "Network of pre-Transit loyalists who still respect the old hierarchy",
            "Knowledge of systems and infrastructure nobody else understands",
        ],
        "dreads": [
            "Becoming irrelevant — a relic nobody listens to",
            "New-world leaders with real power treating them as a joke",
            "Confronting that old-world skills genuinely don't matter here",
        ],
    },
    "ideological_convert": {
        "desc": "Recently changed beliefs — newly faithful or newly cynical — with a convert's zeal",
        "ambitions": [
            "Prove the new belief by living it publicly and successfully",
            "Convert someone they respect to validate the change",
            "Destroy the old belief system they once belonged to",
        ],
        "powers": [
            "Convert's energy — more passionate than lifelong believers",
            "Intimate knowledge of the opposition's methods and weaknesses",
            "Bridge between two communities that normally don't communicate",
        ],
        "dreads": [
            "Doubt creeping back — what if the old belief was right",
            "Former allies treating the conversion as personal betrayal",
            "New community never fully trusting a convert",
        ],
    },
}


# ═══════════════════════════════════════════════════════════════════════════════
# CONTEXT-LAYERED MOTIVATIONS
# ═══════════════════════════════════════════════════════════════════════════════

MOTIVATIONS = {
    "base": [
        "Protect family or loved ones from immediate danger",
        "Accumulate enough power/resources to feel safe",
        "Find meaning or purpose in the post-Transit world",
        "Return to some version of normalcy at any cost",
        "Exploit the chaos for personal advancement",
        "Prove themselves to someone whose opinion matters",
        "Exact revenge on someone specific for something specific",
        "Survive — nothing else matters, just another day",
        "Help as many people survive as possible",
        "Understand the System and how it works",
        "Build something that outlasts them",
        "Find someone who went missing during the Transit",
        "Atone for something they did in the early chaos",
        "Escape — from this faction, this area, this situation",
        "Become strong enough that nobody can threaten them again",
        "Make sure children — theirs or anyone's — have a future",
    ],
    "authority": [
        "Earn promotion by solving the problem leadership can't",
        "Prevent an escalation that command is recklessly pushing for",
        "Maintain the institution because structure is all that holds fear at bay",
        "Expose corruption within without destroying the whole thing",
        "Prove civilian governance can work when everyone wants a strongman",
    ],
    "military": [
        "Avenge a unit lost in the Transit chaos or since",
        "Maintain discipline because without it they're just another gang",
        "Protect a civilian community that command has written off",
        "Find better weapons/training to stop losing people on patrols",
        "Get the commanding officer replaced before more people die",
    ],
    "trade": [
        "Corner the mana crystal market before the competition",
        "Repay a dangerous business obligation before the deadline",
        "Establish a trade route everyone says is impossible",
        "Protect the family business from predators circling it",
        "Go legitimate after making initial fortune through questionable means",
    ],
    "knowledge": [
        "Publish findings before a rival group claims credit",
        "Prove a theory about the System that could change everything",
        "Find the missing research team that went into the field",
        "Get funding by demonstrating practical application of research",
        "Warn people about a danger the data clearly shows that nobody believes",
    ],
    "faith": [
        "Experience a genuine revelation to resolve growing private doubt",
        "Protect the congregation from exploitation by the leadership",
        "Spread the message to a community that desperately needs hope",
        "Reconcile faith with the reality of what the System actually is",
        "Stop a schism that's tearing the faithful apart",
    ],
    "criminal": [
        "Go legitimate before reputation makes that impossible",
        "Take over from a boss who's becoming dangerously erratic",
        "Settle a score from pre-Transit that still burns daily",
        "Find leverage over the one person who actually scares them",
        "Protect someone they care about from the life they've chosen",
    ],
    "commune": [
        "Keep the community fed through the approaching winter",
        "Mediate a growing rift between founding members before it splits",
        "Convince skeptics that cooperation beats hoarding",
        "Protect someone the commune wants to exile for the greater good",
        "Secure outside alliance without sacrificing independence",
    ],
    "scavenger": [
        "Find the legendary cache everyone talks about but nobody's located",
        "Map a safe route through a zone that would cut travel time in half",
        "Recover a specific item promised to a dangerous client",
        "Beat a rival crew to a major salvage site",
        "Retire from fieldwork alive — transition to coordination or trade",
    ],
    "tech": [
        "Get the power grid stable before the next failure kills people",
        "Reverse-engineer System technology using pre-Transit science",
        "Protect infrastructure from factions that would destroy it for short-term gain",
        "Build a communication network that connects isolated communities",
        "Find replacement parts for critical equipment before stock runs out",
    ],
    "hunters": [
        "Kill the specific creature that killed their partner/team",
        "Map creature migration patterns to predict the next surge",
        "Train enough new hunters to handle what's coming",
        "Prove that a particular creature can be domesticated or bargained with",
        "Acquire trophy/material from an apex predator for specific purpose",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# CONTEXT-LAYERED SECRETS
# ═══════════════════════════════════════════════════════════════════════════════

SECRETS = {
    "base": [
        "Killed someone during the Transit chaos — not in self-defense",
        "Hoarding critical supplies while publicly claiming scarcity",
        "Secretly working for a rival faction as informant",
        "Hiding a loved one who's sick, injured, or wanted",
        "Planning to betray current faction when conditions are right",
        "Has classified information about an imminent threat",
        "Stole something extremely valuable during the confusion",
        "Witnessed a faction leader commit an unforgivable act",
        "Has a hidden awakened ability they're concealing from everyone",
        "In debt to someone genuinely dangerous — payment overdue",
        "Knows a safe route or hidden location of significant value",
        "Pre-Transit professional skills that would change their status if known",
        "Responsible for an accident that killed multiple people",
        "Carrying a message or item for someone they've never met",
        "Has symptoms of mana corruption but hiding progression",
        "Knows the location of a pre-Transit weapons cache",
    ],
    "authority": [
        "Was never actually elected or appointed — just assumed the role in the chaos",
        "Making secret deals with criminal faction for enforcement muscle",
        "Rigging resource distribution to favor loyalists over citizens",
        "Hiding intelligence about a threat to prevent public panic",
        "Executed someone extrajudicially and covered it up",
    ],
    "military": [
        "Their unit committed atrocities in the early days that they covered up",
        "Selling weapons from the armory to outside buyers",
        "Faking patrol reports — some areas are unmonitored and they know it",
        "Deserted from their original unit and assumed a new identity",
        "Commander is addicted to something and decisions are compromised",
    ],
    "trade": [
        "Selling goods they know are contaminated or defective",
        "Fixing prices through secret agreement with supposed competitors",
        "Embezzling from the faction treasury through false accounting",
        "The trade route depends on paying a monster cult for safe passage",
        "Primary supplier is actually a front for a hostile faction",
    ],
    "knowledge": [
        "Fabricated key research data to secure position and funding",
        "Experiment caused a creature mutation they've kept quiet about",
        "Discovered something about the System that terrifies them — buried the findings",
        "Performing unethical tests on awakened subjects without consent",
        "Communicating with a non-human intelligence and hiding it from everyone",
    ],
    "faith": [
        "Doesn't believe any of it — performing faith for power and influence",
        "Had a genuine vision that contradicts everything they preach",
        "The religious practices are actually effective magic they don't understand",
        "Leader is being manipulated by something that speaks in their visions",
        "Receiving material support from a faction hostile to the congregation",
    ],
    "criminal": [
        "Informing to authority faction in exchange for personal immunity",
        "Running a side operation the boss doesn't know about",
        "The previous boss didn't die in the Transit — they killed them",
        "Protecting a non-criminal family that doesn't know what they do",
        "Planning a power grab that requires eliminating three specific people",
    ],
    "commune": [
        "The food supply is contaminated and they're hiding test results",
        "Exiled a member who discovered something inconvenient about leadership",
        "Commune's peaceful reputation maintained through quiet violence at borders",
        "Someone in the commune is a System-granted spy for an external faction",
        "The founding principles were based on a lie about the Transit",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# NPC DEPTH GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

def get_character_tags(n: int = 2) -> list:
    """
    Roll n character tags. Returns list of (tag_key, tag_dict) tuples.
    """
    keys = list(CHARACTER_TAGS.keys())
    selected = random.sample(keys, min(n, len(keys)))
    return [(k, CHARACTER_TAGS[k]) for k in selected]


def get_npc_depth(faction_archetype: str = None) -> dict:
    """
    Generate complete NPC dramatic depth.
    
    Returns dict with character_tags, active_ambition, active_dread,
    leverage, motivation, and secret.
    """
    from tables import roll_on
    
    # Roll two character tags
    tags = get_character_tags(2)
    tag1_key, tag1 = tags[0]
    tag2_key, tag2 = tags[1]
    
    # Build context
    ctx = [faction_archetype] if faction_archetype else []
    
    motivation = roll_on(MOTIVATIONS, *ctx)
    secret = roll_on(SECRETS, *ctx) if random.random() < 0.5 else None
    
    return {
        "character_tags": [
            {"key": tag1_key, "desc": tag1["desc"]},
            {"key": tag2_key, "desc": tag2["desc"]},
        ],
        "active_ambition": random.choice(tag1["ambitions"]),
        "active_dread": random.choice(tag2["dreads"]),
        "leverage": random.choice(tag1["powers"]),
        "motivation": motivation,
        "secret": secret,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== NPC DEPTH TEST ===\n")
    
    for archetype in ["military", "trade", "criminal", "commune", None]:
        depth = get_npc_depth(archetype)
        print(f"--- Archetype: {archetype or 'unaffiliated'} ---")
        print(f"  Tags: {depth['character_tags'][0]['key']} + {depth['character_tags'][1]['key']}")
        print(f"    {depth['character_tags'][0]['desc']}")
        print(f"    {depth['character_tags'][1]['desc']}")
        print(f"  Ambition: {depth['active_ambition']}")
        print(f"  Dread: {depth['active_dread']}")
        print(f"  Leverage: {depth['leverage']}")
        print(f"  Motivation: {depth['motivation']}")
        if depth['secret']:
            print(f"  Secret: {depth['secret']}")
        print()
