"""
EMERGENCE: THE EXILE — Environmental Detail Tables
===================================================
Terrain-specific interactable objects, discoveries, sensory details,
and atmospheric elements that replace the 5 hardcoded objects in scene.py.

Context-layered: base entries work everywhere, overlays add
terrain-specific variety.
"""

import random
from typing import Dict, List, Optional


# ═══════════════════════════════════════════════════════════════════════════════
# ENVIRONMENTAL OBJECTS — Interactable things in the scene
# Each entry: {name, interaction, contents}
# ═══════════════════════════════════════════════════════════════════════════════

ENVIRONMENTAL_OBJECTS = {
    "base": [
        {"name": "Supply cache (hidden)", "interaction": "PRC DC 12 to find, then Search", "contents": "1d4 rations + random common item"},
        {"name": "Collapsed structure", "interaction": "MIG DC 14 to clear", "contents": "Passage or trapped supply"},
        {"name": "Strange markings", "interaction": "INT DC 13 to decipher", "contents": "Information about nearby threat or resource"},
        {"name": "Fresh tracks", "interaction": "WIS DC 11 to read", "contents": "Direction, number, and type of recent passers"},
        {"name": "Damaged vehicle", "interaction": "INT DC 15 to salvage", "contents": "Parts, fuel, or short-range transport"},
        {"name": "Crude barricade", "interaction": "Investigation DC 10", "contents": "Recently built — someone's territory marker"},
        {"name": "Corpse (recent)", "interaction": "WIS DC 12 to examine", "contents": "Cause of death + personal effects + intel"},
        {"name": "Water source", "interaction": "WIS DC 10 to assess purity", "contents": "Clean water or contamination warning"},
        {"name": "Abandoned campfire", "interaction": "WIS DC 11 to age it", "contents": "How recent, how many, which direction they went"},
        {"name": "Graffiti or signage", "interaction": "None (visible)", "contents": "Faction territory claim, warning, or directions"},
        {"name": "Scattered equipment", "interaction": "Search DC 10", "contents": "Partial gear set — something happened to the owner"},
        {"name": "Animal carcass", "interaction": "WIS DC 12 to examine", "contents": "What killed it, how recently, predator still near?"},
    ],
    "urban": [
        {"name": "Functioning vending machine", "interaction": "MIG DC 10 to bash or INT DC 8 to hotwire", "contents": "Preserved food and drinks — trade value"},
        {"name": "Abandoned NYPD cruiser", "interaction": "Search DC 13", "contents": "Weapon, body armor, dead radio, case files"},
        {"name": "Subway entrance", "interaction": "WIL DC 12 to enter (pitch dark below)", "contents": "Underground passage, possible shelter, certain danger"},
        {"name": "Faction graffiti tags", "interaction": "INT DC 10 to interpret", "contents": "Territorial boundaries, warnings, coded messages"},
        {"name": "Apartment with barricaded door", "interaction": "Social or MIG DC 14 to open", "contents": "Survivor, corpse, or abandoned hideout with supplies"},
        {"name": "Fire hydrant rigged as water tap", "interaction": "None (obvious)", "contents": "Clean water — but who controls it?"},
        {"name": "Cell tower with jury-rigged antenna", "interaction": "INT DC 15 to operate", "contents": "Short-range communication ability"},
        {"name": "Collapsed MTA bus blocking road", "interaction": "MIG DC 16 to clear or AGI DC 12 to climb", "contents": "Chokepoint — defensible position or trap"},
        {"name": "Bodega with intact stock", "interaction": "Search DC 11", "contents": "Canned goods, medicine, cigarettes (trade goods)"},
        {"name": "Parking garage (multi-level)", "interaction": "PRC DC 12 to scout safely", "contents": "Vehicles for parts, elevation, nesting creatures"},
        {"name": "Payphone bank", "interaction": "INT DC 14", "contents": "Landline that might connect to something still functioning"},
        {"name": "Manhole cover (loose)", "interaction": "MIG DC 10 to open", "contents": "Sewer access — shortcuts, dangers, hidden communities"},
        {"name": "Rooftop garden (abandoned)", "interaction": "WIS DC 10 to assess", "contents": "Salvageable plants, seeds, growing medium"},
        {"name": "Hospital supply closet", "interaction": "Search DC 13", "contents": "Medical supplies — picked over but not empty"},
    ],
    "forest": [
        {"name": "Game trail with snare traps", "interaction": "PRC DC 12 to spot traps", "contents": "Someone hunts here regularly — NPC nearby"},
        {"name": "Ancient tree with deep carvings", "interaction": "INT DC 14 to read", "contents": "Vaelithar script — directions, warnings, or history"},
        {"name": "Stream with unusual coloring", "interaction": "WIS DC 11 to analyze", "contents": "Mana contamination, mineral deposit, or upstream activity"},
        {"name": "Fungal colony emitting visible spores", "interaction": "FOR DC 12 if approached", "contents": "Alchemical reagent or dangerous irritant"},
        {"name": "Hollow tree (large enough to enter)", "interaction": "PRC DC 10 to spot opening", "contents": "Animal den, cache, or shelter"},
        {"name": "Creek crossing with ford stones", "interaction": "AGI DC 10 in bad conditions", "contents": "Regular travel route — tracks on both sides"},
        {"name": "Deadfall trap (large, crude)", "interaction": "PRC DC 13 to spot", "contents": "Set for large game or intruders — recent construction"},
        {"name": "Berry bushes (heavy with fruit)", "interaction": "WIS DC 12 to identify safe ones", "contents": "Food source or toxic lookalike"},
        {"name": "Spider webs spanning between trees", "interaction": "PRC DC 11 to gauge size of spider", "contents": "Small = safe passage, large = predator territory"},
        {"name": "Mossy stone circle", "interaction": "INT DC 14 or arcane check", "contents": "Mana focus point — amplifies abilities, attracts creatures"},
    ],
    "ruins": [
        {"name": "Intact bookshelf in collapsed library", "interaction": "Search DC 11", "contents": "Reference materials, maps, pre-Transit knowledge"},
        {"name": "Locked safe in rubble", "interaction": "INT DC 16 or MIG DC 18 to open", "contents": "Valuables, documents, or weapon"},
        {"name": "Basement stairs descending into dark", "interaction": "WIL DC 11 to enter", "contents": "Deeper ruins — more danger, better loot"},
        {"name": "Mural or statue (pre-Transit art)", "interaction": "INT DC 10 to interpret", "contents": "Cultural artifact — morale boost or trade value"},
        {"name": "Generator room (fuel smell)", "interaction": "INT DC 13 to assess", "contents": "Repairable generator or fuel reserve"},
        {"name": "Sealed door with functioning lock", "interaction": "AGI DC 15 or key", "contents": "Preserved room — supplies from before"},
        {"name": "Collapsed elevator shaft", "interaction": "AGI DC 14 to climb", "contents": "Vertical access between floors — rope recommended"},
        {"name": "Filing cabinets (government)", "interaction": "Search DC 12", "contents": "Records, maps, personnel files — intelligence"},
        {"name": "Graffiti timeline on wall", "interaction": "None (readable)", "contents": "History of who occupied this ruin since the Transit"},
        {"name": "Trap (tripwire + shotgun/crossbow)", "interaction": "PRC DC 14 to spot", "contents": "Defender's trap — someone considers this their space"},
    ],
    "swamp": [
        {"name": "Solid ground island (dry, raised)", "interaction": "None", "contents": "Safe campsite in hostile terrain — extremely valuable"},
        {"name": "Hollow log spanning water", "interaction": "AGI DC 11 to cross", "contents": "Natural bridge — creature might be inside"},
        {"name": "Bubbling mud pool", "interaction": "WIS DC 13 to identify", "contents": "Hot spring (beneficial) or gas vent (hazardous)"},
        {"name": "Dead tree covered in luminous fungus", "interaction": "WIS DC 12 to harvest", "contents": "Natural light source or alchemical ingredient"},
        {"name": "Abandoned boat (small, crude)", "interaction": "INT DC 11 to assess", "contents": "Transport if repaired — who left it and why?"},
        {"name": "Animal bones arranged in pattern", "interaction": "INT DC 14 to interpret", "contents": "Territorial marker from intelligent creature"},
        {"name": "Quicksand patch", "interaction": "PRC DC 13 to spot before stepping", "contents": "Hazard — or deliberately concealing something underneath"},
        {"name": "Beaver dam or similar structure", "interaction": "WIS DC 10 to assess", "contents": "Animal or something more intelligent built this"},
    ],
    "mountain": [
        {"name": "Cave entrance (natural)", "interaction": "PRC DC 12 to scout safely", "contents": "Shelter, creature lair, or passage deeper"},
        {"name": "Rockslide debris field", "interaction": "MIG DC 14 to clear path", "contents": "Passage or trapped items beneath"},
        {"name": "Mountain spring", "interaction": "WIS DC 10 to verify purity", "contents": "Clean water source — rare at altitude"},
        {"name": "Abandoned climbing equipment", "interaction": "Search DC 11", "contents": "Rope, pitons, carabiners — someone was here before"},
        {"name": "Wind-carved rock shelter", "interaction": "None", "contents": "Natural campsite with wind protection"},
        {"name": "Ore vein visible in cliff face", "interaction": "INT DC 13 to identify", "contents": "Valuable metal or mana-reactive mineral"},
        {"name": "Narrow crevice (passable for one)", "interaction": "AGI DC 12 to squeeze through", "contents": "Shortcut — or choke point for ambush"},
        {"name": "Cairn marker", "interaction": "INT DC 11 to interpret", "contents": "Trail marker, grave, or warning from previous explorer"},
    ],
    "plains": [
        {"name": "Tall grass concealing depression", "interaction": "PRC DC 12 to spot", "contents": "Natural pit, animal burrow, or hidden cache"},
        {"name": "Lone tree (large, old)", "interaction": "PRC DC 10 to scout from", "contents": "Vantage point — plus bird nests, bee hives, carvings"},
        {"name": "Dried creek bed", "interaction": "WIS DC 11 to read", "contents": "Travel route — recent tracks? Seasonal water?"},
        {"name": "Termite mound (enormous)", "interaction": "WIS DC 13", "contents": "Navigation landmark — also mineral-rich soil"},
        {"name": "Prairie dog colony", "interaction": "PRC DC 12 to navigate without ankle injury", "contents": "Hazardous ground — but the holes go deep"},
        {"name": "Abandoned wagon or cart", "interaction": "Search DC 12", "contents": "Trade goods, personal effects, signs of attack"},
        {"name": "Standing stones (three, placed)", "interaction": "INT DC 14 to study", "contents": "Mana focus point, Vaelithar marker, or coincidence"},
    ],
    "crystal": [
        {"name": "Crystal cluster (harvestable)", "interaction": "MIG DC 12 to extract carefully", "contents": "Mana crystal — value depends on purity and size"},
        {"name": "Resonating crystal pillar", "interaction": "WIS DC 14 to safely approach", "contents": "Amplifies or disrupts System abilities nearby"},
        {"name": "Crystallized creature remains", "interaction": "INT DC 13 to study", "contents": "What killed it? Process might threaten living creatures"},
        {"name": "Prismatic light patterns on ground", "interaction": "PRC DC 11 to map pattern", "contents": "Navigation aid, hazard indicator, or beautiful distraction"},
        {"name": "Crystal cave mouth", "interaction": "WIL DC 12 to enter (disorienting)", "contents": "Rich deposits inside — also creatures adapted to the environment"},
    ],
    "shadow": [
        {"name": "Shadow pool (liquid darkness)", "interaction": "WIL DC 14 to approach", "contents": "Gateway, hazard, or trap for light sources"},
        {"name": "Flickering light source (no visible fuel)", "interaction": "INT DC 13 to study", "contents": "Mana phenomenon — useful or lure?"},
        {"name": "Whispering wall (sounds almost form words)", "interaction": "WIL DC 12 to listen", "contents": "Information, madness, or echo of something dead"},
        {"name": "Object half-consumed by shadow", "interaction": "MIG DC 13 to pull free", "contents": "Pre-Transit item being absorbed — still salvageable?"},
        {"name": "Glowing sigils on ground", "interaction": "INT DC 15 to decipher", "contents": "Ward, trap, or marker for something that navigates by magic"},
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# DISCOVERY ENCOUNTERS — What the player finds in discovery scenes
# ═══════════════════════════════════════════════════════════════════════════════

DISCOVERIES = {
    "base": [
        {"name": "Abandoned camp", "check": "Investigation DC 12", "reward": "Supplies + journal with intel"},
        {"name": "Hidden cache", "check": "PRC DC 14", "reward": "Equipment stash — someone's insurance"},
        {"name": "Survivor shelter", "check": "None (obvious)", "reward": "NPC contact + rest opportunity"},
        {"name": "Monster corpse", "check": "WIS DC 11", "reward": "Harvestable parts + what killed it info"},
        {"name": "Pre-Transit technology", "check": "INT DC 13", "reward": "Functional device — use or trade"},
        {"name": "Skill Stone location", "check": "PRC DC 16", "reward": "Possible Skill Stone (rare)"},
        {"name": "Map fragment", "check": "INT DC 12", "reward": "Reveals nearby location of interest"},
        {"name": "Message cache (dead drop)", "check": "PRC DC 13", "reward": "Faction intelligence — valuable to right buyer"},
        {"name": "Natural landmark", "check": "WIS DC 10", "reward": "Navigation waypoint — safe routes from here"},
        {"name": "Crafting materials", "check": "INT DC 11", "reward": "Raw materials for equipment improvement"},
    ],
    "high_threat": [
        {"name": "Ancient ruins entrance", "check": "Various DCs", "reward": "Major dungeon — extreme danger and reward"},
        {"name": "Faction stronghold approach", "check": "Social or Stealth", "reward": "Faction contact or infiltration opportunity"},
        {"name": "Legendary creature trail", "check": "WIS DC 16", "reward": "Track to boss-tier creature lair"},
        {"name": "System anomaly zone", "check": "INT DC 15", "reward": "Unique System interaction — unpredictable"},
        {"name": "Mana wellspring", "check": "WIL DC 14", "reward": "Temporary power boost + creature attention"},
    ],
    "urban": [
        {"name": "Sealed apartment (untouched since Transit)", "check": "AGI DC 13 or MIG DC 15", "reward": "Personal effects + pristine supplies"},
        {"name": "Underground community", "check": "Social DC 12", "reward": "Hidden settlement + trade opportunity"},
        {"name": "Police evidence locker", "check": "Search DC 14", "reward": "Weapons, drugs (trade), case files (intel)"},
        {"name": "Rooftop signal fire (recently used)", "check": "PRC DC 11", "reward": "Communication network exists — find it"},
    ],
    "forest": [
        {"name": "Vaelithar ruin overgrown", "check": "PRC DC 14", "reward": "Ancient structure + potential lore"},
        {"name": "Herbalist grove", "check": "WIS DC 12", "reward": "Medicinal plants + alchemical ingredients"},
        {"name": "Hunter's tree blind", "check": "PRC DC 13", "reward": "Safe rest point + visibility + cached supplies"},
    ],
    "ruins": [
        {"name": "Sealed vault door", "check": "INT DC 16 or brute force", "reward": "Pre-Transit secure storage — high value"},
        {"name": "Functioning computer terminal", "check": "INT DC 14", "reward": "Data access — maps, communications, records"},
        {"name": "Collapsed but passable tunnel", "check": "AGI DC 12", "reward": "New route between known locations"},
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# SENSORY ATMOSPHERE — What the AI GM describes on arrival
# ═══════════════════════════════════════════════════════════════════════════════

ATMOSPHERE = {
    "urban": {
        "sounds": [
            "Distant gunfire — single shots, not automatic, deliberate",
            "Dogs barking somewhere above, echoing off concrete",
            "Wind moaning through broken windows like breathing",
            "Generator humming behind a wall — someone has power",
            "Rats scrabbling inside walls, disturbed by your approach",
            "Dripping water from a burst pipe, rhythmic and constant",
            "Pigeons exploding upward from a ledge as you round the corner",
            "Distant shouting — argument or alarm, can't tell which",
            "Creaking metal from a street sign swaying in wind",
            "Absolute silence — which is worse than any noise",
        ],
        "smells": [
            "Garbage and woodsmoke — someone's burning refuse nearby",
            "Cooking food from somewhere above — meat, spices, civilization",
            "Wet concrete and rust — the city sweating",
            "Cordite — gunfire, recent, within the block",
            "Sewage from a backed-up drain — maintenance stopped months ago",
            "Rain on hot asphalt — petrichor with undertones of oil",
            "Nothing — wind scrubbed this block clean and that's eerie",
        ],
        "sights": [
            "Light in a window three floors up — warm, yellow, human",
            "Rats flowing across the street like dark water",
            "Barricade made from furniture, cars, and shopping carts",
            "Body that nobody's moved — weeks old, nature reclaiming",
            "Laundry hanging between buildings — people live here",
            "Spray-painted warning on a wall — skull, X, or faction symbol",
            "Fire escape ladder dangling — someone pulled it down recently",
            "Shadow moving in a doorway that might be a person",
            "Overturned taxi being used as a planter — flowers growing from it",
            "Street flooding from an open hydrant — ankle deep and spreading",
        ],
    },
    "forest": {
        "sounds": [
            "Birdsong that stops abruptly as you enter — the silence that follows",
            "Something large moving through underbrush parallel to your path",
            "Water running somewhere nearby — brook or stream",
            "Insects — overwhelming, layered, almost mechanical",
            "Branch snapping in the distance — weight, not wind",
            "Canopy rustling in patterns that don't match the wind",
            "Owl hoot in daylight — wrong time, wrong behavior",
        ],
        "smells": [
            "Damp earth and decomposing leaves — rich, alive",
            "Something rotting — dead animal, possibly large",
            "Pine resin — sharp, clean, refreshing",
            "Fungal must — thick, damp, like a wet basement",
            "Flowers — unexpected sweetness in dense forest",
            "Smoke — distant, controlled burn or campfire",
        ],
        "sights": [
            "Sunlight filtering through canopy in visible shafts",
            "Spider web spanning the entire path, dew-covered, enormous",
            "Claw marks on a tree trunk — high up, from something large",
            "Bioluminescent fungus on a fallen log — faint blue-green glow",
            "Trail of broken branches — something big came through recently",
            "Clearing that feels intentional — too perfect to be natural",
            "Eyes reflecting your light source — low to the ground, multiple pairs",
        ],
    },
    "ruins": {
        "sounds": [
            "Settling concrete — groans and pops as the building adjusts",
            "Echo of your own footsteps returning wrong — too late, too many",
            "Scratching from inside a wall — rats, hopefully just rats",
            "Wind playing the building like an instrument — low, mournful",
            "Glass crunching underfoot no matter how carefully you step",
            "Distant collapse — something just fell, somewhere deeper in",
        ],
        "smells": [
            "Dust — decades of it, disturbed by your passage, choking",
            "Mold — black, green, everywhere, coating everything",
            "Old fire — charcoal and ash, long cold",
            "Chemical — something leaking that shouldn't be",
            "Stale air breaking fresh for the first time in months",
        ],
        "sights": [
            "Shaft of light from a ceiling hole illuminating dust motes",
            "Wallpaper peeling in sheets — domestic life frozen mid-decay",
            "Footprints in the dust — yours, and one other set, recent",
            "Graffiti over graffiti over graffiti — layers of occupation",
            "A child's toy on a shelf — untouched, somehow worse than destruction",
            "Ceiling sagging — visible crack in the support beam above",
        ],
    },
    "swamp": {
        "sounds": [
            "Frogs — hundreds of them, deafening, then stopping at once",
            "Bubbling from deep in the mire — gas or something breathing",
            "Buzzing insects in clouds so thick you hear them before you see them",
            "Sucking sound as your boots pull from the mud with each step",
            "Something sliding into water nearby — smooth, heavy, long",
            "Bird screaming — alarm call, not territorial, genuine fear",
        ],
        "smells": [
            "Rot and sulfur — the swamp breathing its dead",
            "Sweet decay — flowers blooming on something decomposing",
            "Stagnant water — flat, old, green, nauseating",
            "Methane — sharp and dangerous near the bubbling patches",
        ],
        "sights": [
            "Fog sitting on the water like a blanket — limiting visibility to meters",
            "Dead trees standing like skeletons — stripped bare, silver-grey",
            "Water that looks solid until something moves under the surface",
            "Insects forming clouds dense enough to have visible shape",
            "Green scum on every surface — nature painting everything one color",
            "Bioluminescence beneath the water — something glowing below",
        ],
    },
    "mountain": {
        "sounds": [
            "Wind — constant, stripping, making conversation difficult",
            "Rockfall somewhere distant — stones bouncing down a slope",
            "Eagle scream — territorial, circling above",
            "Your own labored breathing — altitude taxes everything",
            "Silence — absolute, mountain silence that presses on your ears",
            "Thunder rolling between peaks — echoing back and forth",
        ],
        "smells": [
            "Clean air — almost painfully fresh, thin, cold",
            "Stone dust — dry, mineral, ancient",
            "Snow — that crisp nothing-smell that precedes a storm",
            "Wildflowers in a sheltered spot — startling after bare rock",
        ],
        "sights": [
            "Vast vista — you can see for miles, exposed and elevated",
            "Cloud layer below you — walking above the weather",
            "Switchback trail carved into the rock — someone maintained this once",
            "Snow in crevices even in warm weather — permanent ice",
            "Mountain goats on an impossible ledge — watching you without fear",
            "Cairn left by a previous traveler — recent or ancient, hard to tell",
        ],
    },
    "plains": {
        "sounds": [
            "Wind through tall grass — continuous rustling like breath",
            "Insects — grasshoppers, cicadas, the plains' constant hum",
            "Distant herd — hoofbeats or footfalls, moving parallel",
            "Your own heartbeat — the openness amplifies internal sounds",
            "Thunder on the horizon — storm approaching visibly",
        ],
        "smells": [
            "Dry grass and dust — the smell of open country",
            "Wildflowers — scattered patches of unexpected fragrance",
            "Rain approaching — ozone and wet earth in the distance",
            "Something dead in the tall grass — hidden, buzzing with flies",
        ],
        "sights": [
            "Horizon in every direction — beautiful and terrifying exposure",
            "Grass moving in waves — wind patterns visible like water currents",
            "Lone figure in the distance — mirage or real, can't tell yet",
            "Predator bird circling something — meal in progress or about to be",
            "Storm front approaching — visible as a dark wall from miles away",
        ],
    },
}


# ═══════════════════════════════════════════════════════════════════════════════
# ENVIRONMENTAL DETAIL GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

def get_environmental_objects(terrain: str, n: int = 3, threat_level: int = 2) -> list:
    """Get n interactable objects appropriate for the terrain."""
    from tables import roll_n
    ctx = [terrain] if terrain else []
    return roll_n(ENVIRONMENTAL_OBJECTS, n, *ctx)


def get_discovery(terrain: str = None, threat_level: int = 2) -> dict:
    """Get a discovery encounter appropriate for terrain and threat."""
    from tables import roll_on
    ctx = []
    if terrain:
        ctx.append(terrain)
    if threat_level >= 4:
        ctx.append("high_threat")
    return roll_on(DISCOVERIES, *ctx)


def get_atmosphere(terrain: str) -> dict:
    """Get sensory details for a terrain type."""
    terrain_atm = ATMOSPHERE.get(terrain, ATMOSPHERE.get("urban", {}))
    return {
        "sound": random.choice(terrain_atm.get("sounds", ["Silence"])),
        "smell": random.choice(terrain_atm.get("smells", ["Nothing notable"])),
        "sight": random.choice(terrain_atm.get("sights", ["Nothing notable"])),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== ENVIRONMENTAL DETAIL TEST ===\n")
    
    for terrain in ["urban", "forest", "ruins", "swamp", "mountain"]:
        print(f"--- {terrain.upper()} ---")
        
        atm = get_atmosphere(terrain)
        print(f"  Hear: {atm['sound']}")
        print(f"  Smell: {atm['smell']}")
        print(f"  See: {atm['sight']}")
        
        objs = get_environmental_objects(terrain, n=2)
        print(f"  Objects:")
        for obj in objs:
            print(f"    {obj['name']} — {obj['interaction']} → {obj['contents']}")
        
        disc = get_discovery(terrain, threat_level=3)
        print(f"  Discovery: {disc['name']} ({disc['check']}) → {disc['reward']}")
        print()
