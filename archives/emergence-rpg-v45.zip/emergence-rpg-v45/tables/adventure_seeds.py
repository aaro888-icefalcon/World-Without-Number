"""
EMERGENCE: THE EXILE — Adventure Seed Tables
=============================================
Fractal quest templates that connect isolated scenes into adventures.
Templates have slots filled from world state (factions, NPCs, situation
tag components, clocks).

Seed categories:
  - conflict: Faction vs faction or faction vs threat
  - rescue: Someone needs saving before a deadline
  - heist: Get the thing from the place despite the obstacle
  - mystery: Something is wrong and nobody knows why
  - dilemma: No good options — choose the least bad one
  - clock: A countdown is running and action is required
  - social: Relationships, politics, negotiation
"""

import random
from typing import Dict, List, Optional


# ═══════════════════════════════════════════════════════════════════════════════
# SEED TEMPLATES — Slots filled from world state
#
# Slot types:
#   {enemy_faction}    — hostile or rival faction name
#   {friend_npc}       — friendly or neutral NPC name
#   {enemy_npc}        — hostile NPC name
#   {thing}            — object of value from situation tag "things"
#   {place}            — location from situation tag "places"
#   {complication}     — complication from situation tags
#   {clock_name}       — name of an active clock
#   {days}             — random deadline in days
#   {faction_a/b}      — two different factions
#   {resource}         — critical supply (food, water, medicine, ammunition)
# ═══════════════════════════════════════════════════════════════════════════════

SEED_TEMPLATES = {
    "conflict": [
        "{enemy_faction} suffered a devastating setback. They're seeking {thing} to recover — and they'll kill for it.",
        "{faction_a} and {faction_b} both need {thing}. {friend_npc} knows where it is. {enemy_npc} knows they know.",
        "{enemy_faction} has blockaded access to {place}. Inside: {thing}. {complication} means direct assault is suicide.",
        "{enemy_npc} is escalating hostilities between {faction_a} and {faction_b}. {friend_npc} can prove it — if they survive the next {days} days.",
        "A border dispute between {faction_a} and {faction_b} just turned violent. {complication}. Someone needs to intervene before it becomes a war.",
        "{enemy_faction} hired mercenaries to raid {place}. {friend_npc} got advance warning. {days} days to prepare defenses or evacuate.",
    ],
    "rescue": [
        "{friend_npc} will die within {days} days unless {thing} is retrieved from {place}. {complication}.",
        "{enemy_faction} has taken {friend_npc} captive. Demands: {thing}. Deadline: {days} days. {complication}.",
        "A group of survivors is trapped in {place}. {enemy_faction} is also converging on the location. {complication}.",
        "{friend_npc} went into {place} alone {days} days ago and hasn't returned. Last message mentioned {thing}.",
        "A child from {faction_a} wandered into {enemy_faction} territory. Both sides are mobilizing. {complication}. Clock is ticking.",
    ],
    "heist": [
        "{thing} is inside {place}, guarded by {enemy_faction}. {friend_npc} knows a way in. {complication}.",
        "{enemy_npc} has {thing} and doesn't know its true value. {friend_npc} does. Window closes in {days} days.",
        "{faction_a} wants {thing} stolen from {faction_b}. Payment is generous. {complication}. Getting caught means war.",
        "An abandoned {place} contains {thing}. Problem: it's in a threat zone, and {enemy_faction} is also sending a team.",
        "{friend_npc} has a plan to acquire {thing} from {place}. They need exactly one more person. The plan has a fatal flaw they haven't noticed.",
    ],
    "mystery": [
        "People near {place} are getting sick. {friend_npc} suspects {thing} is the cause. {enemy_npc} doesn't want anyone investigating.",
        "{friend_npc} found {thing} and now someone is trying to kill them. They don't know why. {complication}.",
        "Three NPCs from different factions disappeared near {place} in the last {days} days. Only connection: they all visited {enemy_npc}.",
        "{faction_a}'s {resource} supply is being sabotaged. Everyone suspects {faction_b}. {friend_npc} thinks the real culprit is someone else entirely.",
        "A dead body was found at {place} with {thing} on them. {enemy_faction} wants the body. {faction_a} wants {thing}. Nobody's asking who killed them.",
        "{friend_npc} received a System notification that shouldn't exist. It points to {place}. {complication}.",
    ],
    "dilemma": [
        "{faction_a} offers alliance against {enemy_faction} — but the price is betraying {friend_npc}. {complication}.",
        "{thing} could save dozens of lives at {place}. {friend_npc} needs it to save one person they love. There isn't enough for both.",
        "{enemy_npc} has information that could prevent a disaster. Their price: safe passage through {faction_a} territory. Granting it endangers {friend_npc}.",
        "Destroying {thing} stops {enemy_faction}'s plan. But {thing} is also the only thing keeping {place} habitable.",
        "{friend_npc} committed a crime to protect their people. {faction_a} demands justice. Protecting {friend_npc} means opposing an ally.",
        "{faction_a} and {faction_b} each offer contradictory information about {thing}. One is lying. Acting on the wrong intel means someone at {place} dies.",
    ],
    "clock": [
        "{clock_name} is about to complete. {friend_npc} knows how to stop it — but the cost is {thing} from {place}.",
        "{enemy_faction}'s clock advances in {days} days unless someone destroys {thing} at {place}. {complication}.",
        "Two clocks are approaching completion simultaneously. You can only intervene in one. {faction_a} or {faction_b} — who gets saved?",
        "{friend_npc} discovered that {clock_name} will trigger something worse than anyone expected. Proof is at {place}. {days} days.",
        "The {resource} runs out in {days} days. {thing} at {place} could solve it. {enemy_faction} controls the only route there.",
    ],
    "social": [
        "{faction_a} is holding a summit. {friend_npc} wants you to represent their interests. {enemy_npc} will be there too. {complication}.",
        "{friend_npc} is being forced out of {faction_a}. They've asked for help. {complication}. Intervening means picking a side in internal politics.",
        "{enemy_npc} wants to defect from {enemy_faction}. {friend_npc} vouches for them. The information they bring could be game-changing — or a trap.",
        "A marriage or partnership between members of {faction_a} and {faction_b} could forge peace. {enemy_npc} is trying to sabotage it. {complication}.",
        "{friend_npc} is running for leadership of {faction_a}. {enemy_npc} is the other candidate. Both want your endorsement. {complication}.",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# MACGUFFIN GENERATOR — Things worth questing for
# ═══════════════════════════════════════════════════════════════════════════════

MACGUFFINS = {
    "base": [
        "a cache of pre-Transit antibiotics",
        "a functioning radio transmitter",
        "a map of the underground tunnel network",
        "a System skill stone of unknown type",
        "a sealed container of purified water (large)",
        "a working vehicle with fuel",
        "a weapons cache from an NYPD precinct",
        "a generator with enough fuel for a month",
        "detailed notes on creature migration patterns",
        "a Vaelithar artifact of unclear purpose",
        "a stockpile of ammunition (mixed calibers)",
        "seeds and soil treatments for rooftop farming",
        "medical equipment that can't be replicated",
        "cipher key for faction communications",
        "a mana crystal of unusual purity and size",
        "forging tools and raw metal stock",
    ],
    "high_threat": [
        "a technique scroll for a Tier 3 form ability",
        "coordinates to a Vaelithar ruin nobody's explored",
        "a functioning piece of Vaelithar technology",
        "evidence of a second Transit event approaching",
        "the location of a legendary creature's lair",
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# ADVENTURE SEED GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

def generate_adventure_seed(
    world_state: dict,
    seed_type: str = None,
    threat_level: int = 2,
) -> dict:
    """
    Generate a complete adventure seed from world state.
    
    Args:
        world_state: Dict with human_factions, external_threats, clocks, etc.
        seed_type: Force a specific type or None for random.
        threat_level: Area threat level for macguffin scaling.
    
    Returns:
        Dict with seed_type, template, filled_text, and components used.
    """
    from tables import roll_on
    
    # Select seed type
    if seed_type is None:
        seed_type = random.choice(list(SEED_TEMPLATES.keys()))
    
    templates = SEED_TEMPLATES.get(seed_type, SEED_TEMPLATES["conflict"])
    template = random.choice(templates)
    
    # Extract components from world state
    human_factions = world_state.get("human_factions", [])
    external_threats = world_state.get("external_threats", [])
    clocks = world_state.get("clocks", [])
    
    # Build slot values
    components = {}
    
    # Faction names
    if len(human_factions) >= 2:
        fa, fb = random.sample(human_factions, 2)
        components["faction_a"] = fa.get("name", "Unknown Faction")
        components["faction_b"] = fb.get("name", "Unknown Faction")
    elif len(human_factions) == 1:
        components["faction_a"] = human_factions[0].get("name", "Unknown Faction")
        components["faction_b"] = "an independent group"
    else:
        components["faction_a"] = "the local survivors"
        components["faction_b"] = "a rival band"
    
    # Enemy faction (prefer external threats)
    if external_threats:
        enemy = random.choice(external_threats)
        components["enemy_faction"] = enemy.get("name", "the enemy")
    elif human_factions:
        components["enemy_faction"] = random.choice(human_factions).get("name", "a rival faction")
    else:
        components["enemy_faction"] = "a hostile war band"
    
    # NPC names (generate simple placeholders if no NPCs in world state)
    all_npcs = []
    for f in human_factions:
        all_npcs.extend(f.get("npcs", []))
    
    if len(all_npcs) >= 2:
        friend_npc, enemy_npc = random.sample(all_npcs, 2)
        components["friend_npc"] = friend_npc.get("name") or f"the {friend_npc.get('role', 'stranger')}"
        components["enemy_npc"] = enemy_npc.get("name") or f"the {enemy_npc.get('role', 'adversary')}"
    else:
        components["friend_npc"] = "a desperate survivor"
        components["enemy_npc"] = "a dangerous operative"
    
    # Thing (macguffin)
    ctx = ["high_threat"] if threat_level >= 4 else []
    components["thing"] = roll_on(MACGUFFINS, *ctx)
    
    # Place
    locations = [
        "the old hospital on 5th",
        "the collapsed subway at Grand Central",
        "the fortified warehouse in Red Hook",
        "the rooftop gardens in Midtown",
        "the flooded tunnels under the park",
        "the barricaded school in Harlem",
        "a cave system beyond the city border",
        "the ruins of the power station",
        "the contaminated zone near the waterfront",
        "the overpass camp above the BQE",
    ]
    components["place"] = random.choice(locations)
    
    # Complication
    complications = [
        "the route there passes through hostile territory",
        "two other groups are also after it",
        "the person who knows the way has their own agenda",
        "time pressure means planning is a luxury",
        "success requires cooperation with someone you don't trust",
        "the information might be deliberately misleading",
        "weather is turning and travel will become impossible soon",
        "doing this burns a bridge with an ally",
        "the target location has changed hands since last intel",
        "someone on your side is leaking plans to the opposition",
    ]
    components["complication"] = random.choice(complications)
    
    # Clock
    if clocks:
        clock = random.choice(clocks)
        components["clock_name"] = clock.get("name", "the countdown")
    else:
        components["clock_name"] = "the approaching crisis"
    
    # Days
    components["days"] = str(random.randint(2, 7))
    
    # Resource
    resources = ["food", "clean water", "medicine", "ammunition", "fuel", "building materials"]
    components["resource"] = random.choice(resources)
    
    # Fill template
    filled = template
    for slot, value in components.items():
        filled = filled.replace("{" + slot + "}", str(value))
    
    return {
        "seed_type": seed_type,
        "template": template,
        "text": filled,
        "components": components,
    }


def generate_adventure_hook(world_state: dict, n: int = 3, threat_level: int = 2) -> list:
    """
    Generate multiple adventure seeds for the GM to choose from.
    Tries to vary seed types.
    """
    types = list(SEED_TEMPLATES.keys())
    random.shuffle(types)
    
    seeds = []
    for i in range(min(n, len(types))):
        seed = generate_adventure_seed(world_state, seed_type=types[i], threat_level=threat_level)
        seeds.append(seed)
    return seeds


# ═══════════════════════════════════════════════════════════════════════════════
# TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== ADVENTURE SEED TEST ===\n")
    
    # Mock world state
    world_state = {
        "human_factions": [
            {"id": "f1", "name": "The Exchange", "npcs": [
                {"role": "Boss", "name": "Marcus Cole"},
                {"role": "Negotiator", "name": "Ana Reyes"},
            ]},
            {"id": "f2", "name": "Iron Watch", "npcs": [
                {"role": "Commander", "name": "Sarah Kim"},
                {"role": "Scout", "name": "Ghost"},
            ]},
            {"id": "f3", "name": "The Collective", "npcs": [
                {"role": "Elder", "name": "David Chen"},
            ]},
        ],
        "external_threats": [
            {"id": "t1", "name": "The Thornwood Swarm"},
            {"id": "t2", "name": "Shadowfang the Ancient"},
        ],
        "clocks": [
            {"name": "Monster Pressure", "current": 4, "max": 6},
            {"name": "Winter Comes", "current": 5, "max": 8},
        ],
    }
    
    print("--- Three Adventure Hooks ---\n")
    hooks = generate_adventure_hook(world_state, n=3, threat_level=3)
    for i, hook in enumerate(hooks, 1):
        print(f"Hook {i} [{hook['seed_type'].upper()}]:")
        print(f"  {hook['text']}")
        print()
    
    print("--- One of Each Type ---\n")
    for stype in SEED_TEMPLATES.keys():
        seed = generate_adventure_seed(world_state, seed_type=stype)
        print(f"[{stype.upper()}] {seed['text']}")
        print()
