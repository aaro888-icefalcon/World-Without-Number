# EMERGENCE: THE EXILE — Changelog

## v4.5 (2026-02-04)

### Major Changes

#### 1. Derived Stats Rebalanced
- **HP formula changed:** `20 + (MIG × 2) + (FOR × 2) + (Level × 3)`
  - Previously: `20 + (FOR × 3) + MIG + (Level × 2)`
  - FOR no longer dominates survivability (was 3× contribution, now 2×)
  - MIG now contributes equally to HP
  - Level scaling increased from ×2 to ×3
- **Stamina adjusted:** `10 + (FOR × 2) + AGI + Level`
  - Previously: `15 + (FOR × 2) + AGI + Level`
  - Base reduced from 15 to 10

#### 2. Composure Resource Added
- **New resource:** `10 + (PRE × 2) + WIL + Level`
- PRE finally has a resource pool it contributes to
- Uses:
  - Resist Intimidation, fear effects, social pressure
  - Rally allies (cost = ally count)
  - Inspire allies (grant bonus = Composure spent, max PRE mod)
- At 0 Composure: Disadvantage on social rolls, PRE abilities disabled
- Recovery: Short rest (PRE mod), Long rest (full)

#### 3. Attribute Caps Removed
- No more level-based caps (12 at L1-4, 14 at L5-9, etc.)
- Replaced with investment cost scaling:
  - 10-14: 1 point per +1
  - 15-18: 2 points per +1
  - 19-22: 3 points per +1
  - 23-26: 4 points per +1
  - 27-30: 5 points per +1
- Bonuses from Aspect/Archetype/Background now stack freely

#### 4. Attribute Points Doubled
- Base: +2 points per level (was +1)
- Milestone bonus: +1 additional at L5/10/15/20/25/30
- Total by L30: 64 points (was ~36)
- Enables deeper specialization with diminishing returns

#### 5. Proficiency Talents Tiered
Three tiers replace the old flat Attr 12+ requirement:

**Open Proficiency (Attr 10+):**
- Attack OR damage swap only
- Examples: Martial Arts, Careful Aim, Brutal Swing

**Standard Proficiency (Attr 14+):**
- Attack AND damage swap
- Examples: Surgical Precision, Flowing Steel, Instinctive Archer

**Mastery Proficiency (Attr 18+):**
- Build-defining effects
- Examples: Mind Over Matter, Perfect Form, Transcendent Technique

#### 6. Spell Tier Level Requirements
| Tier | Attr Req | Level Req | Mana Cost |
|------|----------|-----------|-----------|
| 0 | — | — | 0 |
| 1 | 12+ | — | 2-3 |
| 2 | 14+ | 3+ | 4-6 |
| 3 | 16+ | 7+ | 8-10 |
| 4 | 18+ | 12+ | 12-15 |
| 5 | 20+ | 18+ | 18-22 |
| 6 | 24+ | 25+ | 25+ |

- Prevents early-game attribute stacking from bypassing progression
- L4 casters can now access Tier 2 spells (was impossible with 12 cap)

#### 7. Overcasting Rules Added
Characters may cast one tier above qualification:
- Mana cost doubled
- Disadvantage on all spell attack rolls and effect DCs
- On failure: 1d6 psychic damage per tier overcast

#### 8. Magic Type Mapping Complete
All 20 magic schools now assigned to types:
- **Arcane (INT):** Fire, Water/Ice, Lightning, Wind, Metal, Force, Time
- **Divine (WIS):** Light, Healing, Warding
- **Primal (WIS):** Beast/Nature, Plant, Spirit (if chosen)
- **Blood (WIL):** Blood, Death
- **Psionic (WIL):** Mind, Shadow (if chosen)
- **Dual-type forms:** Earth, Shadow, Spirit, Illusion require permanent choice at acquisition

#### 9. Awakening Passive Categories
Two categories based on activation reliability:

**Consistent Passives (always active):**
- Design target: +2-4 effective stat equivalent at L1
- Examples: DR on first hit, permanent initiative bonus, condition immunity
- Knight's Iron Resolve, Oracle's Foresight

**Conditional Passives (requires trigger):**
- Design target: +4-8 effective stat equivalent when active
- Examples: Heal on kill, bonus from stealth, bonus when wounded
- Reaper's Death's Harvest, Assassin's Death's Shadow

**Scaling Pattern:**
- L1: Base effect
- L10: Effect doubles OR new application
- L20: Effect doubles again OR significant capability
- L30: Build-defining ultimate

#### 10. Stances Expanded
| Stance | AP | Move | ATK | DEF | DMG | Special |
|--------|-----|------|-----|-----|-----|---------|
| Balanced | 3 | +0 | +0 | +0 | +0 | Default |
| Aggressive | 4 | +0 | +2 | -2 | +2 | Bonus damage all types |
| Defensive | 2 | -2m | -2 | +4 | +0 | Cannot be crit |
| Mobile | 3 | +4m | +0 | +0 | +0 | Free disengage, no OA |
| Focused | 2 | 0m | Adv | -2 | +0 | Cannot move |

- Change at start of turn only (free action)
- Prone/Grappled/Stunned forces Balanced
- Special stances (Berserker, Iron Wall, etc.) unlock via talents/evolutions

#### 11. Techniques as Examples
- Added header to all three forms files
- ~1,200 techniques are representative examples, not exhaustive
- GMs may create additional following power budget in core-balance-templates.md
- Players may propose custom techniques (GM approval, must discover in-world)

### Files Modified

| File | Changes |
|------|---------|
| `creation.md` | Updated derived stats table, Marcus Chen example |
| `character.py` | New formulas, Composure, removed caps |
| `attributes-core.md` | Replaced caps with investment costs |
| `progression.md` | +2 points/level, updated tables |
| `talents-expanded.md` | Three-tier proficiency system |
| `magic.md` | Level requirements, overcasting, type mapping |
| `classes.md` | Awakening categories, L10/20/30 scaling |
| `combat.md` | Expanded stances section |
| `forms-combat-expanded.md` | Techniques as Examples header |
| `forms-magic-expanded.md` | Techniques as Examples header |
| `forms-utility-expanded.md` | Techniques as Examples header |
| `SKILL.md` | Updated formulas, stances table, v4.5 summary |

### Design Rationale

1. **FOR dominance fix:** FOR contributed 3× to HP, making it the only stat that mattered for survivability. Splitting with MIG creates build diversity.

2. **PRE contribution:** PRE had no resource pool, making it feel incomplete compared to other stats. Composure fills this gap with meaningful social/morale mechanics.

3. **Caps → Costs:** Hard caps felt arbitrary and punished focused builds. Diminishing returns via investment costs rewards breadth while allowing depth.

4. **Proficiency tiers:** All T1 proficiency talents required Attr 12+, but L1 cap was 12. This created class imbalance. Three tiers with escalating power fix this.

5. **Spell level gates:** Tier 2 required Attr 14, but L1-4 cap was 12. L4 casters couldn't cast Tier 2 spells. Level gates ensure progression feels earned.

6. **Awakening categories:** Passives had wildly different reliability (always-on vs. kill trigger vs. stealth). Explicit categories help balance and set player expectations.

---

## v4.4 (Previous)

- Initial procedural generation system
- 64 authored classes
- 60 form trees with 1,200 techniques
- Clock system implementation
- Comprehensive evaluation framework

---

## v4.0 (Foundation)

- Core mechanics established
- 2d6 resolution system
- 8 Aspects × 8 Archetypes matrix
- Discovery-based progression
