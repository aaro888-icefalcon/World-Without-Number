# EMERGENCE: THE EXILE — CHARACTER SHEET

**Version:** 4.5  
**Purpose:** Player character state. Single source of truth for PC mechanics.

---

<!-- DATA:JSON_START
{
  "version": "4.5",
  "identity": {
    "name": "",
    "level": 1,
    "xp": {"current": 0, "next": 100},
    "class_name": "",
    "aspect": "",
    "archetype": "",
    "background": "",
    "awakening_narrative": ""
  },
  "awakening": {
    "name": "",
    "tier": "L1",
    "category": "",
    "passive": "",
    "active": "",
    "active_available": true
  },
  "attributes": {
    "might": 10,
    "agility": 10,
    "fortitude": 10,
    "precision": 10,
    "intellect": 10,
    "wisdom": 10,
    "willpower": 10,
    "presence": 10
  },
  "resources": {
    "hp": {"current": 0, "max": 0},
    "stamina": {"current": 0, "max": 0},
    "mana": {"current": 0, "max": 0},
    "composure": {"current": 0, "max": 0}
  },
  "combat": {
    "physical_def": 0,
    "mental_def": 0,
    "resistance_dc": 0,
    "initiative": 0,
    "movement": 6,
    "crit_threshold": 12,
    "current_stance": "balanced",
    "ap": {"current": 3, "max": 3},
    "rp": {"current": 1, "max": 1},
    "conditions": [],
    "zone": null
  },
  "forms": [],
  "skills": [],
  "talents": [],
  "procedural_passives": [],
  "evolutions": [],
  "equipment": {
    "main_weapon": null,
    "off_weapon": null,
    "armor": null
  },
  "inventory": [],
  "witnessed_techniques": [],
  "combat_history": {
    "combats_survived": 0,
    "enemies_defeated": 0,
    "damage_dealt": 0,
    "damage_taken": 0,
    "most_used_technique": null,
    "close_calls": 0
  }
}
DATA:JSON_END -->

---

## Identity

| Field | Value |
|-------|-------|
| **Name** | |
| **Level** | 1 |
| **XP** | 0 / 100 |
| **Class** | |
| **Aspect** | |
| **Archetype** | |

**Background:** [Pre-Transit profession/life]

**Awakening Narrative:** [How the System chose them]

---

## Awakening

| Field | Value |
|-------|-------|
| **Name** | |
| **Category** | Consistent / Conditional |
| **Current Tier** | L1 |
| **Passive** | |
| **Active** | |
| **Active Used** | ☐ Available |

*Tier milestones: L1 → L10 → L20 → L30*
*Categories: Consistent (always active, +2-4 stat equiv) / Conditional (trigger-based, +4-8 stat equiv)*

---

## Attributes

*Base 10 each. Adjusted by background (+2/+1), aspect (+2/+1), archetype (+2/+1). No caps — bonuses stack freely.*

| Attribute | Score | Mod | Attribute | Score | Mod |
|-----------|-------|-----|-----------|-------|-----|
| **MIG** (Might) | 10 | +0 | **INT** (Intellect) | 10 | +0 |
| **AGI** (Agility) | 10 | +0 | **WIS** (Wisdom) | 10 | +0 |
| **FOR** (Fortitude) | 10 | +0 | **WIL** (Willpower) | 10 | +0 |
| **PRC** (Precision) | 10 | +0 | **PRE** (Presence) | 10 | +0 |

**Modifier Formula:** (Score - 10) ÷ 2, round down

### Attribute Investment (Level Up)
| Target | Cost |
|--------|------|
| 10-14 | 1 pt each |
| 15-18 | 2 pts each |
| 19-22 | 3 pts each |
| 23-26 | 4 pts each |
| 27-30 | 5 pts each |

---

## Resources

*Formulas use attribute SCORES (10-30), not modifiers.*

| Resource | Current | Max | Formula |
|----------|---------|-----|---------|
| **HP** | | | 20 + (MIG × 2) + (FOR × 2) + (Level × 3) |
| **Stamina** | | | 10 + (FOR × 2) + AGI + Level |
| **Mana** | | | 10 + (INT × 2) + (WIL × 2) + Level |
| **Composure** | | | 10 + (PRE × 2) + WIL + Level |

### Composure Usage
- Resist Intimidation, fear effects, social pressure
- Rally allies (cost = ally count)
- Inspire (grant bonus up to PRE mod)
- Recovery: Short rest (PRE mod), Long rest (full)
- **At 0:** Disadvantage on social rolls, PRE abilities disabled

---

## Combat Stats

| Stat | Value | Formula |
|------|-------|---------|
| **Physical DEF** | | 10 + AGI mod + armor |
| **Mental DEF** | | 10 + WIL mod |
| **Resistance DC** | | 10 + WIS mod + WIL mod |
| **Initiative** | | AGI mod + PRC mod |
| **Movement** | | 6 + AGI mod (meters) |
| **Crit Threshold** | 12 | Based on PRC mod |

### Crit Threshold by PRC
| PRC Mod | Threshold | Crit Rate |
|---------|-----------|-----------|
| +0 to +2 | 12 | 2.78% |
| +3 to +4 | 11 | 8.33% |
| +5 to +6 | 10 | 16.67% |
| +7+ | 9 | 27.78% |

---

## Combat State

| Field | Value |
|-------|-------|
| **Current Stance** | Balanced |
| **AP Available** | 3/3 |
| **RP Available** | 1/1 |
| **Conditions** | None |
| **Zone** | — |
| **Awakening Active** | ☐ Available |

### Stance Reference
| Stance | AP | Move | ATK | DEF | DMG | Special |
|--------|-----|------|-----|-----|-----|---------|
| Balanced | 3 | +0 | +0 | +0 | +0 | Default |
| Aggressive | 4 | +0 | +2 | -2 | +2 | Bonus damage all types |
| Defensive | 2 | -2m | -2 | +4 | +0 | Cannot be crit |
| Mobile | 3 | +4m | +0 | +0 | +0 | Free disengage, no OA |
| Focused | 2 | 0m | Adv | -2 | +0 | Cannot move |

*Change stance: Free action at turn start, once per round. Prone/Grappled/Stunned forces Balanced.*

---

## Forms

*Slots: 2 at level 1 (1 chosen + 1 empty), +1 at levels 4, 8, 12, 16, 20, 24, 28*

**Current Slots:** 1 / 2

### Form 1: [Name]
**Category:** [Combat/Magic/Utility]
**Variant:** [Variant name]
**Variant Modifier:** [Effect that applies to all techniques]

| Tier | Technique | Unlocked | AP | Cost | Effect |
|------|-----------|----------|-----|------|--------|
| T1 | — | ☐ | — | — | — |
| T1 | — | ☐ | — | — | — |
| T2 | — | ☐ | — | — | — |
| T2 | — | ☐ | — | — | — |
| T3 | — | ☐ | — | — | — |
| T3 | — | ☐ | — | — | — |
| T4 | — | ☐ | — | — | — |
| T4 | — | ☐ | — | — | — |

### Form 2: [Empty]
*Discover through play: scrolls, teachers, survival unlocks (sessions 2-5)*

---

## Skills (Dropped Abilities)

*Found via Skill Stones. Powerful but resource-intensive.*

| Skill | Rarity | Rank | Uses/Day | AP | Cost | Effect |
|-------|--------|------|----------|-----|------|--------|
| *None yet* | — | — | — | — | — | — |

---

## Talents

*+1 per level starting at level 2. Total at level 30: 29*

| Talent | Tier | Source | Effect |
|--------|------|--------|--------|
| *None yet* | — | — | — |

---

## Procedural Passives

*Generated at levels 3, 7, 12, 18, 25 based on playstyle.*

| Level | Passive | Effect | Generated From |
|-------|---------|--------|----------------|
| 3 | *Not yet* | — | — |
| 7 | *Not yet* | — | — |
| 12 | *Not yet* | — | — |
| 18 | *Not yet* | — | — |
| 25 | *Not yet* | — | — |

---

## Evolution

*Available at levels 10, 20, 30. Aspect-gated.*

| Level | Evolution | Type | Effect |
|-------|-----------|------|--------|
| 10 | *Not yet* | — | — |
| 20 | *Not yet* | — | — |
| 30 | *Not yet* | — | — |

---

## Equipment

### Weapons
| Slot | Weapon | Damage | Type | Properties |
|------|--------|--------|------|------------|
| Main | — | — | — | — |
| Off | — | — | — | — |

### Armor
| Slot | Item | DEF Bonus | Properties |
|------|------|-----------|------------|
| Body | — | +0 | — |

---

## Inventory

**Carrying Capacity:** FOR score × 2 items (no encumbrance)

| Item | Qty | Notes |
|------|-----|-------|
| — | — | — |

---

## Witnessed Techniques

*Techniques seen enemies use. Can attempt to learn.*

| Technique | Form | Tier | Witnessed From | Learned |
|-----------|------|------|----------------|---------|
| — | — | — | — | ☐ |

---

## Combat History

*Tracks patterns for procedural passive generation.*

| Stat | Value |
|------|-------|
| Combats Survived | 0 |
| Enemies Defeated | 0 |
| Damage Dealt (Total) | 0 |
| Damage Taken (Total) | 0 |
| Most Used Technique | — |
| Close Calls (HP ≤ 10%) | 0 |

---

<!--
=== ARTIFACT UPDATE INSTRUCTIONS ===

When UPDATING this artifact:

1. COMBAT DAMAGE:
   - Update HP current value
   - Update JSON block hp.current

2. RESOURCE SPEND:
   - Update Stamina/Mana current
   - Update JSON block resources

3. COMBAT STATE:
   - Update AP/RP available
   - Update conditions list
   - Update zone
   - Update stance if changed

4. LEVEL UP:
   - Update level, XP
   - Recalculate all derived stats using script:
     python emergence_cli.py character --aspect [asp] --archetype [arch] --level [new]
   - Add talent slot
   - Check for new form slot (levels 4,8,12,16,20,24,28)
   - Check for procedural passive (levels 3,7,12,18,25)
   - Check for evolution (levels 10,20,30)

5. FORM UNLOCK:
   - Add technique to appropriate form section
   - Mark as ☑ Unlocked
   - Update JSON forms array

6. LOOT ACQUIRED:
   - Add to inventory
   - Update equipment if better

7. COMBAT END:
   - Reset AP/RP to max
   - Clear temporary conditions
   - Update combat history stats

ALWAYS update both the JSON block AND the markdown section.
-->
