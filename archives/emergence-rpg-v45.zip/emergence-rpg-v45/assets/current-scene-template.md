# EMERGENCE: THE EXILE — CURRENT SCENE

**Version:** 4.3  
**Purpose:** Ephemeral scene state. REGENERATE COMPLETELY on scene change.

---

<!-- DATA:JSON_START
{
  "version": "4.3",
  "scene_id": "",
  "location": {
    "name": "",
    "region": "",
    "terrain": "",
    "threat_level": 2
  },
  "time": {
    "day": 1,
    "time": "12:00",
    "time_of_day": "day"
  },
  "conditions": {
    "weather": "clear",
    "lighting": "daylight",
    "visibility": "normal"
  },
  "scene_type": "exploration",
  "encounter_type": "clear",
  "atmosphere": {
    "sound": "",
    "smell": "",
    "sight": ""
  },
  "zones": [],
  "npcs": [],
  "enemies": [],
  "objects": [],
  "combat_state": {
    "active": false,
    "round": 0,
    "phase": "none",
    "initiative_order": [],
    "current_turn": null
  },
  "relevant_clocks": [],
  "secrets": [],
  "upcoming_events": []
}
DATA:JSON_END -->

---

## Scene Header

| Field | Value |
|-------|-------|
| **Scene ID** | [Generated] |
| **Location** | [Name] |
| **Region** | [terrain type] |
| **Threat Level** | X/5 |
| **Scene Type** | [exploration/travel/social/danger_zone/safe_zone] |
| **Encounter Type** | [clear/combat/social/environmental/discovery] |

---

## Time & Conditions

| Field | Value |
|-------|-------|
| **Day** | X |
| **Time** | HH:MM |
| **Time of Day** | [dawn/day/dusk/night] |
| **Weather** | [clear/overcast/rain/fog/storm] |
| **Lighting** | [daylight/dim/dark] |

---

## Scene Description

*[Generated from atmosphere data. 2-3 sentences. What the player sees/hears/smells.]*

**You hear:** [From atmosphere.sound]

**You smell:** [From atmosphere.smell]

**You see:** [From atmosphere.sight]

---

## Zones

| Zone | Name | Properties | Hazard | Occupants |
|------|------|------------|--------|-----------|
| A | — | — | — | — |
| B | — | — | — | — |
| C | — | — | — | — |
| D | — | — | — | — |

### Zone Distance Matrix

|   | A | B | C | D |
|---|---|---|---|---|
| **A** | — | Xm | Xm | Xm |
| **B** | Xm | — | Xm | Xm |
| **C** | Xm | Xm | — | Xm |
| **D** | Xm | Xm | Xm | — |

---

## Present NPCs

*Reference world-state for full details. Only ID and current disposition here.*

| Name | Faction | Disposition | Zone | Activity |
|------|---------|-------------|------|----------|
| *None* | — | — | — | — |

---

## Enemies

*Pre-load stats BEFORE combat starts. Generate via:*
```bash
python emergence_cli.py creatures --level X --difficulty [easy/medium/hard/deadly] --region [region]
```

| Enemy | Lv | Threat | HP | Armor | DEF | ATK | DMG | Init | Zone |
|-------|-----|--------|-----|-------|-----|-----|-----|------|------|
| *None* | — | — | —/— | — | — | +— | — | — | — |

### Enemy Details

<!--
For each enemy, record from generation output:

### [Enemy Name]
**Level:** X | **Threat:** [minion/standard/elite/boss]
**HP:** X/X | **Armor:** X | **DEF:** X | **ATK:** +X | **DMG:** X
**Initiative:** X | **Movement:** Xm | **Actions/Turn:** X

**Behavior:** [From behavior.pattern]
**Intelligence:** X ([mindless/bestial/cunning/intelligent/genius])

**Abilities:**
- [Ability Name]: [Effect]

**Encounter Context:**
- Activity: [What they were doing when players arrived]
- Mood: [Current emotional/behavioral state]
- Problem: [Something affecting their behavior]
- Complication: [Hidden factor that may emerge]

**Telegraphed Action:** [What they're about to do next turn]
-->

---

## Objects of Interest

| Object | Check | Result |
|--------|-------|--------|
| *None* | — | — |

---

## Combat State

| Field | Value |
|-------|-------|
| **Status** | Not in combat |
| **Round** | — |
| **Current Turn** | — |
| **Phase** | — |

### Initiative Order

| Order | Name | Roll | Status |
|-------|------|------|--------|
| — | — | — | — |

---

## Relevant Clocks

*Clocks that may affect or be affected by this scene.*

| Clock | Owner | Progress | Effect on Scene |
|-------|-------|----------|-----------------|
| — | — | ○○○○○○ 0/X | — |

---

## Secrets (GM Only)

*Hidden information revealed by investigation or events.*

| Type | Content | Reveal Trigger |
|------|---------|----------------|
| — | — | — |

---

## Upcoming Events

*What happens if players wait or take specific actions.*

| Trigger | Event |
|---------|-------|
| — | — |

---

## Combat Display Template

*Copy this block when combat is active. Update each turn.*

```
## Combat — Round X | [Name]'s Turn

**Stance:** [Stance] | **AP:** X/X | **RP:** X/X | **Move:** Xm remaining
**HP:** X/X ([state]) | **Stamina:** X/X | **Mana:** X/X
**Conditions:** [None or list]
**Zone:** [Current zone] — [Zone properties]

### Enemies

| Enemy | HP | DEF | ATK | DMG | Zone | Telegraphed |
|-------|-----|-----|-----|-----|------|-------------|
| [Name] (Lv X [threat]) | X/X | X | +X | X | [Zone] | [Next action hint] |

### Zone Map

- **A** ([Name]): [Occupants] | [Properties] | [Hazard if any]
- **B** ([Name]): [Occupants] | [Properties]
- **C** ([Name]): [Occupants] | [Properties]
- **D** ([Name]): [Occupants] | [Properties]

### Initiative Order

1. [Name] (X) ← CURRENT
2. [Name] (X)
3. [Name] (X)

### Available Actions

**Movement** (1 AP): Up to Xm. Current zone → Adjacent zones.
**Attack** (1 AP): +X vs DEF, Xd6+X damage
**[Technique Name]** (X AP, X Stamina): [Effect summary]
**Defend** (1 AP): +2 DEF until your next turn
**Change Stance** (Free): Switch to different stance

---

**What do you do?**
```

---

<!--
=== SCENE GENERATION INSTRUCTIONS ===

Generate scene via:
```bash
cd /mnt/skills/user/emergence-rpg/scripts
python emergence_cli.py scene \
  --location "[Name]" \
  --region [region] \
  --threat-level [1-5] \
  --player-level [level] \
  --world-json '[JSON from world-state]'
```

Then:
1. Parse output JSON
2. Populate all sections from data
3. Write atmospheric description from atmosphere fields
4. If combat encounter, generate enemies immediately
5. Update JSON block with full scene data

=== SCENE UPDATE INSTRUCTIONS ===

During scene:
1. COMBAT START: Generate enemies, set combat_state.active=true, roll initiative
2. COMBAT TURN: Update HP, conditions, zones, current_turn
3. ENEMY DEFEAT: Remove from enemies list, update HP to 0
4. NPC INTERACTION: Update disposition in NPC table
5. OBJECT INTERACTION: Mark as used/searched

On SCENE CHANGE:
1. DO NOT UPDATE this artifact
2. Generate entirely new scene
3. REPLACE this artifact completely

ALWAYS update both the JSON block AND the markdown section.
-->
