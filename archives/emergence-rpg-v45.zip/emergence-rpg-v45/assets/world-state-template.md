# EMERGENCE: THE EXILE — WORLD STATE

**Version:** 4.3  
**Purpose:** Campaign-level persistent state. Single source of truth for factions, clocks, NPCs, and chronicle.

---

<!--
=== MACHINE-READABLE STATE ===
The JSON block below is the authoritative data. Markdown sections are for human reading.
When updating, modify BOTH the JSON and the corresponding markdown section.

To extract JSON programmatically:
1. Find content between DATA:JSON_START and DATA:JSON_END
2. Parse as JSON
-->

<!-- DATA:JSON_START
{
  "version": "4.3",
  "campaign": {
    "name": "Emergence: The Exile",
    "start_date": "2025-01-01",
    "current_day": 1,
    "current_time": "14:47",
    "current_location": "Starting Location"
  },
  "meters": {
    "entropy": 50,
    "momentum": 30,
    "connection": 0
  },
  "human_factions": [],
  "external_threats": [],
  "meta_clocks": [],
  "faction_relationships": [],
  "known_npcs": [],
  "known_locations": [
    {
      "id": "loc_start",
      "name": "Starting Location",
      "region": "urban",
      "threat_level": 1,
      "discovered_day": 1,
      "notes": ""
    }
  ],
  "active_quests": [],
  "chronicle": [
    {
      "day": 1,
      "time": "14:47",
      "event": "Transit occurs. NYC transported to Vaelithar. 8.4M people. Two moons visible.",
      "significance": "critical",
      "tags": ["transit", "worldchange"]
    }
  ],
  "clock_log": [],
  "world_pulse": {
    "day": 1,
    "news": "The Transit. NYC arrives in Vaelithar.",
    "rumors": [],
    "trends": [],
    "arrivals": []
  }
}
DATA:JSON_END -->

---

## Campaign Info

| Field | Value |
|-------|-------|
| **Campaign Name** | Emergence: The Exile |
| **Start Date** | [Real-world date] |
| **Current Day** | 1 |
| **Current Time** | 14:47 |
| **Current Location** | [Location name] |

---

## Hidden Meters (GM Reference)

These meters influence scene generation and faction behavior.

| Meter | Current | Range | Effect |
|-------|---------|-------|--------|
| **Entropy** | 50 | 0-100 | Chaos/danger level |
| **Momentum** | 30 | 0-100 | Story pace |
| **Connection** | 0 | -100 to +100 | Political footprint |

### Entropy Effects
| Range | State | Effects |
|-------|-------|---------|
| 0-30 | Stable | Normal encounters, factions cooperative |
| 31-60 | Tense | +25% encounters, faction suspicion |
| 61-80 | Dangerous | +50% encounters, faction conflicts |
| 81-100 | Critical | Catastrophic events, survival priority |

---

## Human Factions

**Generated at session zero via:** `python emergence_cli.py session-zero`

<!-- FACTION_TABLE_START -->
| Faction | Archetype | Goal | Territory | Clock | Power |
|---------|-----------|------|-----------|-------|-------|
| *Run session-zero to generate* | — | — | — | — | — |
<!-- FACTION_TABLE_END -->

### Faction Details

<!-- 
TEMPLATE FOR EACH FACTION (copy and fill from session-zero output):

### [Faction Name]
**ID:** faction_XXXXX
**Archetype:** [authority/military/trade/knowledge/faith/criminal/commune/scavenger/tech/hunters]
**Goal:** [What they're trying to achieve]
**Method:** [How they pursue it]
**Territory:** [Where they operate]
**Resources:** [What they have]
**Power Level:** X/5

**Internal Crisis:** [From faction_dynamics]
**Legitimacy Source:** [From faction_dynamics]

**Clock:** [Name] ○○○○○○ 0/X
**On Completion:** [What happens when clock fills]

**Key NPCs:**
- [Role]: TBD (generate when encountered)
- [Role]: TBD
- [Role]: TBD

**Situation Tags:**
- [Tag]: [Description]

**Player Standing:**
- Reputation: Unknown (0/6)
- Rank: None

**Notes:**
[Faction-specific notes, history with player]
-->

---

## External Threats

**Generated at session zero via:** `python emergence_cli.py session-zero`

<!-- THREAT_TABLE_START -->
| Threat | Type | Region | Goal | Clock | Level |
|--------|------|--------|------|-------|-------|
| *Run session-zero to generate* | — | — | — | — | — |
<!-- THREAT_TABLE_END -->

### Threat Details

<!--
TEMPLATE FOR EACH THREAT (copy and fill from session-zero output):

### [Threat Name]
**ID:** threat_XXXXX
**Type:** [empire/horde/swarm/predator/corruption/undead/cult/elemental]
**Region:** [Primary operating area]
**Goal:** [What they want]
**Method:** [How they act]
**Approach:** [Behavioral pattern]
**Creature Types:** [Associated creature types]
**Threat Level:** X/5

**Clock:** [Name] ○○○○○○ 0/X (hidden: yes/no)
**On Completion:** [Catastrophic effect when clock fills]

**Notes:**
[Threat-specific notes, player encounters]
-->

---

## Faction Relationships

| Faction A | Faction B | Complication |
|-----------|-----------|--------------|
| *Generated at session zero* | — | — |

---

## Meta Clocks

World-level events that affect everything.

| Clock | Progress | Max | Description | On Completion |
|-------|----------|-----|-------------|---------------|
| The Stirring | ○○○○○○○○○○○○ | 12 | Something ancient awakens | The Hollow King stirs. Massive undead escalation. |
| Winter Comes | ○○○○○○○○ | 8 | First winter in Vaelithar | Winter arrives. Resource scarcity. Clocks accelerate. |

---

## Clock Advancement Log

**Every clock tick MUST be recorded here.**

| Day | Clock | Change | New Value | Reason |
|-----|-------|--------|-----------|--------|
| — | — | — | — | *No ticks yet* |

---

## Known NPCs

**Single source of truth for all NPCs.** Scene documents reference by ID only.

<!-- NPC_TABLE_START -->
| ID | Name | Faction | Role | Disposition | Status | Last Seen |
|----|------|---------|------|-------------|--------|-----------|
| — | *None yet* | — | — | — | — | — |
<!-- NPC_TABLE_END -->

### NPC Details

<!--
TEMPLATE FOR EACH NPC (add when generated or encountered):

### [NPC Name]
**ID:** npc_XXXXX
**Faction:** [Name or Independent]
**Role:** [Their function]
**Disposition:** [hostile/wary/neutral/friendly/allied]
**Status:** [active/missing/dead/unknown]

**Traits:** [personality trait], [personality trait]
**Motivation:** [What drives them]
**Secret:** [Hidden agenda or knowledge, if any]

**Character Tags:**
- [Tag Key]: [Description]

**Ambition:** [Active goal]
**Dread:** [Active fear]
**Leverage:** [How to influence them]

**Last Seen:** Day X, [Location]
**Notes:**
[Interaction history, relevant details]
-->

---

## Known Locations

| ID | Name | Region | Threat Level | Discovered | Notes |
|----|------|--------|--------------|------------|-------|
| loc_start | Starting Location | urban | 1 | Day 1 | Initial position |

---

## Active Quests

| Quest | Giver | Status | Deadline | Objectives |
|-------|-------|--------|----------|------------|
| *None* | — | — | — | — |

---

## Chronicle

**Terse entries. One line per significant event.**

| Day | Time | Event | Significance | Tags |
|-----|------|-------|--------------|------|
| 1 | 14:47 | Transit occurs. NYC transported to Vaelithar. | Critical | #transit #worldchange |

---

## World Pulse

**Updated EVERY scene transition. Delete old, write new.**

### World Pulse — Day 1, 14:47

**News:** The Transit. New York City has arrived in Vaelithar. Two moons hang in an unfamiliar sky.

**Rumors:**
- "Did you see those things in the park?" — Panicked survivor

**Trends:**
- Mass confusion ⧗ 1/4

**Arrivals:**
- Unknown creatures spotted at city edges

---

## Session Log

| Session | Date | Days Covered | Summary |
|---------|------|--------------|---------|
| 0 | [Date] | Day 1 | Session zero complete. World generated. |

---

## GM Notes

*Plot threads, future plans, reminders.*

- Clock pressure: Watch for clocks at 80%+
- Faction tensions: Note brewing conflicts
- Player hooks: Which factions might recruit?

---

<!-- 
=== ARTIFACT UPDATE INSTRUCTIONS ===

When UPDATING this artifact:

1. CLOCK TICK:
   - Update the clock's ○● display in the relevant section
   - Add entry to Clock Advancement Log
   - If completed, execute effect and add to Chronicle

2. NPC ENCOUNTER:
   - Add to NPC table if new
   - Update disposition/status if changed
   - Update "Last Seen" field

3. SCENE TRANSITION:
   - Update Current Location in Campaign Info
   - Update Current Time
   - Replace World Pulse section entirely
   - Tick 1-2 relevant clocks

4. FACTION INTERACTION:
   - Update Player Standing
   - Add to Notes section
   - Adjust relevant clock if significant

5. QUEST CHANGES:
   - Update Active Quests table
   - Add completion to Chronicle if resolved

ALWAYS update both the JSON block AND the markdown section.
-->
