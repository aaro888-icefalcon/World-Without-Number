# Named Locations

## NYC Zones

### THE VERGE (City interior, 0-2 miles from edge)
- Relatively safe; human-controlled
- **Locations:** City Hall, major hospitals, faction territories
- **Threats:** Human conflict, occasional incursion

### THE FRONTIER (City edge, 2-4 miles)
- Contested; monster incursions common
- **Locations:** Perimeter checkpoints, staging areas, ruined outer blocks
- **Threats:** Thornwolves, Grass Runners, human raiders

### THE WILDS (Beyond city, 4-10 miles)
- Dangerous; organized expeditions only
- **Locations:** Resource sites, indigenous contact points
- **Threats:** Regional creatures, territorial monsters

### THE REACHES (Beyond 10 miles)
- Extremely dangerous; unknown territory
- **Locations:** Dungeons, faction capitals
- **Threats:** Boss creatures, intelligent enemies

---

## Cardinal Direction Landmarks

### NORTH: THORNWOOD (3 miles)
- **Forest Edge:** First trees; marking boundary
- **The Twilight Zone:** Permanent shade under canopy
- **Thornwolf Territory:** Pack hunting grounds (marked by claw marks)
- **The Caller's Grove:** Thornwood Clan sacred site (do not approach)
- **Alpha Den:** Boss dungeon (Level 8+ party)

### SOUTH: HOLLOWVEIL (4 miles badlands, 15+ miles fog)
- **The Badlands:** Rocky terrain descending toward fog
- **The Fog Line:** Where permanent mist begins
- **Lost Expedition Markers:** Those who entered and didn't return
- **Cult Outposts:** Hollowveil worshipper camps
- **The Whispers:** Audible at fog's edge (do not follow voices)

### EAST: CRYSTALVELD (5 miles)
- **The Grass Sea:** Rolling grasslands with crystal formations
- **Silent Grazing Grounds:** Nomad territory (approach carefully)
- **Crystal Spires:** Veld Drake territory
- **The Resonance Caves:** 10+ miles east, 2000 ft depth (Elite dungeon, Level 12+)

### WEST: IRONSPINE MOUNTAINS (6 miles)
- **Lower Trails:** Relatively safe passages
- **Stone Bear Territories:** Marked (avoid)
- **Dweregar Trade Post:** Surface contact point
- **The Frozen Pass:** Only route over mountains
- **The Sealed Mine:** Dweregar forbid entry (The Deep below)

---

## Intercardinal Landmarks

### NORTHEAST: DELTA (8 miles)
- **The River Junction:** Where waters meet
- **Market Boats:** Rivermen trading posts
- **The Marsh:** Dangerous; creatures lurk

### NORTHWEST: SUNDERING FIELDS (12 miles)
- **The Dead Zone:** Nothing grows; death magic saturates
- **Risen Patrols:** Undead active at night
- **The Command Post:** Elite dungeon (Level 10+) — Ancient weapons, historical knowledge
- **The Binding Site:** Where Hollow King was bound (do not approach)

### SOUTHEAST: CRYSTAL CAVES / KAELTHARI (10/18 miles)
- **Cave Entrance:** 10 miles; leads to Resonance Heart
- **Kaelthari Forward Camp:** 18 miles; ~200 soldiers, slaves, mages

### SOUTHWEST: EXILE CAMPS (15 miles)
- **Warlord's Hold:** Keth the Oathless's fortress
- **Scholar's Refuge:** Truthseeker territory
- **The Changed Quarter:** Hollow-Touched area (strange transformations)
- **Market of Last Resort:** Anything for sale (at a price)
- **The Sealed Gate:** Endgame location — Hollow King's binding

---

## Dungeons and Special Locations

| Location | Distance | Level | Reward |
|----------|----------|-------|--------|
| Boundary Wurm's Lair | Eastern city edge | 5+ party | Core Stone, massive resources |
| Alpha Thornwolf Den | Deep Thornwood | 8+ party | Pack control collapse, rare materials |
| Veld Drake Spire | 15 miles east | 8+ OR negotiate | Alliance or legendary loot |
| Sundering Command Post | 20 miles NW | 10+ party | Ancient weapons, historical knowledge |
| Resonance Heart | Crystal Caves, 2000 ft | 12+ party | Pure crystal core, Deep hints |
| The Sealed Gate | 30 miles SW | Endgame | Hollow King's binding |
| Memory Vaults | Aelthri Sanctuary | Invitation only | Transit answers, history |
| Dweregar Deep Hold | Ironspine depths | Trade access only | Master-forged equipment |

---

## Distance Reference

| Destination | Distance | Travel Time (foot) |
|-------------|----------|-------------------|
| Thornwood edge | 3 miles | 1-2 hours |
| Hollowveil badlands | 4 miles | 2-3 hours |
| Crystalveld grasslands | 5 miles | 2-4 hours |
| Ironspine foothills | 6 miles | 3-5 hours |
| Delta region | 8 miles | 4-6 hours |
| Crystal Caves | 10 miles | 1 day |
| Sundering Fields | 12 miles | 1-2 days |
| Exile Camps | 15 miles | 2-3 days |
| Kaelthari Camp | 18 miles | 3-4 days |
| Aelthri Sanctuary | 40+ miles | 1+ week |
