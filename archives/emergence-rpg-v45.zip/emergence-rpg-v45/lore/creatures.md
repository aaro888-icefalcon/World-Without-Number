# Creature Threat Profiles

**Threat Levels:** T=Trivial | L=Low (1-3) | M=Moderate (1-5 party) | H=High (5-10 party) | E=Extreme | B=Boss

Use: `grep -i "creature_name" lore/creatures.md` to find specific entries.

---

## THORNWOOD (North, 3 miles)

### THORNWOLF | M | Pack 5-12
HP: 25-35 | Dmg: 6-10 + poison
- Thorn-pelted pack hunters. Test before commit; retreat if bloodied.
- **Fear fire. Won't enter open ground.**
- Loot: Pelts (15-25), Fangs (5-10), Rare: Alpha's Fang (50)

### GLOOM STALKER | M-H | Solitary
HP: 45-60 | Dmg: 12-18 or 8-12+bleed
- Ambush predator with heat-sense. Strikes from above.
- **Avoids groups of 4+. Patient.**
- Loot: Hide (40-60), Eyes (20), Rare: Shadow Core (200)

### CREEPING VINES | L-M | Patch 10m²
Dmg: 4/round + Restrained
- Semi-animate plant trap. Sweet rotting smell warns.
- **Instant-killed by fire.**
- Loot: Vine Sap (5/flask), Seeds (15)

### MOSS HULK | M-H | Solitary
HP: 80-100 | Dmg: 15-25
- Shambling plant-creature. Regenerates 5 HP/round.
- **Fire stops regeneration. Territorial.**
- Loot: Heart-Root (60), Moss (20)

### SHADOW PANTHER | H | Solitary/pair
HP: 70-90 | Dmg: 18-24
- Phase-shifting predator. Can become incorporeal briefly.
- **Hunts at twilight. Fears bright light.**
- Loot: Phase Gland (100), Pelt (80)

### FOREST TROLL | H | Solitary
HP: 120-150 | Dmg: 22-32
- Regenerating brute (10 HP/round). Dumb but dangerous.
- **Only fire/acid stops regeneration.**
- Loot: Troll Blood (80), Hide (60)

### VERDANT WARDEN | E | Solitary
HP: 200+ | Dmg: 30-45
- Intelligent plant guardian. Protects sacred groves.
- **Can command lesser plants. May negotiate.**
- Loot: Warden Heart (300), Sacred Wood (200)

---

## CRYSTALVELD (East, 5 miles)

### GRASS RUNNER | M | Pack 8-15
HP: 20-30 | Dmg: 5-8 + trip
- Six-legged pursuit predator. Alpha coordinates.
- **Won't enter forest. Kill alpha = scatter.**
- Loot: Hides (10), Rare: Alpha Crest (30)

### CRYSTAL WASP | L-M | Swarm 50-200
Swarm HP: 80-150 | Dmg: 2-4/10 + mana drain
- Mana-burning stings. Defend nest 30m radius.
- **Dormant at night/cold. Fire kills.**
- Loot: Crystal Honey (30/flask), Queen Gland (100)

### THUNDER GRAZER | Hazard | Herd 20-100
HP: 150-200 each | Dmg: 25-40 trample
- Massive herbivore. Docile until startled.
- **Stampede = environmental disaster.**
- Loot: Meat (50+ days), Hide (80), Horn (40), Rare: Thunder Stone (200)

### GLASS VIPER | L-M | Solitary
HP: 15-25 | Dmg: 4-6 + crystal poison
- Nearly invisible snake. Venom causes crystallization spreading from wound.
- **Antivenom from Silent only.**
- Loot: Venom (50), Scales (20)

### VELD STALKER | M-H | Solitary
HP: 55-70 | Dmg: 14-20
- Camouflaged grass-colored predator. Patient ambusher.
- **Lies in wait for days.**
- Loot: Camo Hide (70), Claws (25)

### CRYSTAL GOLEM | H | Solitary
HP: 100-140 | Dmg: 20-28
- Animated crystal formation.
- **Immune to piercing/slashing. Vulnerable to sonic, bludgeoning.**
- Loot: Crystal Core (120), Fragments (60)

### VELD DRAKE | H-E | Solitary territorial
HP: 120-160 | Dmg: 20-30 + breath
- Dragon-kin claiming crystal spires. Lightning breath.
- **Intelligent. May negotiate.**
- Loot: Scales (100), Lightning Gland (120)

### CRYSTAL HORROR | E | Solitary
HP: 180-220 | Dmg: 28-40
- Massive crystal-encrusted predator. Fires crystal shards.
- **Absorbs mana attacks.**
- Loot: Horror Core (250), Crystal Plates (150)

---

## HOLLOWVEIL (South, 4+ miles)

### ROCKJAW | M-H | Solitary/pair
HP: 60-80 | Dmg: 15-22 + grapple
- Burrowing ambusher. Stone hide (half slash/pierce).
- **Can't burrow in water/mud.**
- Loot: Stone Hide (100), Teeth (25), Tremor Gland (60)

### DUST DRAKE | M-H | Pack 3-6
HP: 35-50 | Dmg: 8-12 or breath 10-15
- Small fire-breathing dragon-kin. Dive attacks.
- **Vulnerable to cold. Sleep at night.**
- Loot: Scales (50), Fire Gland (80), Eggs (200)

### SHADOW CREEPER | M-H | Group 2-4
HP: 40-55 | Dmg: 12-18 + fear
- Hunts in darkness/shadow. Causes supernatural fear.
- **Bright light weakens.**
- Loot: Shadow Essence (60), Eyes (35)

### HOLLOW ONE | H | Solitary
HP: 80-100 | Dmg: 18-26 + drain
- Humanoid from the mist. Drains life on touch.
- **May have been person once. Speaks sometimes.**
- Loot: Hollow Essence (100), Echoes of Memory (valuable to some)

### MISTWALKER | H-E | Unknown
HP: 80-120 | Dmg: 18-25 + mana drain
- Fog creature sensing magic. Strike and vanish.
- **Strong light/wind weakens.**
- Loot: Fog Essence (300), Void Touch (500+)

---

## IRONSPINE (West, 6 miles)

### STONE BEAR | H | Solitary
HP: 120-160 | Dmg: 20-35 + knockdown
- Rock-hided apex predator. Territorial.
- **Warning roar. Fire causes retreat.**
- Loot: Stone Hide (150), Claws (40 each), Heart (100)

### FROST SPRITE | L-M | Swarm 10-30
HP: 5-10 each | Dmg: 3 + heat drain
- Heat-draining elemental. 3+ touches = Exhausted.
- **Fire instant-kills.**
- Loot: Sprite Essence (15 each), Frost Core (100/10)

### MOUNTAIN WOLF | M | Pack 6-10
HP: 30-40 | Dmg: 8-14
- Larger Thornwolf cousin. Better cold resistance. More aggressive.
- Loot: White Pelt (30), Fangs (15)

### ROCK ELEMENTAL | H | Solitary
HP: 100-140 | Dmg: 18-28
- Animated stone.
- **Immune to physical except bludgeon. Vulnerable to water erosion.**
- Loot: Earth Core (120), Ore (60)

### IRONCLAD WYRM | H-E | Solitary
HP: 140-180 | Dmg: 24-36
- Metallic-scaled serpent. Ambush in passes. Constricts.
- **Lightning empowers it.**
- Loot: Iron Scales (150), Wyrm Heart (200)

---

## UNDEAD (Sundering Fields, NW 12 miles)

### RISEN | L-M | Groups 3-12
HP: 15-25 | Dmg: 6-10
- Animated dead from ancient battle. Mindless aggression.
- **Active at night; dormant by day. Fire effective.**
- Loot: Ancient Equipment (variable), Bone Dust (10)

### DEATH KNIGHT | H-E | Solitary
HP: 100-140 | Dmg: 20-30 + life drain
- Intelligent undead commander. Raises fallen as Risen.
- **Commands other undead. Retains combat skills from life.**
- Loot: Soul Gem (200), Ancient Weapon (150)

### THE BOUND | E-B | Unknown
HP: ??? | Dmg: ???
- Something stirs at the Sundering Command Post.
- **Do not approach without preparation.**
