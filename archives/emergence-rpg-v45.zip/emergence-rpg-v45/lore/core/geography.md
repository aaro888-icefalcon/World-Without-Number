# Geography & Distances

## The Cardinal Directions

### NORTH: The Thornwood (3 miles)
- Primordial forest; trees 200+ feet tall
- Permanent twilight beneath canopy
- **Threats:** Thornwolves, Gloom Stalkers, Creeping Vines, Forest Trolls
- **Power:** Thornwood Clans (~800,000 isolationist humanoids)
- **Warning:** FIRE causes instant hostility—forest terror response

### SOUTH: The Hollowveil Descent (4 miles to badlands, 15 miles to fog)
- Rocky badlands descending to permanent magical fog
- **Threats:** Rockjaws, Dust Drakes, Carrion Wings, Hollow Ones, Mistwalkers
- **Power:** Hollowveil Cult (mysterious, dangerous)
- **Warning:** The fog is lethal—no confirmed returns from deep fog

### EAST: The Crystalveld (5 miles)
- Rolling grasslands with crystalline formations
- **Threats:** Grass Runners, Crystal Wasps, Thunder Grazers, Veld Drakes
- **Power:** The Silent (~300,000 nomadic humanoids)
- **Resource:** Crystals (mana-charged, valuable)

### WEST: The Ironspine Mountains (6 miles)
- Snow-capped peaks, forested slopes, extensive cave systems
- **Threats:** Mountain Wolves, Stone Bears, Frost Sprites, Ironclad Wyrms
- **Power:** Dweregar Holds (~4 million underground smiths)
- **Resource:** Metal, crafted goods (if you can trade for them)

---

## Intercardinal Directions

| Direction | Distance | Feature |
|-----------|----------|---------|
| **Northeast** | 8 miles | Delta/River confluence; Rivermen territory |
| **Northwest** | 12 miles | Sundering Fields; undead, ancient battlefield |
| **Southeast** | 10 miles caves, 18 miles camp | Crystal Caves; Kaelthari forward camp |
| **Southwest** | 15 miles | Exile Camps; outcasts, marchers, criminals |

---

## Distance Reference Table

| Destination | Distance from NYC |
|-------------|-------------------|
| Thornwood edge | 3 miles |
| Hollowveil badlands | 4 miles |
| Crystalveld | 5 miles |
| Ironspine foothills | 6 miles |
| River Delta | 8 miles |
| Crystal Caves | 10 miles |
| Sundering Fields | 12 miles |
| Exile Camps | 15 miles |
| Hollowveil fog line | 15 miles |
| Kaelthari Camp | 18 miles |
| Aelthri Sanctuary | 40 miles |

---

## Travel Times

| Journey | On Foot | Notes |
|---------|---------|-------|
| Within NYC | 1-4 hours | Depending on district |
| To wilderness edge | 4-8 hours | Thornwood, Crystalveld |
| Per 10 wilderness miles | 1-3 days | Terrain dependent |
| To Kaelthari Camp | 3-5 days | If unmolested |
| To Exile Camps | 2-4 days | Dangerous route |

---

## Zone System

### The Verge (0-2 miles from city edge)
- Mixed urban/wilderness
- Monster incursions common
- Human patrols active
- **Encounter modifier:** +2

### The Frontier (2-5 miles)
- True wilderness begins
- Established monster territories
- Few human outposts
- **Encounter modifier:** +0

### The Wilds (5-15 miles)
- Deep wilderness
- Apex predator territory
- Indigenous power territories
- **Encounter modifier:** -2

### The Reaches (15+ miles)
- Far territories
- Major power strongholds
- Legendary threats
- **Encounter modifier:** -4

---

## NYC Internal Geography

### Borough Status Post-Transit

| Borough | Population | Status |
|---------|------------|--------|
| Manhattan | 1.6M | Contested core; faction warfare |
| Brooklyn | 2.6M | Fragmented; neighborhood control |
| Queens | 2.3M | Isolated enclaves; poor coordination |
| Bronx | 1.4M | Northern frontier; Thornwood pressure |
| Staten Island | 0.5M | Cut off; minimal contact |

### Key NYC Locations

**Verge Zone (City Edge):**
- Eastern Waterfront — First crystal sightings
- Bronx North — Thornwood incursion zone
- Southern Tip — Hollowveil watchers
- Western Shore — Mountain visibility

**Core Zone:**
- City Hall — Provisional Authority HQ
- Financial District — Exchange territory
- Major Hospitals — Remnant strongholds
- Perimeter Checkpoints — Sentinel posts

---

## Terrain Properties

| Terrain | Movement Cost | Properties |
|---------|---------------|------------|
| Urban (intact) | Normal | Cover abundant |
| Urban (ruined) | +50% | Difficult, hazardous |
| Forest (Thornwood) | +100% | Dim light, ambush risk |
| Grassland (Crystalveld) | Normal | Open, visible |
| Badlands (Hollowveil) | +50% | Rocky, elevation changes |
| Mountains (Ironspine) | +100% | Elevation, weather |
| Caves | +50% | Dark, confined |

---

## Environmental Hazards

| Hazard | Location | Effect |
|--------|----------|--------|
| Thornwood canopy | Forest | Permanent dim light |
| Crystal resonance | Crystalveld | Mana interference possible |
| Death magic residue | Sundering Fields | Undead spawn, corruption |
| Hollowveil fog | Deep south | Disorientation, Hollow transformation |
| Mountain cold | Ironspine heights | Cold damage, exhaustion |
| Urban collapse | Damaged buildings | Cave-in risk |
