# Powers Overview

## At-a-Glance Reference

### NYC Human Factions (Major)

| Faction | Strength | Territory | Disposition |
|---------|----------|-----------|-------------|
| **Provisional Authority** | ~200 loyal | City Hall | Claims legitimacy |
| **The Sentinels** | ~500 armed | Perimeter, armories | Defensive |
| **The Exchange** | ~300 employees | Financial District | Mercantile |
| **The Harvesters** | ~150 capable | Eastern staging | Expansionist |
| **The Remnant** | ~100 medical | Hospitals | Protective |
| **The Pack** | ~80, half awakened | Lower Manhattan | Predatory |

### NYC Human Factions (Community)

| Faction | Strength | Territory |
|---------|----------|-----------|
| Harlem Council | ~2,000 | North of 110th |
| Chinatown Collective | ~800 | Chinatown proper |
| Washington Heights Defenders | ~1,500 | Heights, Inwood |
| Brooklyn Bridge Authority | ~60 armed | Bridge, approaches |
| Village Commune | ~400 | Greenwich Village |
| Midtown Towers Syndicate | ~200 residents | Luxury buildings 40th-60th |

### Indigenous Powers

| Power | Population | Distance | Disposition |
|-------|------------|----------|-------------|
| **The Silent** | ~300K | 5+ miles E | Observing |
| **Thornwood Clans** | ~800K | 3+ miles N | Isolationist |
| **Dweregar Holds** | ~4M | 6+ miles W | Isolationist |
| **Rivermen** | Unknown | 8+ miles NE | Pragmatic |
| **Kaelthari Dominion** | 30M (200+ at camp) | 18 miles SE | Evaluating |
| **Steppen Khanate** | ~10M | Far east | Observing |
| **Marchers** | ~600K | 15+ miles SW | Hopeful |
| **Aelthri Remnant** | ~150K | 40+ miles | Melancholy |

### Distant Powers (Reference)

| Power | Population | Notes |
|-------|------------|-------|
| Shattered Realm | ~22M | Human kingdom in civil war |
| Free Cities | ~3M | Neutral traders, slave market |

---

## Faction Quick Reference

### THE SILENT (~300K) — Grassland Nomads
- **Disposition:** Observing
- **Key Figures:** Drift-Walker Shen, Hunt-Master Voss
- **Wants:** Respect, trade, information about Transit
- **Fears:** Kaelthari expansion, disruption of balance
- **Cultural Note:** Silence, stillness valued; salt = 3-day bond

### THORNWOOD CLANS (~800K) — Forest Dwellers
- **Disposition:** Isolationist
- **Key Figures:** Caller Aethen, Elder Root
- **Wants:** To be left alone
- **Fears:** FIRE (absolute terror), deforestation
- **Cultural Note:** Never start fire in forest; greet the forest itself

### KAELTHARI DOMINION (200+ at camp) — Scaled Empire
- **Disposition:** Evaluating
- **Key Figures:** Commander Kethras, Magister Vaelketh, Slave-Master Thessik
- **Wants:** Submission, alliance, or at minimum non-interference
- **Fears:** NYC allying with Khanate or Marchers
- **Cultural Note:** Slavery is normal; cold is weakness; show no fear

### DWEREGAR HOLDS (~4M) — Underground Smiths
- **Disposition:** Isolationist
- **Key Figures:** Foreman Kraddock, Deep-Warden Vorn
- **Wants:** Trade for surface goods
- **Fears:** Digging without permission, The Deep
- **Cultural Note:** Never touch their tools; announce at threshold

### RIVERMEN CONFEDERATION — Delta Traders
- **Disposition:** Pragmatic
- **Key Figures:** Grandmother Vessels, Captain Marsh
- **Wants:** Trade, river access
- **Fears:** Water pollution, violence
- **Cultural Note:** Wave from shore; no violence on Market; no lies about goods

### STEPPEN KHANATE (~10M) — Horse Lords
- **Disposition:** Observing
- **Key Figures:** Khan Temur the Patient
- **Wants:** Military alliance against Kaelthari
- **Fears:** NYC weakness, alliance with Kaelthari
- **Cultural Note:** Hospitality sacred; oaths binding unto death

### MARCHERS (~600K) — Escaped Slaves
- **Disposition:** Hopeful
- **Key Figures:** Marshal Vera Chainbreaker
- **Wants:** Alliance against Kaelthari, rescue of captured slaves
- **Fears:** NYC tolerating slavery
- **Cultural Note:** Will judge NYC by stance on slavery—no neutrality possible

### AELTHRI REMNANT (~150K) — Fading Ancients
- **Disposition:** Melancholy
- **Key Figures:** Vaelindra, Thessaly the Chronicler
- **Wants:** Understanding, perhaps help
- **Fears:** Further decline
- **Cultural Note:** Ancient, wise, declining; may know Transit truth

---

## Faction Relationship Matrix

### Allies / Friendly
- Marchers ↔ Khanate (anti-Kaelthari)
- Marchers ↔ Free Cities (trade, support)
- Silent ↔ Khanate (distant respect)

### Enemies / Hostile
- Kaelthari ↔ Marchers (slaves vs freed)
- Kaelthari ↔ Khanate (centuries of war)
- Thornwood ↔ Anyone who uses fire

### Neutral / Transactional
- Dweregar ↔ Everyone (trade only)
- Free Cities ↔ Everyone (profit)
- Rivermen ↔ Everyone (trade)

---

## Faction Triggers

| Action | Consequence |
|--------|-------------|
| Ally with Kaelthari | Silent, Marchers, Khanate become hostile |
| Strike Kaelthari | Silent, Marchers, Khanate improve |
| Free slaves | Marchers favor, Kaelthari hostile |
| Fire in Thornwood | Immediate Thornwood hostility |
| Dig in mountains without permission | Dweregar hostile |
| Break Dweregar contract | Permanent enemy |
| Violate Silent hospitality | Known to all Silent within week |

---

## Starting Clocks

| Clock | Progress | Description |
|-------|----------|-------------|
| City Consolidation | 0/8 | Human organization progress |
| Kaelthari Assessment | 0/6 | When they make their move |
| Monster Pressure | 0/4 | Next major incursion |
| Resource Depletion | 0/6 | Critical shortages |
| Feudal Emergence | 0/10 | Anarchy → territorial control |
| First Contact | 0/4 | Formal meeting with indigenous |
| The Stirring | 0/12 | Hollow King awakening (HIDDEN) |
