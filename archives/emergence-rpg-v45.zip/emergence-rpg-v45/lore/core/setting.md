# Core Setting

## The Transit — What Happened

**ONE-LINE:** New York City was torn from Earth and deposited into Vaelithar.

### Immediate Consequences
- All electronics failed instantly and PERMANENTLY
- Vehicles with circuits dead; purely mechanical devices work
- Subways became tombs; elevators froze; hospitals lost power
- Communication reduced to shouting distance
- Food spoilage began immediately (no refrigeration)
- The System awakened in every human mind

### What Everyone Knows
- Electronics are dead—permanently
- The geography is wrong
- Something called "The System" appeared as a visible screen
- Creatures are appearing at the city's edges
- Some people are manifesting powers

---

## The System — What It Does

**ONE-LINE:** Neutral-evil intelligence administering reality through selective pressure.

The System is an intelligence administering reality. It emerged when the Transit occurred. It manifests as a translucent screen visible only to each individual—semi-transparent, blue-white luminescent text on dark backing.

### The Three Laws

1. **STAGNATION IS DEATH** — Those who stay safe too long attract danger
2. **RISK PURCHASES POWER** — Reward scales with danger voluntarily accepted
3. **SCARCITY BREEDS POLITICS** — Critical resources are finite; cooperation, trade, or war are the only paths forward

### System Behavior
- Observes all actions and measures growth
- Rewards risk and punishes stagnation
- Remains indifferent to individual survival
- Accelerates evolution through selective pressure
- Communicates through visible screen displays when mechanics trigger
- Generates appropriate options based on player's unique path

---

## The World: Vaelithar

The world is called **Vaelithar** ("The Living Land") by its indigenous peoples.

- Single massive continent surrounded by ocean
- Magically saturated; mana flows through ley lines
- Dozens of sapient species with varying civilizations
- Currently stable after a cataclysmic war 800 years ago

---

## The Korveth Plateau — Why Here

**ONE-LINE:** NYC landed on cursed, uninhabitable highland that no one claims.

### Why No One Lives Here
- Site of the Sundering War's worst battle (800 years ago)
- Monster density exceeds anywhere else on the continent
- Residual death magic saturates the soil
- Undead walk the northern fields
- Every civilization that tried to settle failed

### Population Context

| Power | Population |
|-------|------------|
| Kaelthari Dominion | ~30M |
| Shattered Realm | ~22M |
| Steppen Khanate | ~10M |
| **NYC Humans** | **8.4M** |
| Dweregar Holds | ~4M |
| Free Cities | ~3M |
| Thornwood Clans | ~800K |
| Marchers | ~600K |
| The Silent | ~300K |
| Aelthri Remnant | ~150K |

---

## The Opening

The world ends at 2:47 PM on a Tuesday.

No warning. No explanation. One moment ordinary life, the next—

Light. Everywhere. A pressure behind your eyes, in your teeth, in your bones. The ground lurches. Glass shatters. Someone screams.

When vision clears, still in New York. But New York is no longer on Earth.

Through the gaps in the skyline, where New Jersey should be: mountains. Actual mountains, snow-capped and massive, impossibly close. The Hudson has become rapids cutting through ancient forest. And the sky—two moons, one silver and one pale green, hanging in broad daylight.

Then the screen appears.

```
╔═══════════════════════════════════════════════════════════════════╗
║  TRANSIT COMPLETE                                                  ║
║  DESIGNATION: EARTH-NYC-8.4M                                       ║
║  STATUS: INTEGRATION PENDING                                       ║
║                                                                    ║
║  WELCOME TO THE SYSTEM                                             ║
║                                                                    ║
║  BIOLOGICAL ASSESSMENT REQUIRED                                    ║
║  COMMENCING...                                                     ║
╚═══════════════════════════════════════════════════════════════════╝
```

The chaos continues. Screams. Car alarms (for a few seconds, then they die with everything electronic). People running. Something roaring in the distance—something that doesn't sound like any animal from Earth.

But the screen demands attention.
