# NYC Ideological Factions

## THE CHURCH COALITION — Interfaith Survival Network

**Wants:** Spiritual guidance, humanitarian aid
**Fears:** Violence, loss of faith, despair spreading

### Key Figures
- **Archbishop O'Brien** — Catholic; senior religious leader
- **Imam Hassan** — Muslim; bridge-builder
- **Rabbi Goldman** — Jewish; practical organizer
- **Rev. Jackson** — Baptist; community connections

### Details
- **Territory:** Major religious buildings citywide
- **Strength:** ~50 clergy, thousands of congregants
- **Resources:** Sanctuary tradition, information network, moral authority, shelter

### Character
Interfaith cooperation born of crisis. Religious buildings as sanctuaries—even criminals mostly respect this. Church network provides communication across the city. Providing shelter and aid regardless of background. Struggling with theological questions about Transit.

### Hooks
- Sanctuary can protect anyone
- Information flows through congregations
- Moral authority can sway public opinion
- Theological interest in The System

---

## THE AWAKENED BROTHERHOOD — Power Supremacists

**Wants:** Awakened rule over mundanes
**Fears:** Mundane numbers, organized resistance, other awakened factions

### Key Figures
- **"Archon" Victor Cross** — Fire awakened; charismatic leader
- **"Prophet" Elise Moon** — Seer; provides "divine" justification
- **"Titan" Marcus Cole** — Strength awakened; enforcer

### Details
- **Territory:** Claimed tower in Midtown
- **Strength:** ~40 awakened members
- **Resources:** Concentrated awakened power, ideology

### Character
Believe awakening makes them inherently superior. Recruiting awakened aggressively with promises of power and purpose. Victor Cross has genuine charisma and fire powers. Elise Moon's visions provide religious justification. Growing threat that Sentinels are watching closely.

### Hooks
- Antagonist faction for awakened player
- Recruiting attempts on player
- Eventual confrontation likely
- May have genuine insights about awakening

---

## THE RECLAMATION — Techno-Optimists

**Wants:** Restore technology, understand Transit
**Fears:** Permanent regression, magic corruption

### Key Figures
- **Dr. Yuki Tanaka** — Physicist; leading researcher
- **Engineer Rajesh Patel** — Inventor; practical applications
- **"Spark"** — Possibly awakened tech affinity; uncertain

### Details
- **Territory:** Columbia University campus
- **Strength:** ~60 scientists, engineers, students
- **Resources:** Laboratory equipment, academic knowledge, research

### Character
Believe science can explain and possibly reverse the Transit. Experimenting with crystal-technology hybrids. "Spark" may be an awakened with technology affinity—they're studying him. Actually making progress on understanding why electronics failed.

### Hooks
- May have answers about Transit
- Crystal-tech hybrid research
- "Spark" is an interesting character
- Could restore some technology eventually?

---

## THE PURISTS — Anti-Awakening Movement

**Wants:** Reject System "corruption," preserve humanity
**Fears:** Awakening, losing human identity, System control

### Key Figures
- **Father Michael Stern** — Charismatic leader; former priest
- **Dr. Amanda Cross** — Theorist; believes awakening is mutation
- **"Clean" James** — Enforcer; violently opposed to awakened

### Details
- **Territory:** Staten Island fragment
- **Strength:** ~200 committed members
- **Resources:** Isolated territory, fervent belief

### Character
Believe awakening is corruption or damnation. Refuse to awaken themselves. Violent toward those who "embrace the mark." Staten Island isolation gives them a defensible territory. Father Stern is genuinely charismatic and believes absolutely.

### Hooks
- Antagonists for awakened players
- Staten Island is isolated—what's there?
- Dr. Cross may have insights about awakening biology
- Violence against awakened creates conflict

---

## THE NEW DAWN CULT — Transit Worshippers

**Wants:** Understand Transit's "divine purpose"
**Fears:** Missing the revelation, being wrong

### Key Figures
- **"The Voice"** — Anonymous leader; only heard, never seen
- **Sister Clarity** — Recruiter; compelling speaker
- **Brother Truth** — Enforcer; handles doubters

### Details
- **Territory:** Hidden meeting locations; move frequently
- **Strength:** ~150 members
- **Resources:** Fervent believers, hidden locations, growing membership

### Character
Believe Transit was divine intervention with a purpose. Seeking "purpose" through visions, meditation, and... concerning practices. The Voice speaks through intermediaries, never appears directly. Growing quickly as people seek meaning in chaos.

### Hooks
- May have genuine mystical insights
- Recruitment attempts
- What are the "concerning practices"?
- Who is The Voice really?

---

## Ideological Landscape

### Spectrum
```
REJECT SYSTEM ←——————————————→ EMBRACE SYSTEM
   Purists    Church    Neutral    Brotherhood    New Dawn
```

### Relationships
- **Church + Purists:** Tension (Stern was a priest)
- **Church + Brotherhood:** Opposition (power vs. humility)
- **Brotherhood + Purists:** Violent opposition
- **Reclamation + All:** Secular, focused on science
- **New Dawn + All:** Mysterious, recruiting from everyone

### Flashpoints
- What does awakening mean spiritually?
- Should awakened have authority over mundanes?
- Can/should the Transit be reversed?
- Is The System god, tool, or trap?

### Player Interaction
- Ideological factions want to recruit or convert
- Violence between factions creates opportunity
- Information about awakening/Transit scattered across groups
- Player's stance will have consequences
