# NYC Major Factions

## THE PROVISIONAL AUTHORITY — City Hall Remnants

**Wants:** Legitimacy, resource control
**Fears:** Irrelevance, rival powers

### Key Figures
- **Acting Mayor Chen** — Pragmatic survivor; trying to hold things together
- **Council President Williams** — Ambitious; sees opportunity in chaos
- **City Clerk Reyes** — Competent administrator; knows where everything is

### Details
- **Territory:** City Hall, surrounding blocks
- **Strength:** ~200 loyal staff and volunteers
- **Resources:** Paper authority, official records, some emergency supplies

### Disposition
Claims legitimate governmental authority. Struggling to be relevant when power comes from guns and awakening, not elections. Will trade legitimacy (official recognition, titles) for real power.

### Hooks
- Need muscle to enforce decisions
- Need information about what's happening outside
- Internal power struggle between Chen and Williams

---

## THE SENTINELS — Military/Police Coalition

**Wants:** Secure perimeter, chain of command
**Fears:** Ammunition exhaustion, awakened threats

### Key Figures
- **Captain Torres** — Rigid military officer; believes in hierarchy
- **Sgt Major Okafor** — Practical veteran; knows when to bend rules
- **Lt Park** — Awakened officer; torn between duty and new power

### Details
- **Territory:** Perimeter checkpoints, remaining armories
- **Strength:** ~500 armed and disciplined (mix of NYPD, National Guard, veterans)
- **Resources:** Weapons, ammunition (finite), training, discipline

### Disposition
Focused on defense. Suspicious of awakened not under their command. Will work with anyone who helps secure the perimeter. Desperate for ammunition solutions.

### Hooks
- Need scouts beyond perimeter
- Internal tension about awakened members
- Ammunition is running out—need alternatives

---

## THE EXCHANGE — Business Interests

**Wants:** Trade control, currency establishment
**Fears:** Total collapse, violence disrupting trade

### Key Figures
- **Marcus Sterling** — Ruthless financier; sees opportunity in chaos
- **Rosa Delgado** — Controls food distribution network; pragmatic
- **James Thornton** — Real estate mogul; trading shelter for loyalty

### Details
- **Territory:** Financial district, key warehouses
- **Strength:** ~300 employees and hired security
- **Resources:** Stockpiled goods, trade connections, organization

### Disposition
Purely transactional. Will work with anyone who has something to trade. Establishing "credits" as currency. Already has traders heading to indigenous contacts.

### Hooks
- Need expedition escorts for trade missions
- Need information about indigenous economy
- Competition with black market operations

---

## THE HARVESTERS — Expedition Groups

**Wants:** Crystals, skill stones, territory knowledge
**Fears:** Being outcompeted, monster escalation

### Key Figures
- **"Boss" Carmine Vitale** — Former construction union leader; now expedition organizer
- **Diana "Huntress" Webb** — Expert tracker; one of first awakened
- **Dr. Oyelaran** — Biologist; studying Vaelithar creatures

### Details
- **Territory:** Eastern staging areas near Crystalveld
- **Strength:** ~150 awakened and capable individuals
- **Resources:** Crystal stockpile, creature knowledge, expedition experience

### Disposition
Aggressive expansion into wilderness. Recruiting awakened aggressively. Most likely to have contact with Silent. Competitive internally—expedition teams vie for best routes.

### Hooks
- Need skilled individuals for expeditions
- Have information about wilderness and creatures
- Internal competition creates opportunities

---

## THE REMNANT — Medical Community

**Wants:** Medicine, equipment, awakened healers
**Fears:** Epidemic, mob demands for resources

### Key Figures
- **Dr. Elena Vasquez** — ER chief; natural leader under pressure
- **Dr. Frank Morrison** — Awakened healer; exhausted, in demand
- **Nurse Kowalski** — Knows secrets; runs informal supply network

### Details
- **Territory:** Major hospitals (Bellevue, NYU Langone, etc.)
- **Strength:** ~100 medical staff with critical skills
- **Resources:** Medical supplies (diminishing), expertise, healing magic (rare)

### Disposition
Overwhelmed. Trying to maintain medical ethics in impossible situation. Different hospitals developing different policies. Will trade treatment for supplies or protection.

### Hooks
- Need medicine from outside (wilderness herbs?)
- Need protection from desperate mobs
- Internal conflict about rationing care

---

## THE PACK — Predatory Awakened

**Wants:** Power, territory, fear
**Fears:** Organized resistance, stronger awakened

### Key Figures
- **Vincent "Fang" Russo** — Shadow manipulation; operates from darkness
- **Leticia "Volt" Santos** — Lightning powers; most visible enforcer
- **Darius Cole** — Super strength; quiet but terrifying

### Details
- **Territory:** Lower Manhattan blocks (expanding)
- **Strength:** ~80 members, roughly half awakened
- **Resources:** Fear, violence, taken goods

### Disposition
Predatory. Taking what they want. Testing boundaries constantly. Will back down from clearly superior force but remember and plan revenge.

### Hooks
- Antagonists for early game
- Information about awakened abilities
- Could be redirected against external threats?

---

## Faction Interaction Notes

### Power Dynamics
- Provisional Authority has legitimacy but no force
- Sentinels have force but need supplies
- Exchange has supplies but needs protection
- Harvesters have crystals but need organization
- Remnant has skills but needs everything
- Pack has power but no allies

### Potential Alliances
- Authority + Sentinels (legitimacy + force)
- Exchange + Harvesters (trade + resources)
- Anyone vs Pack (common enemy)

### Flashpoints
- Who controls food distribution?
- Who controls awakened?
- What to do about Pack?
- How to interact with indigenous?
