# NYC Criminal Factions

## THE FIVE FAMILIES REMNANT — Organized Crime Survivors

**Wants:** Traditional territory, respect, profit
**Fears:** Awakened wildcards, losing relevance

### Key Figures
- **Don Carmine Luciano** — Old guard boss; traditional methods
- **Tony "Numbers" Rizzo** — Pragmatist underboss; adapting to new reality
- **Sofia Marchetti** — Rising capo; sees awakened as opportunity

### Details
- **Territory:** Little Italy, scattered holdings across boroughs
- **Strength:** ~120 loyal soldiers
- **Resources:** Organization, smuggling routes (now expedition routes), discipline

### Character
Pre-existing criminal organization adapted to chaos. Traditional hierarchy provides stability. Old smuggling routes now serve expedition logistics. Struggling with awakened disruption—can't threaten someone who throws lightning. Sofia Marchetti pushing to recruit awakened; Don Luciano resistant.

### Hooks
- Expedition logistics through their routes
- Protection services (legitimate in new context)
- Internal generational conflict
- Competition with Pack for criminal territory

---

## LOS REYES — Latin Gang Confederation

**Wants:** Bronx control, respect, protection money
**Fears:** Rival gangs, awakened threats, Thornwood

### Key Figures
- **"King" Carlos Mendez** — Supreme leader; strategic thinker
- **Maria "La Loba" Vega** — Awakened lieutenant; shapeshifter rumors
- **Padre Julio** — Gang chaplain; moral compass and community link

### Details
- **Territory:** South Bronx
- **Strength:** ~200 members, several awakened
- **Resources:** Street control, community ties, awakened muscle

### Character
Absorbing smaller gangs through diplomacy or force. Protection racket actually keeps neighborhoods functional—they deliver on their promises. Church ties through Padre Julio provide legitimacy and community acceptance. Maria "La Loba" is their awakened enforcer, rumored to actually transform.

### Hooks
- Bronx is Thornwood frontier—they fight monsters
- Protection services for travelers
- Padre Julio is voice of moderation
- Could be allies against external threats

---

## THE GHOST DRAGONS — Chinatown Syndicate

**Wants:** Chinatown protection, smuggling monopoly
**Fears:** Collective rejection, exposure, federal remnants

### Key Figures
- **"Uncle" Wong** — Hidden mastermind; never seen in person
- **Mei-Lin** — Assassin; possibly awakened with shadow abilities
- **David Cho** — Public face; legitimate businessman front

### Details
- **Territory:** Hidden within Chinatown
- **Strength:** ~50 elite members
- **Resources:** Hidden wealth, trained killers, information network

### Character
Operating alongside Chinatown Collective publicly, running criminal operations privately. Tong structure intact and adapted. Uncle Wong has never been seen by outsiders—commands through intermediaries. Mei-Lin handles problems that require permanent solutions.

### Hooks
- Information for sale
- Assassination services
- Tension with Collective leadership
- May know things about Transit (Triad mysticism?)

---

## THE TUNNELERS — Underground Survivors

**Wants:** Subway network control, safety
**Fears:** Surface dangers, tunnel creatures, collapse

### Key Figures
- **"Mole King" Jeremiah** — Founder; knows every tunnel
- **Blind Sarah** — Seer? Prophet? Something awakened
- **Engineer Kowalski** — Infrastructure expert; keeps tunnels safe

### Details
- **Territory:** Accessible subway tunnels
- **Strength:** ~300 underground residents
- **Resources:** Tunnel network knowledge, hidden passages, darkness adaptation

### Character
Homeless population and others who fled underground during Transit chaos. Know the tunnel network intimately—which sections are safe, which collapsed, which have... other things living in them. Blind Sarah claims to see things in the dark that others can't. They won't talk about what lives deeper down.

### Hooks
- Underground travel routes
- Something else lives in the deep tunnels
- Hidden supply caches
- Knowledge of building basements and sub-basements

---

## THE REAPERS — Scavenger Gang

**Wants:** Salvage rights, freedom from rules
**Fears:** Organized opposition, running out of easy pickings

### Key Figures
- **"Crow" Martinez** — Leader; opportunist supreme
- **"Picker" Smith** — Finder; knows where valuable things are
- **"Ghost"** — Awakened scout; actually can turn partially invisible

### Details
- **Territory:** Nomadic, primarily outer boroughs
- **Strength:** ~80 mobile scavengers
- **Resources:** Salvaged goods, mobility, knowledge of abandoned areas

### Character
Strip abandoned areas systematically. Sell to all sides without loyalty. Know where bodies are buried—literally—and where supplies were stashed. Will trade information and goods to anyone with payment. No ideology, pure opportunism.

### Hooks
- Know where things are
- Will sell information about anything
- Can be hired for salvage operations
- Know the dangerous abandoned areas

---

## Criminal Ecosystem Notes

### Territories
- Five Families: Manhattan core, scattered
- Los Reyes: South Bronx
- Ghost Dragons: Chinatown (hidden)
- Tunnelers: Underground network
- Reapers: Nomadic, outer boroughs

### Relationships
- Five Families vs Pack (old territory dispute now awakened conflict)
- Los Reyes vs various Bronx gangs (consolidating)
- Ghost Dragons + Chinatown Collective (symbiotic)
- Tunnelers isolated from surface politics
- Reapers sell to everyone

### Services Offered
- Protection (Families, Reyes)
- Smuggling/Logistics (Families, Dragons)
- Information (Dragons, Reapers, Tunnelers)
- Underground access (Tunnelers)
- Salvage (Reapers)
- Assassination (Dragons)

### Threats
- Pack is everyone's problem
- Awakened criminals destabilize traditional power
- Resource scarcity increases desperation
- External threats may force cooperation
