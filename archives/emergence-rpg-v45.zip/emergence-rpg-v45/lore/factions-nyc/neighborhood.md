# NYC Neighborhood Factions

## THE HARLEM COUNCIL — Community Coalition

**Wants:** Self-governance, northern defense
**Fears:** Thornwood incursions, outside control

### Key Figures
- **Pastor Williams** — Spiritual leader; church network backbone
- **Councilwoman Davis** — Political organizer; liaison to downtown
- **Duke Monroe** — Defense coordinator; former gang leader turned protector

### Details
- **Territory:** Harlem, north of 110th Street
- **Strength:** ~2,000 organized residents
- **Resources:** Strong community bonds, church network for communication

### Character
Strong community ties pre-date the Transit. Churches serve as communication hubs and community centers. Suspicious of downtown factions trying to assert control. Duke Monroe's past gives them street credibility and practical defense experience.

### Hooks
- Northern perimeter pressure from Thornwood
- Internal tension: work with downtown or stay independent?
- Duke's old enemies might cause problems

---

## CHINATOWN COLLECTIVE — Tight-Knit Enclave

**Wants:** Autonomy, family protection
**Fears:** Exploitation, forced integration

### Key Figures
- **Elder Chen Wei** — Respected patriarch; community spokesman
- **Dr. Lin** — Traditional medicine practitioner; increasingly valuable
- **"Red" Huang** — Street boss; enforcer for community decisions

### Details
- **Territory:** Chinatown proper
- **Strength:** ~800 tightly coordinated residents
- **Resources:** Herbal medicine knowledge, tight organization, language barrier as information security

### Character
Pre-existing social structures adapted quickly to crisis. Extended family networks ensure everyone is accounted for. Traditional medicine knowledge suddenly valuable. Language barrier protects internal discussions from outsiders.

### Hooks
- Dr. Lin's herbal knowledge could be valuable for wilderness medicine
- Ghost Dragons operate within/alongside Collective
- Trade connections through Chinatown businesses

---

## WASHINGTON HEIGHTS DEFENDERS — Dominican Community Stronghold

**Wants:** Safety, reconnection with scattered families
**Fears:** Isolation, gang exploitation

### Key Figures
- **Father Martinez** — Church leader; moral authority
- **Maria Gutierrez** — Community organizer; coordinates aid
- **"Machete" Reyes** — Militia leader; practical defender

### Details
- **Territory:** Washington Heights, Inwood
- **Strength:** ~1,500 organized residents
- **Resources:** Strong family networks, control of northern approach

### Character
Control the area where the George Washington Bridge used to connect to New Jersey—now a cliff edge overlooking alien forest. Strong family networks mean excellent internal communication. "Machete" Reyes keeps order with practical brutality when needed.

### Hooks
- Northern approach to Thornwood passes through their territory
- Families separated across boroughs want reunification
- Could be gateway for Thornwood contact

---

## BROOKLYN BRIDGE AUTHORITY — Bridge Controllers

**Wants:** Toll revenue, strategic position
**Fears:** Bridge collapse, overwhelming force

### Key Figures
- **Officer Frank DeLuca** — Ex-cop leader; maintains order
- **"Toll" Jackson** — Enforcer; collects payments
- **Maya Singh** — Negotiator; handles disputes

### Details
- **Territory:** Brooklyn Bridge and both approaches
- **Strength:** ~60 armed members
- **Resources:** Strategic chokepoint, toll income

### Character
The Brooklyn Bridge is the only easy crossing to the Brooklyn fragment. They charge passage and maintain the structure. Corrupt but functional—everyone knows the price and mostly pays it. DeLuca keeps things professional enough to avoid organized opposition.

### Hooks
- Bridge structural integrity concerns
- Brooklyn factions want to break the toll
- Information flows through the bridge—they hear everything

---

## THE VILLAGE COMMUNE — Greenwich Village Collective

**Wants:** Egalitarian community, mutual aid
**Fears:** Authoritarianism, resource hoarding

### Key Figures
- **Professor Sarah Chen** — Academic organizer; idealistic leader
- **"Doc" Williams** — Street medic; practical healthcare
- **Jamie Okonkwo** — Security coordinator; reluctant use of force

### Details
- **Territory:** Greenwich Village
- **Strength:** ~400 committed members, rotating militia
- **Resources:** Idealism, diverse skills, university connections

### Character
Refusing hierarchy and private property. Consensus decision-making. Attracts idealists, artists, academics. Genuinely trying to build something better. Vulnerable to exploitation by bad actors who don't share their values.

### Hooks
- Academic knowledge could be valuable
- Idealism makes them potential allies for "good" players
- Internal conflict when consensus fails

---

## MIDTOWN TOWERS SYNDICATE — Luxury Building Coalition

**Wants:** Exclusive safety, maintained privilege
**Fears:** Mob invasion, resource exhaustion

### Key Figures
- **Richard Vance III** — Financier; de facto leader through wealth
- **Building Superintendents Council** — Practical managers
- **Security Chief Morrison** — Former private security; mercenary now

### Details
- **Territory:** Luxury high-rise buildings, 40th-60th Streets
- **Strength:** ~200 wealthy residents, ~50 hired security
- **Resources:** Stockpiled supplies (diminishing), money (increasingly meaningless)

### Character
The wealthy trying to maintain pre-Transit privilege. Hiring mercenary protection. Hoarding supplies. Wealth means nothing without enforcers, and they're slowly realizing this. Internal tension as resources deplete.

### Hooks
- Will pay well for services (but what's payment worth?)
- Security forces might be bought away
- Some residents have useful skills/knowledge
- Target for robbery attempts

---

## Inter-Neighborhood Dynamics

### Communication
- Harlem: Church network
- Chinatown: Family networks
- Heights: Family + church
- Bridge: Toll traffic
- Village: Meetings
- Midtown: Radio (dying batteries)

### Tensions
- Downtown factions vs. neighborhood independence
- Bridge tolls affect everyone
- Midtown wealth resented
- Village idealism seen as naïve

### Cooperation
- Neighborhoods share Thornwood/monster information
- Medical resources sometimes shared
- Common interest in stability
