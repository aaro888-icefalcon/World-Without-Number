# Culture and History

## Cultural Protocols Quick Reference

### THE SILENT
- Stand still, speak softly
- Salt gift = 3-day bond
- **NEVER:** Enter tent, touch mount, speak loudly, ask about "the song"

### KAELTHARI
- State name and purpose
- Kneeling = submission
- **NEVER:** Turn back, show fear, mention Rebellion, imply they feel cold

### DWEREGAR
- Announce at threshold
- Never give metal as gift (implies their work is inferior)
- **NEVER:** Touch their tools, dig without permission, mention "the Deeps"

### THORNWOOD CLANS
- Show hands empty, greet the forest first
- **NEVER:** Cut living wood, start fire (TERROR RESPONSE), kill without eating

### RIVERMEN
- Wave from shore before approaching
- **NEVER:** Pollute water, violence on Market, lie about trade goods

---

## Faction Trigger Consequences

| Action | Consequence |
|--------|-------------|
| Ally with Kaelthari | Silent/Marchers/Khanate become hostile |
| Strike Kaelthari | Silent/Marchers/Khanate relations improve |
| Free slaves | Marchers favor, Kaelthari hostile |
| Fire in Thornwood | **Immediate** Thornwood hostile (they will hunt you) |
| Dig in mountains | **Immediate** Dweregar hostile |
| Break Dweregar contract | **Permanent** enemy status |
| Violate Silent hospitality | Known to all Silent within one week |

---

## History Timeline

### The Sundering War (800 years ago)
- The Hollow King emerged from the Beneath
- Coalition of all races formed to fight
- Final battle on what is now Sundering Fields
- Hollow King "bound," not destroyed
- Fields remain haunted; death magic saturates soil
- **GM Truth:** The binding is weakening. The Transit damaged it.

### Aelthri Decline (500 years ago)
- Birthrates collapsed mysteriously
- Population dwindled from millions to ~150,000
- They know why but don't share
- **GM Truth:** The binding's price was their fertility

### Shattered Realm Transit (400 years ago)
- Another group of humans appeared via transit
- Built kingdom west of Ironspine
- Forgot their origin over generations
- Church teaches divine delivery
- **Possible connection to NYC transit**

### Marcher Rebellion (150 years ago)
- Slaves escaped Kaelthari Dominion
- Founded Chainbreak fortress
- ~30 Marcher citizens now held at Kaelthari forward camp

### Shattered Realm Civil War (2 years ago)
- King Aldric died without clear heir
- Three factions now fight for throne
- Removed primary counterweight to Kaelthari expansion

### The Transit (Day 1)
- NYC torn from Earth, deposited on Korveth Plateau
- All electronics failed permanently
- The System awakened in every human mind
- 8.4 million humans now refugees in alien world

---

## Mysteries

### THE TRANSIT
- Signature resembles Sundering magic
- Aelthri knew something was coming
- Reversible?
- **GM Truth:** Something called NYC here. Intentionally.

### THE HOLLOW KING
- Not destroyed, bound
- Binding weakening over centuries
- Transit damaged the binding further
- Stirs in the depths
- **GM Truth:** Awakening. Clock ticking.

### THE DEEP
- Something vast exists below Crystal Caves
- Crystals are connected to it
- Dweregar sealed access points
- **GM Truth:** Ancient, curious about humans, neither good nor evil

### AELTHRI DECLINE
- Birthrates collapsed 500 years ago
- They remember why
- **GM Truth:** Price paid for binding the Hollow King

---

## Cosmology

### VAELITHAR (Material World)
- Single massive continent surrounded by ocean
- Magically saturated; mana flows through ley lines
- Two moons: silver and pale green
- Dozens of sapient species

### THE ÆTHER
- Pure mana dimension
- Source of all magic
- Accessed by mages during spellcasting

### THE BENEATH
- Dimension of darkness and hunger
- Hollow King's origin
- Corruption spreads from contact

### THE SHATTERED REALMS
- Broken worlds drifting between dimensions
- Earth may be one of these
- Transit pulled NYC across the void

### THE DEEP
- Unknown entity/dimension below Crystal Caves
- Predates recorded history
- Neither Æther nor Beneath
- Watching. Waiting. Curious.

---

## Starting Clocks

| Clock | Progress | Description |
|-------|----------|-------------|
| City Consolidation | ⧗ 0/8 | How organized is human response? |
| Kaelthari Assessment | ⧗ 0/6 | When do the slavers act? |
| Monster Pressure | ⧗ 0/4 | Next major incursion |
| Resource Depletion | ⧗ 0/6 | Critical shortages |
| Feudal Emergence | ⧗ 0/10 | Anarchy → territorial control |
| First Contact | ⧗ 0/4 | Formal meeting with indigenous power |
| **The Stirring** | ⧗ 0/12 | **(Hidden)** Hollow King awakening |
