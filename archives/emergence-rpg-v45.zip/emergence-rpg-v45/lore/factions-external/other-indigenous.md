# Other Indigenous Peoples

## The Silent (~300,000)

**One-Line:** Grassland nomads who observe and wait; potential guides or enemies.

| Aspect | Detail |
|--------|--------|
| Territory | Crystalveld (eastern grasslands) |
| Disposition | OBSERVING |
| Key Figures | Drift-Walker Shen, Hunt-Master Voss |
| Society | Nomadic herders; follow crystal formations |

**Cultural Protocols:**
- Stand still, speak softly
- Salt gift = 3-day bond of hospitality
- **NEVER:** Enter their tent uninvited, touch their mount, speak loudly, ask about "the song"

**Silent Hounds:** Domesticated predators. Only attack on command. Killing one angers all Silent.

---

## Thornwood Clans (~800,000)

**One-Line:** Isolationist forest dwellers who react violently to intrusion.

| Aspect | Detail |
|--------|--------|
| Territory | Thornwood (northern forest, 3 miles) |
| Disposition | ISOLATIONIST |
| Key Figures | Caller Aethen, Elder Root |
| Society | Tribal; live in symbiosis with forest |

**Cultural Protocols:**
- Show hands empty, greet the forest first
- **NEVER:** Cut living wood, start fire (TERROR RESPONSE), kill without eating

**FIRE WARNING:** Starting fire in Thornwood triggers immediate, overwhelming hostile response. They will pursue you out of the forest and hunt you down.

---

## Dweregar Holds (~4 million)

**One-Line:** Underground smiths with unmatched metalwork; isolationist but will trade.

| Aspect | Detail |
|--------|--------|
| Territory | Ironspine Mountains (west, 6 miles) |
| Disposition | ISOLATIONIST |
| Key Figures | Foreman Kraddock, Deep-Warden Vorn |
| Society | Industrial underground civilization; guild-based |

**Cultural Protocols:**
- Announce yourself at threshold
- Never give metal as gift (implies their work is inferior)
- **NEVER:** Touch their tools, dig without permission, mention "the Deeps"

**Trade Post:** Surface contact point exists in lower Ironspine. Will trade master-forged equipment for specific goods.

**The Deep:** Something vast exists below their caves. They've sealed it. They don't discuss it.

---

## Rivermen Confederation

**One-Line:** Delta traders who deal with everyone neutrally.

| Aspect | Detail |
|--------|--------|
| Territory | Delta region (northeast, 8 miles) |
| Disposition | PRAGMATIC |
| Key Figures | Grandmother Vessels, Captain Marsh |

**Cultural Protocols:**
- Wave from shore before approaching
- **NEVER:** Pollute water, violence on Market boats, lie about trade goods

---

## Aelthri Remnant (~150,000)

**One-Line:** Fading ancients who may hold answers about the Transit.

| Aspect | Detail |
|--------|--------|
| Territory | Sanctuary (40+ miles south) |
| Disposition | MELANCHOLY |
| Key Figures | Vaelindra, Thessaly the Chronicler |
| Society | Ancient, declining; birthrates collapsed 500 years ago |

**They know something about the Transit.** They haven't shared it.

**Memory Vaults:** Non-combat location requiring invitation. Contains Transit answers and history.

**GM Truth:** The binding of the Hollow King cost them their fertility.

---

## Free Cities (~3 million)

**One-Line:** Coastal merchant republics that trade with everyone and commit to no one.

| Aspect | Detail |
|--------|--------|
| Territory | Southeastern coast |
| Disposition | NEUTRAL/PROFIT-MOTIVATED |

**Major Cities:** Valdris (banking), Porton (port), Craftholm (industry), Goldgate (luxury), Ironhaven (ships), Silverquay (slave market), Freeport (pirates)

**Slavery:** Legal in Silverquay; tolerated elsewhere. Morally compromised but economically practical (their view).

**They offer:** Trade goods, mercenaries, banking, information, neutral ground.
**They want:** Trade access to NYC, stability, no one power dominating.

---

## Shattered Realm (~22 million)

**One-Line:** Human kingdom arrived via transit 400 years ago; now in civil war.

| Aspect | Detail |
|--------|--------|
| Territory | Western continent beyond Ironspine |
| Current State | Civil war between three claimants |

**The Three Claimants:**

| Claimant | Claim | Forces | Offers NYC |
|----------|-------|--------|------------|
| Princess Aldara | Legitimate heir | ~5,000; legitimacy | Recognition, Church blessing |
| Marshal Corvain | Right of conquest | ~12,000; experienced | Military expertise, weapons |
| Merchant Council | Commerce should rule | ~3,000 mercenaries | Trade, money, contracts |

**Why It Matters:** Pre-war Realm matched Kaelthari. Civil war removed counterweight. Winner's disposition toward NYC matters enormously.

**Realm Origin Mystery:** They don't remember where they came from. Church teaches divine delivery. Connection to NYC transit?
