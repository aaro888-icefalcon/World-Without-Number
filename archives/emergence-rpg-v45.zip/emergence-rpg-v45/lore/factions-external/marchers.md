# The Marchers

**One-Line:** 600,000 former Kaelthari slaves with universal military service who will judge NYC by its stance on slavery.

## Quick Facts

| Aspect | Detail |
|--------|--------|
| Population | ~600,000 |
| Territory | Buffer zone between Free Cities and Kaelthari |
| Capital | Chainbreak — fortress city of 80,000 |
| Government | Military republic; Marshal elected by veteran assembly |
| Military | Universal service; ~150,000 mobilizable; all experienced |
| Religion | Cult of the Broken Chain; freedom is sacred; slavery is evil |

## Current Marshal: Vera Chainbreaker

- Age 45; third-generation Marcher
- Hardliner; will NEVER negotiate with Kaelthari
- Led 20+ raids into Dominion territory
- Visible slave brands on arms; displays proudly
- **View of NYC:** Hopeful but wary; will test commitment to freedom

## Society

- Mixed species: Humans (60%), others escaped from Dominion (40%)
- Universal military service ages 15-50
- Citizenship earned through service; refugees must serve to join
- **Slavery is the ultimate evil; death preferable to re-enslavement**
- Tattoos mark battles, kills, service record
- "The nation is our family"

## Military Capability

- 150 years of continuous warfare with Kaelthari
- Know Dominion tactics, weaknesses, psychology
- Guerrilla specialists: raids, ambushes, hit-and-run
- Cannot face Dominion in open battle (numbers too uneven)
- Survive through terrain knowledge, speed, ruthlessness

## What Marchers Know (VALUABLE INTELLIGENCE)

- Kaelthari military doctrine, unit structure, command patterns
- Dominion internal politics and factional conflicts
- Slave trade routes, holding facilities, guard rotations
- Kaelthari language, customs, weaknesses

## The Slavery Test

**~30 humans at Kaelthari forward camp are captured Marcher citizens.**

- Marchers know they're there
- Rescue or abandonment will define NYC-Marcher relations
- This is a deliberate test by circumstances

## Marcher View of Slavery

| Action | Judgment |
|--------|----------|
| Any tolerance of slavery | Moral failure |
| Trading with slavers | Complicity |
| Owning slaves | Enemy |
| Freeing slaves | Ally |

**NYC will be judged by its stance.**

## What They Want from NYC

- **Ideal:** Full military alliance against Kaelthari; total commitment
- **Acceptable:** Rescue of Marcher slaves; anti-slavery stance
- **Minimum:** Non-interference; don't trade with Dominion
- **Unacceptable:** Any cooperation with Kaelthari; tolerating slavery

## What Marchers Offer

- Military alliance against Kaelthari
- 150 years of intelligence on Dominion
- Guerrilla warfare expertise
- Moral clarity and commitment
- Path to Khanate alliance (they have contacts)

## Key Figures

| Name | Role |
|------|------|
| Marshal Vera Chainbreaker | Must be convinced NYC is worthy |
| Captain Jorah Scarback | Raid leader; liaison if relations improve |
| Elder Miriam | Former slave; memory keeper; knows Kaelthari weaknesses |
| Agent Tal | Already in NYC? Observing human response to slavery question |

## NPC Interaction Guidelines

**Marcher NPCs are:**
- Absolutely committed to their cause
- Suspicious until proven otherwise
- Excellent sources of Kaelthari intelligence
- Harsh judges of moral compromise
- Loyal unto death once trust is earned

**The slavery question will come up. PCs must eventually take a stance. Neutrality is not possible; inaction is a choice that Marchers will judge.**
