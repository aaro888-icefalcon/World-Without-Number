# The Kaelthari Dominion

**One-Line:** Expansionist scaled empire of 30M that practices slavery and views all others as subjects, resources, or obstacles.

## Quick Facts

| Aspect | Detail |
|--------|--------|
| Population | ~30M Kaelthari + ~8M slaves |
| Territory | Southeastern continent; tropical/subtropical |
| Capital | Thesskareth ("The Warm Heart") — 2M population |
| Government | Theocratic military empire; Supreme Overmind is divine ruler |
| Military | 500,000+ professional legionaries; scaled mages; grass-runner cavalry |
| Religion | Worship the Sun-That-Warms; cold = death/evil; heat = life/good |

## Caste System (By Scale Color)

| Caste | Role |
|-------|------|
| Azure (Blue) | Royal bloodline; only they can become Supreme Overmind |
| Verdant (Green) | Nobility; governors, high officers, senior mages |
| Copper | Professional class; officers, mages, administrators |
| Bronze | Skilled labor; craftsmen, merchants, junior officers |
| Gray | Common labor; soldiers, farmers, workers |
| Pale | Lowest caste; servants, expendable labor |
| Albino | Cursed; killed at birth or enslaved |

## Biology

- Cold-blooded; require external heat (vulnerability they never discuss)
- Carnivorous; prefer live prey; consider cooked meat inferior
- Forked tongues taste-smell air; can detect fear, arousal, deception
- Shed skin annually; shedding period is private, vulnerable
- Lifespan 150-200 years; adult at 30

## Military Doctrine

- Professional standing army; legion structure (5,000/legion, 100+ legions)
- Combined arms: Heavy infantry, scaled mages, cavalry, siege
- Doctrine: Overwhelming force, encirclement, demand surrender, enslave survivors
- **Weaknesses:** Cold weather, night operations, guerrilla warfare

## Slavery

- Slaves are property; can be bought, sold, killed by owner
- ~30 human slaves at forward camp are captured Marcher citizens
- This is a deliberate test by circumstances

## Political Factions

| Faction | Stance on NYC |
|---------|---------------|
| Expansionists | New slave source |
| Consolidators | Buffer/potential ally |
| Purists | Threat to eliminate |

## What They Want from NYC

- **Best:** Voluntary submission as client state; tribute, slaves, resources
- **Acceptable:** Alliance against Khanate; military support, trade
- **Minimum:** Non-interference; stay on plateau, don't ally with enemies
- **Unacceptable:** Alliance with Khanate or Marchers; unified resistance

## Key Figures

| Name | Role |
|------|------|
| Supreme Overmind Thessarak | Ultimate authority (Azure, 180 years old) |
| Commander Kethras | Forward camp commander (at Korveth) |
| General Vekkthar the Cold | Commands southern armies; expansionist |
| High Magister Ssissara | Head of mage corps; studying Transit |
| Merchant Prince Kasseth | Controls trade; sees NYC as opportunity |

## NPC Interaction Guidelines

Kaelthari are ALWAYS evaluating:
- Can this human fight? (Combat capability)
- Can this human be useful? (Skills, knowledge, connections)
- Can this human be controlled? (Psychological leverage)
- Is this human a threat? (Power level, allies, intentions)

**Every interaction is a test.** Showing weakness invites exploitation. Showing strength earns respect but also caution.

## Cultural Protocols

- State name and purpose when addressing
- Kneeling = submission (don't do unless surrendering)
- **NEVER:** Turn your back, show fear, mention the Rebellion, imply they feel cold
