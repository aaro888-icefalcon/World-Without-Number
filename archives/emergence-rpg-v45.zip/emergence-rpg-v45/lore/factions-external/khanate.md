# The Steppen Khanate

**One-Line:** Nomadic horse empire of 10M native Vaelithar humans who have fought Kaelthari to standstill for centuries.

## Quick Facts

| Aspect | Detail |
|--------|--------|
| Population | ~10 million |
| Territory | Eastern grasslands; extends far beyond Crystalveld |
| Capital | None permanent; Khan's camp moves seasonally |
| Government | Meritocratic confederation; Khan elected by clan chiefs |
| Military | Every adult rides and fights; ~2 million potential riders |
| Religion | Ancestor worship; Sky Father and Earth Mother; shamanic tradition |

## Current Khan: Temur the Patient

- Age 52; ruled 18 years
- Diplomatic, strategic, prefers alliance to conquest
- Expanded Khanate through marriage alliances, not war
- **View of NYC:** Curious; sees potential ally against Kaelthari
- **Concern:** Will NYC humans have strength to be useful allies?

## Great Clans

| Clan | Character |
|------|-----------|
| Iron Riders | Military elite; Khan's guard; ~50,000 warriors; fiercely loyal |
| Wind Singers | Shamanic tradition; magic users; interested in Transit's signature |
| Golden Horde | Merchant clan; control trade routes; see NYC as opportunity |
| Storm Bringers | Aggressive warriors; want war with Kaelthari NOW |
| Sky Watchers | Scouts, intelligence; already have agents observing NYC |

## Culture and Values

- Strength respected; weakness despised (but less cruelly than Kaelthari)
- **Hospitality sacred; guest-right is inviolable**
- **Oaths binding unto death; oath-breakers are outcast**
- Horses are sacred; harming another's horse is grave offense
- Women fight alongside men; gender equality
- Death in battle is honorable; death in bed is shameful

## Military Capability

- Every adult can ride, shoot, fight from age 12
- Light cavalry tactics: mobility, archery, feigned retreat, encirclement
- No siegecraft; avoid fortified positions
- **Strengths:** Speed, endurance, coordination, numbers
- **Weaknesses:** No heavy infantry, no siege, poor in forests/mountains

## Khanate-Kaelthari Conflict

- Wars every generation for 500+ years
- Neither can decisively defeat the other
- Current: Tense peace; border skirmishes; both building strength
- **NYC changes the equation:** If humans ally with Khanate, balance tips

## What They Want from NYC

- **Ideal:** Military alliance against Kaelthari; NYC holds western flank
- **Acceptable:** Trade, information sharing, non-aggression
- **Unacceptable:** NYC alliance with Kaelthari

## How to Earn Alliance

1. Demonstrate military capability (kill something impressive)
2. Show willingness to fight Kaelthari
3. Respect Khanate customs and guest-right
4. Provide something of value (weapons? magic? information?)
5. Be patient; they will test before committing

## Key Figures

| Name | Role |
|------|------|
| Khan Temur | Must be impressed to gain alliance |
| War Chief Altan | Commands Iron Riders; skeptical of NYC |
| High Shaman Oyuun | Leads Wind Singers; wants to study awakened humans |
| Trade Master Batu | Golden Horde leader; planning trade missions |

## NPC Interaction Guidelines

**Khanate NPCs respect:**
- Demonstrated combat ability
- Keeping your word absolutely
- Hospitality properly given and received
- Courage in face of danger
- Practical thinking over sentiment

**They lose respect for:**
- Weakness or cowardice
- Broken oaths or lies
- Refusing offered hospitality
- Excessive cruelty
- Inability to ride (minor but noticeable)
